import { request } from './index'

// 获取地图附近列表
export const locationNearbyList = data => request({
  method: 'POST',
  url: '/location/nearbyList',
  data
})

// // 智库动态详情
// export const dynamicDetail = data => request({
//   url: `/axis/wechat/dynamic/${data.id}`,
//   data
// })
// // 获取bannerlist
// export const bannerList = data => request({
//   url: `/axis/wechat/banner/list`,
//   data
// })
// // 上传文件
// export const commonUpload = data => request({
//   method: 'POST',
//   url: `/common/upload`,
//   data
// })
export const mappingByVillage = data => request({
  url: `/mapping/byVillage?area=${data.area}`,
  header: {
    'content-type': 'application/json',
    token: 'eyJhbGciOiJSUzI1NiJ9.eyJ1c2VybmFtZSI6IjE4NTMzMDg1MjU3IiwiaXNzIjoiMTg1MzMwODUyNTciLCJzdWIiOiJTWVMiLCJpYXQiOjE2NzM3NzUzMjQsImV4cCI6MTY3Mzc4MjUyNH0.x6rTMZwZ7cDe1OZEiHX04phKAVhUajsVknrM8ilP_tIwzpJAS6b664S01U748KiZ17sJ9TaG0XkXVc3sOGTykSrY_n9GIJ6TfEYr8jFiZjfnV_eR4gVOyS9QtOMK91YfynBkyFNBtNf_vNfNLvxS8rawgkNsnziXzWoeFDep-ms'
    },
  method: 'GET'
})
