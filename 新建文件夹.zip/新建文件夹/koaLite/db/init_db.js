const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

const pool = mysql.createPool({
  host: 'sh-cynosdbmysql-grp-9gv4boza.sql.tencentcdb.com',
  port: 24563,
  user: 'root',
  password: 'R7cRMzuj',
  database: 'election_v2',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function initDB() {
  let connection;
  try {
    // 读取 SQL 文件
    const sqlFile = path.join(__dirname, 'init_v2.sql');
    const sql = fs.readFileSync(sqlFile, 'utf8');

    // 连接数据库
    connection = await pool.getConnection();
    console.log('✓ 连接腾讯云数据库成功');

    // 执行 SQL（按分号分割执行多条语句）
    const statements = sql.split(';').filter(s => s.trim());

    for (let i = 0; i < statements.length; i++) {
      const stmt = statements[i].trim();
      if (stmt) {
        await connection.execute(stmt);
        console.log(`✓ 执行第 ${i + 1}/${statements.length} 条 SQL`);
      }
    }

    console.log('✓ 数据库初始化完成');
    process.exit(0);
  } catch (err) {
    console.error('✗ 错误:', err.message);
    process.exit(1);
  } finally {
    if (connection) connection.release();
    await pool.end();
  }
}

initDB();
