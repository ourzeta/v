import { defineStore } from 'pinia';
import { ref } from 'vue';
import { login as loginApi } from '@/api/api';
import router from '@/router';

export const useAuthStore = defineStore('auth', () => {
  const token = ref(localStorage.getItem('token') || '');
  const user = ref(JSON.parse(localStorage.getItem('user') || 'null'));

  async function login(phone: string, password: string, role: string, villageId?: string) {
    const res: any = await loginApi(phone, password, role, villageId);
    token.value = res.token;
    user.value = res.user;
    localStorage.setItem('token', res.token);
    localStorage.setItem('user', JSON.stringify(res.user));
    router.push('/dashboard');
  }

  function logout() {
    token.value = '';
    user.value = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/login');
  }

  return { token, user, login, logout };
});
