var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/screenshot/route.js")
R.c("server/chunks/[root-of-the-server]__06k3odnjkl0dc._.js")
R.c("server/chunks/server_http_1_talzw37mkt5.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0wa_cny40gfmm._.js")
R.c("server/chunks/_next-internal_server_app_api_screenshot_route_actions_1b2rmq65qjn__.js")
R.m(959384)
module.exports=R.m(959384).exports
