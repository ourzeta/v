var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/asset/[...path]/route.js")
R.c("server/chunks/[externals]__0zs-obvkaa-mj._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_0x4d41nhf3rws._.js")
R.c("server/chunks/_next-internal_server_app_api_asset_[___path]_route_actions_1cmmxarcnaraw.js")
R.m(562161)
module.exports=R.m(562161).exports
