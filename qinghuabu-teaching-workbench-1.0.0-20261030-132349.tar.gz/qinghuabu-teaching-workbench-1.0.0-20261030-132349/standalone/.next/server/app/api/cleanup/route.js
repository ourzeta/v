var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cleanup/route.js")
R.c("server/chunks/[root-of-the-server]__104oob4sbh4j5._.js")
R.c("server/chunks/server_http_1_talzw37mkt5.js")
R.c("server/chunks/_0szcj4-mayvi1._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_next-internal_server_app_api_cleanup_route_actions_1lycnxhopl1zb.js")
R.m(538720)
module.exports=R.m(538720).exports
