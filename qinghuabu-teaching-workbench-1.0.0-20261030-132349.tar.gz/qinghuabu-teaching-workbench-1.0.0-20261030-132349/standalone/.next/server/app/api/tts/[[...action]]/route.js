var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tts/[[...action]]/route.js")
R.c("server/chunks/[root-of-the-server]__06k3odnjkl0dc._.js")
R.c("server/chunks/src_lib_mathAsrConverter_0-99l3134e1se.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_18h5u7esu04_1._.js")
R.c("server/chunks/_next-internal_server_app_api_tts_[[___action]]_route_actions_0xx8gjk97yo61.js")
R.m(291293)
module.exports=R.m(291293).exports
