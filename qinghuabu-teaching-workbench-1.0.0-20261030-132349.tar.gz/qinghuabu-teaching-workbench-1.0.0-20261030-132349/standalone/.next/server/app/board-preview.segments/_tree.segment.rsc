:HL["/_next/static/chunks/3vqx2gqpvhqbm.css","style"]
:HC["/",""]
:HL["/_next/static/chunks/07dt9lho7rqiv.css","style"]
:HL["/_next/static/chunks/1ydjbmvcd15-j.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"board-preview","h":96,"c":"$Q2"}]]
0:{"b":"fYE8EksxSS3V0bpONyxFh","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
