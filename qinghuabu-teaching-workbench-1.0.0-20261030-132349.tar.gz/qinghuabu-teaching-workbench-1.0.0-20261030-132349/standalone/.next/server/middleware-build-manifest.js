globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/fYE8EksxSS3V0bpONyxFh/_buildManifest.js",
    "static/fYE8EksxSS3V0bpONyxFh/_ssgManifest.js",
    "static/fYE8EksxSS3V0bpONyxFh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0b766pd_07krm.js",
    "static/chunks/0lf376vpvibs6.js",
    "static/chunks/1xwrzwvpj1gb0.js",
    "static/chunks/0i8eef_83jjb7.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0b766pd_07krm.js",
        "static/chunks/0lf376vpvibs6.js",
        "static/chunks/1xwrzwvpj1gb0.js",
        "static/chunks/0i8eef_83jjb7.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0b766pd_07krm.js",
        "static/chunks/0lf376vpvibs6.js",
        "static/chunks/1xwrzwvpj1gb0.js",
        "static/chunks/0i8eef_83jjb7.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0b766pd_07krm.js",
        "static/chunks/0lf376vpvibs6.js",
        "static/chunks/1xwrzwvpj1gb0.js",
        "static/chunks/0i8eef_83jjb7.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    },
    "/board-preview/page": {
      "otherChunks": [
        "static/chunks/0b766pd_07krm.js",
        "static/chunks/0lf376vpvibs6.js",
        "static/chunks/1xwrzwvpj1gb0.js",
        "static/chunks/0i8eef_83jjb7.js"
      ],
      "runtimeModuleIds": [
        494553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
