module.exports=[822435,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tts_%5B%5B___action%5D%5D_route_actions_0xx8gjk97yo61.js.map