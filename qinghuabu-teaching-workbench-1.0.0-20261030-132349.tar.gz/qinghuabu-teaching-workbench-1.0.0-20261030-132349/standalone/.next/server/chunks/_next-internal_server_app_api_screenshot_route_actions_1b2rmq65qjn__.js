module.exports=[594097,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_screenshot_route_actions_1b2rmq65qjn__.js.map