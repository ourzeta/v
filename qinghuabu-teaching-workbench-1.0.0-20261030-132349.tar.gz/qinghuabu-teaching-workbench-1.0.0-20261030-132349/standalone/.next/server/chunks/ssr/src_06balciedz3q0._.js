module.exports=[[827572,a=>{var b=a.i(907997),c=a.i(500522);let d=`(function() {
  var origDefineProperty = Object.defineProperty;
  var initialNativeFetch = window.fetch;
  var customFetch;
  var hasCustomSet = false;
  Object.defineProperty = function(obj, prop, desc) {
    if (obj === window && prop === 'fetch') {
      var origGet = desc && desc.get;
      return origDefineProperty.call(Object, obj, prop, {
        configurable: true,
        enumerable: true,
        get: function() {
          if (hasCustomSet) return customFetch;
          return origGet ? origGet.call(window) : (customFetch || initialNativeFetch);
        },
        set: function(val) {
          customFetch = val;
          hasCustomSet = true;
        }
      });
    }
    return origDefineProperty.apply(this, arguments);
  };
  try {
    var desc = Object.getOwnPropertyDescriptor(window, 'fetch');
    if (desc && desc.configurable && !desc.set) {
      Object.defineProperty(window, 'fetch', desc);
    }
  } catch (e) {}
})();`,e=`(function() {
  var main = document.createElement('link');
  main.rel = 'preload'; main.as = 'style';
  main.href = '/fonts/board-local.css';
  main.onload = function() { main.rel = 'stylesheet'; };
  main.onerror = function() { console.warn('[Font] 本地板书字体加载异常，按字体栈降级'); };
  document.head.appendChild(main);
  ['507', '511', '510', '509'].forEach(function(id) {
    var l = document.createElement('link');
    l.rel = 'stylesheet'; l.media = 'print';
    l.href = 'https://fontsapi.zeoseven.com/' + id + '/main/result.css';
    l.onload = function() { l.media = 'all'; };
    document.head.appendChild(l);
  });
})();`;a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"zh-CN",suppressHydrationWarning:!0,children:[(0,b.jsxs)("head",{children:[(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:d}}),(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:e}}),(0,b.jsx)("script",{defer:!0,src:"/snapdom.js"})]}),(0,b.jsx)("body",{suppressHydrationWarning:!0,children:(0,b.jsx)("div",{id:"app",className:"min-h-screen",children:(0,b.jsx)(c.default,{children:a})})})]})},"metadata",0,{title:"小学数学讲解视频生成工作台",description:"基于大模型的小学数学题识别、分步口播与板书动作生成的教学视频工作台",icons:{icon:"/favicon.svg"},openGraph:{title:"小学数学讲解视频生成工作台",description:"基于大模型的小学数学题识别、分步口播与板书动作生成的教学视频工作台"}}])},256687,a=>{let b=(0,a.i(211857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/teaching/TeachingProviders.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/teaching/TeachingProviders.tsx","default");a.s(["default",0,b])},500522,a=>{var b=a.i(256687);a.n(b)}],650645,function(a){a.n(a.i(827572))}];

//# sourceMappingURL=src_06balciedz3q0._.js.map