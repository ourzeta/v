module.exports=[265548,a=>{"use strict";let b=[{bg:"rgba(246, 201, 95, 0.75)",border:"#f6c95f"},{bg:"rgba(255, 143, 163, 0.75)",border:"#ff8fa3"},{bg:"rgba(110, 231, 183, 0.75)",border:"#6ee7b7"},{bg:"rgba(125, 211, 252, 0.75)",border:"#7dd3fc"},{bg:"rgba(216, 180, 254, 0.75)",border:"#d8b4fe"}],c=["biu~ ✨","biu~ 🫧","啵~ 💖","biu~ 🌸","biu~ 🍃","好嘞~ ✨"],d=null;a.s(["initBiuBubbleListener",0,function(){},"triggerBiuBubble",0,function(a,e,f=null){let g=(!d&&"u">typeof document&&((d=document.createElement("div")).id="biu-bubble-stage",d.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 999999;
      overflow: hidden;
    `,document.body.appendChild(d)),d);if(!g)return;let h=f||c[Math.floor(Math.random()*c.length)],i=document.createElement("div");i.className="biu-popup-pill",i.textContent=h,i.style.left=`${a}px`,i.style.top=`${e}px`,g.appendChild(i);let j=4+Math.floor(3*Math.random());for(let c=0;c<j;c++){let d=document.createElement("div");d.className="biu-soap-bubble";let f=b[Math.floor(Math.random()*b.length)],h=10+Math.floor(12*Math.random()),i=2*Math.PI*c/j+(Math.random()-.5)*.5,k=20+26*Math.random(),l=Math.cos(i)*k,m=Math.sin(i)*k-22;d.style.width=`${h}px`,d.style.height=`${h}px`,d.style.left=`${a-h/2}px`,d.style.top=`${e-h/2}px`,d.style.setProperty("--dx",`${l}px`),d.style.setProperty("--dy",`${m}px`),d.style.background=f.bg,d.style.borderColor=f.border,g.appendChild(d),setTimeout(()=>{d.parentNode&&d.parentNode.removeChild(d)},700)}setTimeout(()=>{i.parentNode&&i.parentNode.removeChild(i)},750)}])}];

//# sourceMappingURL=src_utils_biuBubble_0pakuu4hjtsx_.js.map