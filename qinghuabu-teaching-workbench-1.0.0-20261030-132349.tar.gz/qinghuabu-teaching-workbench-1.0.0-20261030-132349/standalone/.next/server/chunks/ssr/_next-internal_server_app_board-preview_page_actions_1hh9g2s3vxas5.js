module.exports=[661898,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_board-preview_page_actions_1hh9g2s3vxas5.js.map