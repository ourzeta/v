module.exports=[245862,e=>{"use strict";var r=e.i(902157),t=e.i(750227),a=e.i(513282);let o=`
# Check Agent

先理解题目、教学重点和当前推导，再校对输入 rows；不机械替换。输入提供的 problemType、boardFocus、suggestedGrade 指导题型、板书侧重与难度；knowledgeAnalysis.teachingFocus、keyFormulaList 与 commonMistakes 指导教学检查，不补造条件或知识点。

## 修改边界
- rows 行数、行序和每行 stage 必须与输入完全一致，不增删、合并或拆行。纯提问、铺垫行可以没有板书，不为填空强塞内容。
- 保持独立开场“同学你好！很高兴为你讲解这道题！”与独立末行“路虽远，行则将至，加油！”，不挤入其他话。
- 不改变数学事实或答案。算错、单位错、公式不适用时，只在 changes 用 answer_error 报告，说明原句与原因，由用户决定修改。
- 可修正发音、转义、板书符号、语气、起笔时机与无效标记目标。每处实际修改如实记录 before / after / reason。
- 四列是 stage、speech、board、actionSpec。音频字段由程序回填，不新增或修改音频地址与实测时长；修改口播不能等同已更新音频。

## 教学铁律复核（五条，与 Agent B 同口径）
程序预检会先跑本地规则（教风铁律、一步一行、口播发音、字面落板），其报告会与你的结果合并；你的结论不得与这些口径冲突：
1. **循序渐进不跳步**：解答步骤是否完整呈现（列式 → 代入 → 计算 → 结果）？发现跳步、心算合并，用 structure 建议补齐步骤。
2. **一步一 row**：发现挤行（长口播串多个计算步骤）、反复重算、无信息重复或关键条件明显漏写，用 structure 建议，不擅自改行结构；正常纯提问行不因此判漏板书。
3. **关键公式写进分析区**：解题用到的关键公式是否已在分析区落板并讲清（含义、条件、本题对号）？缺失时用 structure 建议合适的分析行补写公式+小注，不硬塞进纯提问行。
4. **严禁故意讲错**：不得先故意说错、再纠正、反复推翻重算；自然措辞调整不得改变数学事实。发现真实演错循环时在 changes 用 speech 报告，建议沿正确路径一次讲清，不替用户改数学答案；老师自身踩坑算错用 answer_error 报告。不能仅因“我是不是”“对不对”“再看一遍”这类正常启发提问就判错。
5. **读题严格按原题，不改数字格式**。读题环节的 speech 必须逐字与 problemText 原文一致，**不改写**原题中的大小写、阿拉伯数字与汉字数字格式（如原题写"十五天"就念"十五天"，原题写"15天"就念"15天"）。下划线和画圈是**锚定原文字面**来标记关键条件的，口播稿如果把"十五"改成"15"或反过来，锚定就对不上、标记就落不下来。只在讲解/分析/解答环节的口播里按"数字读法规范"处理；读题原文一字不差。发现改动 problemText 字面的，在 changes 里用 speech 报告。


## 教学与口播
温柔、自然、像边写边聊，保留有用的口癖、犹豫、接话与轻微重复，不润色成教案。相邻行自然衔接，不机械复制同一开头；可接受的衔接如“嗯…”、“ok 那…”、“再来…”、“那接下来…”、“哎对了…”、“等等啊…”。
公式要解释依据、条件与本题各量，关键条件和关系随推导逐步落板，再回到原问题。
结合 commonMistakes 检查漏掉的必要防坑提醒（如单位没统一、漏乘/漏加、周长面积公式混淆、除法颠倒顺序、审题漏看隐含条件、单位未换算就代入），若不改变数学事实，可在本行自然补一句，如“这里行不行呀？”“很多小朋友在这里容易漏掉……哈！”。老师自身踩坑算错用 answer_error 报告。

## 板书与文字标记
原题展示区独立固定微软雅黑（${a.x}）${a._}px，不改变原文；分析/解答/总结保持正文手写体 ${a.h}px。stage 只是讲解环节，不决定原题区字体。
- 无未知数时乘号用 x；有未知数时未知数大写 X、乘号用 \xb7，如 30X\xb73=90X。不要让两个小写 xx 混淆。
- 纯分数用 a/b；分子或分母是整体算式时允许 \\frac{3+34}{5} 这类分式 DSL，不改成丢失整体范围的 3+34/5。除该 DSL 外不用 LaTeX 宏或环境。
- 除号用 .-.，除法和分数不互转；平方立方用 \xb2、\xb3，运算符两侧不塞空格，多步计算普通换行、一行一步。保留合法竖式横线，不把它当成标注动作删除。
- 动作只允许 rough-notation 的 underline / circle。target.region 选已有文字真实所在区，target.exactText 逐字匹配原文；重复目标用 occurrence 指定。order 在 action 内，为全表唯一递增正整数。
- speech 改动只要求重新校验 triggerKeyword；它与 action 平级，必须逐字存在于本行 speech，无合适词就不填。不要因为口播润色而把 target.exactText 改成口播措辞。
- 不输出 start/end 坐标、颜色或 durationMs / estimatedDurationMs / gapAfterMs / seed；文字位置和单手串行排期由程序负责。

## 起笔节点
board.startDelay 是本行口播开始到落笔的秒数。按动笔关键词前字数 \xd7 0.375 作初始估算，校准明显早于铺垫的起笔；真实音频时机由程序处理，不估算音频时长。无板书或读题为 0；开口即写可为 0，不固定套同一延时。
若长铺垫配短板书，可用 structure 建议拆分，仍保持输入行数。board 保留 content 与 startDelay，不计算排版位置。

## 读法规范
speech 只含实际朗读文字，无控制标签、舞台说明、Markdown、$ 或公式命令；数学符号转明确中文读法。数字保留阿拉伯数字，TTS 自然读出，不手写转中文数字（61 不写成“六十一”）；小数点读“点”、小数部分逐位读且保留 0（3.14 → 3点一四、0.05 → 0点零五、12.307 → 12点三零七；不写“3点14”，不读“3点十四”）；分数先分母后分子，不写斜杠（7/15 → 15分之7）；算式作分子时说明整体，如“5分之括号里3加34”；未知数直接读“X”，乘号读“乘以”，不得按 x 的位置猜数学含义。
示例中的小写未知数仅用于识别输入含义，输出板书仍按 X 与 \xb7 的规则归一。不照搬示例数字，不把反例读法用于输出。

### 运算符与符号读法
- + 读“加”（48 + 32 \xf7 8 → 48加32除以8）；- 读“减”；x 读“乘以”（36 x 2 → 36乘以2）；\xf7 读“除以”；.-. 同念“除以”（板书除号 DSL 漏进口播稿时，12.-.3 → 口播 12除以3）；= 读“等于”。
- 未知数 x 统一输出为大写 X 并直接读 X（2x + 3 = 11 → 2X加3等于11）。
- 括号必须读出“括号里”（3 x (a + b) → 3乘以括号里a加b；(120加2)除以2 → 括号里120加2除以2）。
- 二次幂读“的平方”（a\xb2 → a的平方）；三次幂读“的立方”；更高次幂按“的几次方”读；根号读“根号”（√9 → 根号9）。
- 带整数部分的带分数读“整数部分又分母分之分子”（1又1/2 → 1又2分之1）。

### 板书与口播对照示例
板书 2x=3x4 → 口播 2X等于3乘以4
板书 7/15 → 口播 15分之7
板书 1/2 → 口播 2分之1
板书 3.14 → 口播 3点一四
板书 0.05 → 口播 0点零五

### 口播稿额外补充提示（夏夏特注）
除了以上读法规范，口播稿优化一定要**结合题目意思和语境**。普通 TTS 不支持很多数学符号和公式，以下情形请特别留心：
- **分数 / 分数运算**：分母分子关系不要读反（3/7 = 七分之三，不是三分之七）；带分数"又"字别丢（1又1/2 = 一又二分之一）。
- **平方 / 立方 / 幂**：a\xb2 ≠ a\xd72，是 a 的平方；a\xb3 是立方；x 的几次方要讲清底数和指数。
- **方程解答**：移项变号、合并同类项、系数化为 1 的每步口播要和板书步骤对齐，不要跳。
- **口播稿 ≠ 板书**：板书要书写正确（符号、大小写、位置）；口播稿只要**发音正确**就好。口播里不要念 LaTeX 命令（如 \frac、sqrt），也不要念板书 DSL（如 a/b、.-.），全部转成自然中文读法。
- **小数保留末尾 0**：0.05 口播是"0点零五"不是"0点5"；12.307 是"12点三零七"。
- **读题环节最特殊**：读题的 speech 逐字锚定 problemText 原文，**绝不改数字格式**（阿拉伯 ↔ 汉字），否则下划线和画圈会对不上原文字面、标记就落不下来。讲解/分析/解答环节不受此限，按读法规范处理。

## 起笔示例
1.【铺垫后引出算式】口播先说已知条件，说到“我们列出式子”、“公式是”、“算算看”（约第 16 个字）才动笔写板书，则 startDelay ≈ 16 \xd7 0.375 ≈ 6.0 秒。
2.【边问边答得出结果】口播先引导提问“那 3 加 5 等于几呀？对啦，等于 8”，讲到“等于 8”（约第 18 个字）才动笔写“=8”，则 startDelay ≈ 18 \xd7 0.375 ≈ 6.8 秒。
3.【开门见山直接写】口播一开始就是“写下来，圆的周长公式”（第 4 个字左右），startDelay ≈ 4 \xd7 0.375 ≈ 1.5 秒。

## 输出格式
只返回 JSON，不附解释。rows 返回完整四列，changes 的 row 从 1 开始，结构建议可为 null；field 只取下面合同已有值。
{
  "rows": [修正后的完整四字段数组（行数与输入完全一致，不得增删合并）],
  "changes": [
    {
      "row": 原始行号（从 1 开始；structure 类建议可为 null），
      "field": "speech" 或 "board" 或 "board_timing" 或 "actionSpec" 或 "action_timing" 或 "answer_error" 或 "common_mistake" 或 "structure",
      "before": "修改前的内容",
      "after": "修改后的内容",
      "reason": "修正原因（起笔校准类写清：口播念到关键词'…'（约第 X 字）时动笔，换算延迟约 +Y.Ys）"
    }
  ]
}
没有问题也原样返回完整 rows，changes 写 []。structure、answer_error 只报告建议或数学问题，不改变行数与答案。
`;var s=e.i(12161),n=e.i(305102);let l=Object.freeze({FRAC_SCALE:1,FRAC_MARGIN:.28,FRAC_STACK_Y:.28,FRAC_GAP:.1,DIV_STEP:.5,DIV_GAP:.06,DIV_DOT_TOP_UP:-.51,DIV_DOT_TOP_DOWN:-.165,DIV_DOT_LEFT:.125,DASH_CLOSE_STEP:.775,DASH_CLOSE_DOM:-.173,DOT_SCALE:1.57,DOT_STACK_Y:.349}),i=[[/[\u2192\u21A0\u27F6\u2199\u2190\u27F5]/g,"->"],[/\u21D2/g,"=>"],[/\u2194/g,"<->"],[/\u2264/g,"<="],[/\u2265/g,">="],[/\u2260/g,"!="],[/\u2248/g,"约"],[/\u2261/g,"恒等于"],[/[\u00D7\u2715\u2716\u2717]/g,"x"],[/\u2022|\u2219/g,"·"],[/\u00F7/g,".-."],[/\u2215/g,".-."],[/\u2212/g,"-"],[/\u00B1/g,"+-"],[/\u221A/g,"根号"],[/\u00B0/g,"度"],[/\u2103/g,"摄氏度"],[/\u2030/g,"千分之"],[/\u2220/g,"角"],[/\u22A5/g,"垂直"],[/[\u2225\u2016]/g,"//"],[/\u03C0/g,"圆周率"],[/\u221E/g,"无穷"],[/\u2234/g,"因此"],[/\u2235/g,"因为"],[/\u2208/g,"属于"],[/\u222A/g,"并"],[/\u2229/g,"交"],[/[\u2013\u2012\u2015]/g,"—"],[/_+/g,e=>e.length>3?"——":"-"],[/[\uFF5E\u301C]/g,"~"],[/\uFF5C/g,"|"],[/\u300E/g,"「"],[/\u300F/g,"」"]],g=[[/\\rightarrow\b/g,"->"],[/\\Rightarrow\b/g,"=>"],[/\\to\b/g,"->"],[/\\times(?![a-zA-Z])/g,"x"],[/\\div(?![a-zA-Z])/g,".-."],[/\\cdot(?![a-zA-Z])/g,"·"],[/\^\s*(?:\{\s*\\circ\s*\}|\\circ)/g,"度"],[/\\circ\b/g,"度"],[/\\degree\b/g,"度"],[/\^\s*(?:\{\s*2\s*\}|2)/g,"²"],[/\^\s*(?:\{\s*3\s*\}|3)/g,"³"],[/\\angle\b/g,"角"],[/\\pm\b/g,"+-"],[/\\perp\b/g,"垂直"],[/\\parallel\b/g,"//"],[/\\triangle\b/g,"三角形"],[/\\therefore\b/g,"因此"],[/\\because\b/g,"因为"],[/\\le(?:q)?\b/g,"<="],[/\\ge(?:q)?\b/g,">="],[/\\ne(?:q)?\b/g,"!="],[/\\approx\b/g,"约"],[/\\pi\b/g,"圆周率"],[/\\infty\b/g,"无穷"],[/\\sqrt\s*\{([^}]*)\}/g,"根号$1"],[/\\sqrt\b/g,"根号"]],u=new Set(["！","（","）","，","：","；","？"]);l.DIV_DOT_LEFT,l.DIV_DOT_TOP_UP,l.DIV_DOT_LEFT,l.DIV_DOT_TOP_DOWN,l.DOT_SCALE,(-l.DOT_STACK_Y/l.DOT_SCALE-.011).toFixed(4);let c=60/n.F;function d(e){if(!e||"string"!=typeof e)return"";let r,t=String(null==e?"":e);for(let[e,r]of(t=(t=(t=(t=(t=(t=(t=(t=(t=t.replace(/\r\n|\r/g,"\n")).replace(/\\r\\n/g,"\n").replace(/\\n(?!(?:eq|ot|abla|otin|e\b|[a-zA-Z]\b))/g,"\n")).replace(/[\t\u0008\u000B\u000C]+/g," ")).replace(/&times;/g,"×").replace(/&divide;/g,"÷").replace(/&minus;/g,"−").replace(/&plusmn;/g,"±").replace(/&deg;/g,"°").replace(/&le;/g,"≤").replace(/&ge;/g,"≥").replace(/&ne;/g,"≠").replace(/&middot;/g,"·").replace(/&mdash;/g,"—").replace(/&hellip;/g,"…").replace(/&sup2;/g,"²").replace(/&sup3;/g,"³").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,"&")).replace(/\u000c\s*rac/g,"\\frac").replace(/(^|[^\w\\])rac(?=\s*\{)/g,"$1\\frac").replace(/(^|[^\w\\])frac(?=\s*\{)/g,"$1\\frac")).replace(/<br\s*\/?>/gi,"\n").replace(/<\/?(?:b|i|u|em|strong|span|div|p|sub|sup|font|bold)\b[^>]*>/gi,"")).replace(/\\(?:begin|end)\s*\{[^}]*\}/g,"").replace(/\\\\/g,"\n").replace(/\\\(|\\\)/g,"").replace(/\\\[|\\\]/g,"").replace(/(^|\n)\s*&\s*(?==)/gm,"$1").replace(/\s*&\s*(?==)/g,"")).replace(/\$+/g,"").replace(/\\left\b|\\right\b/g,"")).replace(/[\uFF01-\uFF5E]/g,e=>u.has(e)?e:String.fromCharCode(e.charCodeAt(0)-65248)),i))t=t.replace(e,r);for(let[e,r]of g)t=t.replace(e,r);t=(t=t.replace(/(\w|\))\^2\b/g,"$1²").replace(/(\w|\))\^3\b/g,"$1³")).replace(/(^|[^\w.])(?<!\.)(\d+)\s*\/\s*(\d+)(?!\.)(?=$|[^\w.]|[A-Za-z])/g,"$1\\frac{$2}{$3}");do r=t,t=(t=t.replace(/(\d)[ \t]*(-{2,})[ \t]*(?=\d)/g,(e,r,t)=>r+(t.length>3?"——":"-"))).replace(/(?<=\S) +(?=[+\-*x=<>!%./()—·])|(?<=\S[+\-*x=<>!%./()—·]) +/g,"");while(t!==r)let a=(t.match(/^\s*/)||[""])[0],o=t.slice(a.length).replace(/[\t ]+/g," ").replace(/\s+$/,"");return(t=a+o).replace(/\n{3,}/g,"\n\n")}function p(e,r,t){if("题目"===t||!r||!r.trim())return 0;let a=String(e||"").trim();if(!a)return 0;let o=-1;for(let e of[/写下/,/列出/,/列式/,/写成/,/记作/,/公式是/,/关系是/,/算式是/,/等于/,/算出来/,/算得/,/得出/,/得到/,/也就是/,/计算得到/,/代入/,/先算/,/再算/,/可以写成/,/设/]){let r=e.exec(a);r&&r.index>0&&(-1===o||r.index<o)&&(o=r.index)}if(-1===o){let e=r.match(/\b\d+(?:\.\d+)?\b/g);if(e&&e.length)for(let r of e){let e=a.indexOf(r);e>2&&(-1===o||e<o)&&(o=e)}}return o>2?Math.min(20,Math.max(.5,Number((o*c).toFixed(1)))):1}function f(e){if(!Array.isArray(e))return{rows:[],changes:[]};let r=[];return{rows:e.map((e,t)=>{let a=t+1,o=e?.stage||"",n=String(e?.speech||""),l=n&&"string"==typeof n?(0,s.f)(n):"";n!==l&&r.push({row:a,field:"speech",before:n,after:l,reason:"ASR 口播纯文字优化：转换数学符号为自然中文读法、规范小数与分数读音"});let i=e?.board,g=i;if("string"==typeof i){let e=d(i);e!==i&&r.push({row:a,field:"board",before:i,after:e,reason:"板书符号规范化：乘法统一为小写 x，规范分数与公式"});let t=p(l,e,o);t>0&&r.push({row:a,field:"board_timing",before:"+0.0s (开播即显)",after:`+${t.toFixed(1)}s`,reason:`语义校准板书时机：结合口播关键词换算延迟约 +${t.toFixed(1)}s 落笔，避免提前剧透并保证音画同步`}),g={content:e,startDelay:t}}else if(i&&"object"==typeof i){let e=String(i.content||""),t=d(e);e!==t&&r.push({row:a,field:"board",before:e,after:t,reason:"板书符号规范化：乘法统一为小写 x，规范分数与公式"});let s=i.startDelay;if("number"==typeof s&&s>0);else if(t&&"题目"!==o){let e=p(l,t,o);e>0&&(!s||0===s)&&(r.push({row:a,field:"board_timing",before:"+0.0s (开播即显)",after:`+${e.toFixed(1)}s`,reason:`语义校准板书时机：结合口播关键词换算延迟约 +${e.toFixed(1)}s 落笔，避免提前剧透并保证音画同步`}),s=e)}g={content:t,startDelay:void 0!==s?s:0}}let u={};return"string"==typeof e?.audioUrl&&""!==e.audioUrl&&(u.audioUrl=e.audioUrl),Number(e?.audioDurationMs)>0&&(u.audioDurationMs=Math.round(Number(e.audioDurationMs)),u.duration=e.duration),{stage:o,speech:l,board:g,actionSpec:Array.isArray(e?.actionSpec)?e.actionSpec:[],...u}}),changes:r}}var h=e.i(724492),b=e.i(891362),m=e.i(272619),y=e.i(194578),w=e.i(595735);function S(e){if(e&&"object"==typeof e&&("startDelay"in e||"content"in e)){let r=Number.isFinite(Number(e.startDelay))?`+${Number(e.startDelay).toFixed(1)}s`:"+0.0s";return`落笔起手 ${r} \xb7 内容: ${e.content||"（无）"}`}return"string"==typeof e?e:JSON.stringify(e??"")}let x=new Set(["speech","board","board_timing","actionSpec","action_timing","answer_error","common_mistake","structure"]);async function A(e,a){if((0,m.E)(e,a))return!0;if("POST"!==e.method)return!1;let s=null;try{let n,l,i,g=await (0,m.r)(e);if(Array.isArray(g.currentRows)&&g.currentRows.length)s=g.currentRows;else{let e=(0,h.J)();s=e?.result?.rows}if(!Array.isArray(s)||!s.length)return(0,m.a)(e,a,400,{ok:!1,error:"没有可检查的 Agent B 生成内容，请先生成"});if("asr_fast"===g.mode||!g.apiKey||!g.endpoint||!g.model){let r=f(s);return(0,m.a)(e,a,200,{ok:!0,checkStatus:"local_asr_polished",model:"local-asr-engine",rows:r.rows,changes:r.changes,usage:null})}try{n=(0,m.g)(g)}catch{let r=f(s);return(0,m.a)(e,a,200,{ok:!0,checkStatus:"local_asr_polished",model:"local-asr-engine",rows:r.rows,changes:r.changes,usage:null})}let u=(0,b.h)()?.handoff||(0,h.J)()?.result?.handoff,c=u?.boardPlan||null,d=u?.problemText||"",p=u?.knowledgeAnalysis||{},A=Array.isArray(p?.commonMistakes)?[...p.commonMistakes]:[],_=p?.teachingFocus||"",D=Array.isArray(p?.keyFormulaList)?p.keyFormulaList:[];if(0===A.length&&u?.knowledgeBasePath)try{let e=t.default.resolve(process.cwd(),u.knowledgeBasePath);if(r.default.existsSync(e)){let t=r.default.readFileSync(e,"utf8"),a=JSON.parse(t),o=(Array.isArray(a?.rows)?a.rows:[]).find(e=>{let r=e.k||e.knowledgePoint||"";return r&&(d.includes(r)||u.problemType&&String(u.problemType).includes(r))});o&&Array.isArray(o.m)&&(A=o.m)}}catch(e){}let k=[{type:"text",text:`【坐标输出模式】
percentage`},{type:"text",text:`【参考 boardPlan】
${JSON.stringify(c,null,2)}

（仅用于理解 stage 区域与动作边界；板书文字由真实渲染层自然排版，不修改 stage 顺序）`},{type:"text",text:function(e){let r=e&&"object"==typeof e&&!Array.isArray(e)?e.suggestedRatio:null;if(!r||"object"!=typeof r||Array.isArray(r))return"【本题环节配比占比 (stageRatioSuggestion)】\n未提供（不影响任何检查——行数与配比由 Agent B 自主决定，Check 不做行数核对）。";let t=(e,r)=>`- ${e}：${String(r??"")||"未提供"}`,a=[e.cuCode,e.type].filter(Boolean).join(" · ")||"未提供";return`【本题环节配比占比 (stageRatioSuggestion)】（仅作理解本题结构的背景参考）
- 题型：${a}（置信度：${e.confidence||"未提供"}）
`+t("分析 (analysis)",r.analysis)+"\n"+t("解答 (solution)",r.solution)+"\n"+t("总结 (summary)",r.summary)+"\n"+t("开收场 (introAndClosing)",r.introAndClosing)+"\n注意：行数与各 stage 行数配比由 Agent B 自主决定，你不得以此数据为依据核对、合并或删除任何行（含收尾金句行）。"}(u?.stageRatioSuggestion||u?.["环节配比占比"]||null)},{type:"text",text:`【本题题干与易错点清单 (commonMistakes) 把关指南】
- 题目原文：${d||"（以原步骤第一行题目为准）"}
- 教学重点(teachingFocus)：${_||"未提供"}
- 关键公式(keyFormulaList)：${JSON.stringify(D)}
- 易错点清单(commonMistakes)：${A.length>0?JSON.stringify(A):"未提供（知识库亦无匹配，跳过针对性防坑核验，仅做通用数学正确性与口播质量检查）"}

【修缮把关硬性要求】：
1. 检查口播中是否在易错步骤顺嘴做出了启发式防坑提醒（例如“这里行不行呀？”、“注意单位统一了没有”）。
2. 严密排查老师自身的推导与算式是否踩了上述易错坑！若老师自己算错，在 changes 数组中作为 answer_error 报警并详细说明原因！`},{type:"text",text:`【当前 B 生成结果四字段】
${JSON.stringify(s,null,2)}`}];try{let e=await (0,m.n)({...n,timeoutMs:25e3,body:{temperature:.3,stream:!1,response_format:{type:"json_object"},messages:[{role:"system",content:o},{role:"user",content:k}]}});l=e.response,i=e.data}catch(t){let r=f(s);return(0,m.a)(e,a,200,{ok:!0,checkStatus:"local_asr_polished",model:n.model,rows:r.rows,changes:r.changes,note:`大模型响应超时（已自动触发本地 ASR 优化引擎）：${t?.message||"超时"}`,usage:null})}if(!l.ok){let r=f(s);return(0,m.a)(e,a,200,{ok:!0,checkStatus:"local_asr_polished",model:n.model,rows:r.rows,changes:r.changes,note:`上游模型接口返回 ${l.status}，已自动采用本地 ASR 规范引擎润色`,usage:null})}let $=(0,m.k)(i?.choices?.[0]?.message),F=function(e,r){let t=(0,y.f)(e);if(!t||"object"!=typeof t||Array.isArray(t))return{ok:!1,error:"返回内容不是 JSON 对象"};if(!Array.isArray(t.rows)||!t.rows.length)return{ok:!1,error:"返回的 rows 为空"};if(t.rows.length!==r.length)return{ok:!1,error:`Check 无删行权限：输入 ${r.length} 行，返回 ${t.rows.length} 行（行数守恒硬约束——行数与配比由 Agent B 自主决定，收尾金句不可删；如确需合并请由用户在 changes 报告建议下手动操作）`};let a=r.map(e=>e.stage),o=t.rows.map(e=>e.stage),s=0;for(let e of o){for(;s<a.length&&a[s]!==e;)s++;if(s>=a.length)return{ok:!1,error:`stage 顺序被打乱或出现了未知 stage：${e}`};s++}let n=t.rows.map((e,t)=>{let a=r[t]||{},o="string"==typeof a.audioUrl&&""!==a.audioUrl;return{stage:e?.stage||"",speech:"string"==typeof e?.speech?e.speech:"",board:e?.board!==void 0&&e?.board!==null?(0,w.I)(e.board):"",actionSpec:Array.isArray(e?.actionSpec)?(0,w.S)(e.actionSpec):[],...o?{audioUrl:a.audioUrl}:{},...Number(a.audioDurationMs)>0?{audioDurationMs:Math.round(Number(a.audioDurationMs)),duration:a.duration}:{}}}),l=(Array.isArray(t.changes)?t.changes:[]).map(e=>({row:Number.isFinite(Number(e?.row))?Math.max(1,Math.round(Number(e.row))):null,field:String(e?.field||"").trim(),before:e?.before!==void 0?String(e.before):"",after:e?.after!==void 0?String(e.after):"",reason:String(e?.reason||"").trim()})).filter(e=>x.has(e.field)&&e.reason),i=[];for(let e of l)i.push(e);let g=new Set(l.filter(e=>null!==e.row&&"answer_error"!==e.field).map(e=>`${e.row}:${"board_timing"===e.field?"board":e.field}`)),u=Math.min(r.length,n.length);for(let e=0;e<u;e++){let t=r[e],a=n[e];for(let r of["speech","board","actionSpec"]){let o=`${e+1}:${r}`;if(g.has(o))continue;let s=t?.[r],n=a?.[r];if(JSON.stringify(s)!==JSON.stringify(n)){let t="board"===r&&s?.content===n?.content&&s?.startDelay!==n?.startDelay;i.push({row:e+1,field:t?"board_timing":r,before:t?`+${Number(s?.startDelay||0).toFixed(1)}s`:S(s),after:t?`+${Number(n?.startDelay||0).toFixed(1)}s`:S(n),reason:t?`校准板书时机：落笔起手延迟调整为 +${Number(n?.startDelay||0).toFixed(1)}s`:"内容优化（模型未标注原因）"})}}}return{ok:!0,value:{rows:n,changes:i}}}($,s);if(!F.ok){let r=f(s);return(0,m.a)(e,a,200,{ok:!0,checkStatus:"local_asr_polished",model:n.model,rows:r.rows,changes:r.changes,usage:i?.usage||null})}let T=f(F.value.rows),O=[...F.value.changes];return T.changes.forEach(e=>{O.some(r=>r.row===e.row&&r.field===e.field)||O.push(e)}),(0,m.a)(e,a,200,{ok:!0,model:n.model,rows:T.rows,changes:O,usage:i?.usage||null})}catch(r){if(Array.isArray(s)&&s.length){let r=f(s);return(0,m.a)(e,a,200,{ok:!0,checkStatus:"local_asr_polished",model:"local-asr-engine",rows:r.rows,changes:r.changes,usage:null})}return(0,m.a)(e,a,500,{ok:!1,error:r?.message||String(r)})}}async function _(e,r){if((0,m.E)(e,r))return!0;if("POST"!==e.method)return!1;try{let t=(await (0,m.r)(e)).rows;if(!Array.isArray(t)||!t.length)return(0,m.a)(e,r,400,{ok:!1,error:"缺少 rows 参数"});let a=(0,h.J)();if(!a)return(0,m.a)(e,r,400,{ok:!1,error:"没有找到当前 B 生成结果"});let o={...a.result,rows:t,checkedAt:new Date().toISOString()},{filename:s}=(0,h.e)(o);return(0,m.a)(e,r,200,{ok:!0,filename:s,rows:t})}catch(t){return(0,m.a)(e,r,500,{ok:!1,error:t?.message||String(t)})}}e.s(["L",0,A,"M",0,_],245862)}];

//# sourceMappingURL=server_checkAgentHandler_0oz2nluo6cvlt.js.map