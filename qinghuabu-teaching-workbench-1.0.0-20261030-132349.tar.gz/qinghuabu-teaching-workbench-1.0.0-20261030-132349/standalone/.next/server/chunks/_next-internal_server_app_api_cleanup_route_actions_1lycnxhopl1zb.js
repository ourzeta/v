module.exports=[806158,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cleanup_route_actions_1lycnxhopl1zb.js.map