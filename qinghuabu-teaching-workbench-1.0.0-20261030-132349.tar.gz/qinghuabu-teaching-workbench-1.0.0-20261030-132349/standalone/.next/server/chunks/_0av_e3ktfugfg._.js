(()=>{"use strict";module.exports=[210993,e=>{var t=e.i(747909),r=e.i(174017),a=e.i(996250),n=e.i(759756),o=e.i(561916),i=e.i(174677),s=e.i(869741),l=e.i(316795),u=e.i(487718),d=e.i(995169),c=e.i(47587),f=e.i(666012),p=e.i(570101),h=e.i(626937),m=e.i(10372),g=e.i(193695),w=e.i(509580);e.i(52474);var y=e.i(600220);let v=new t.AppRouteRouteModule({definition:{kind:r.f.APP_ROUTE,page:"/api/knowledge/[action]/route",pathname:"/api/knowledge/[action]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/knowledge/[action]/route.ts",nextConfigOutput:"standalone",userland:()=>e.r(627331),...{}}),{workAsyncStorage:k,workUnitAsyncStorage:A,serverHooks:b}=v;async function R(e,t,r){r.requestMeta&&(0,n.R)(e,r.requestMeta),v.isDev&&(0,n.i)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/knowledge/[action]/route";a=a.replace(/\/index$/,"")||"/";let{instrumentation:i}=await v.ensureInstrumentation(e,{deferSpans:!0});return v.traceRequest(e,{tracer:(0,o.v)(),spanName:`${e.method||"GET"} ${a}`,httpTarget:e.url,instrumentation:i},(n,o)=>x(e,t,r,a,!1,n,o))}async function x(e,t,a,k,A,b,R){let x=await v.prepare(e,t,{srcPage:k,multiZoneDraftMode:A});if(!x)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:E,deploymentId:O,params:S,nextConfig:T,parsedUrl:C,isDraftMode:P,prerenderManifest:U,routerServerContext:N,isOnDemandRevalidate:M,revalidateOnlyGenerated:j,resolvedPathname:I,clientReferenceManifest:$,serverActionsManifest:_,previewProps:q}=x,H=(0,s.f)(k),L=!!U.routes[I]&&(v.isDev||(0,w.f)(I,v.cacheOwner,U.routes[I])),F=!!(U.dynamicRoutes[H]||L),D=async()=>((null==N?void 0:N.render404)?await N.render404(e,t,C,!1):t.end("This page could not be found"),null);if(F&&!P){let e=U.dynamicRoutes[H];if(e&&!1===e.fallback&&!L){if(T.adapterPath)return await D();throw new g.NoFallbackError}}let J=null;!F||v.isDev||P||(J="/index"===(J=I)?"/":J),_&&$&&(0,i.f)({page:k,clientReferenceManifest:$,serverActionsManifest:_});let G=e.method||"GET",B=(0,o.v)(),K=!!(null==N?void 0:N.isWrappedByNextServer),Q=!!(0,n.w)(e,"minimalMode"),V=(0,n.w)(e,"incrementalCache")||await v.getIncrementalCache(e,T,q,U,Q);null==V||V.resetRequestCache(),globalThis.__incrementalCache=V;let W={params:S,previewProps:q,renderOpts:{experimental:{authInterrupts:!!T.experimental.authInterrupts,useCacheTimeout:T.experimental.useCacheTimeout,durableUseCacheEntries:!!T.experimental.durableUseCacheEntries},cacheComponents:!!T.cacheComponents,validationLevel:T.experimental.instantInsights.validationLevel,isDraftMode:P,incrementalCache:V,hmrRefreshHash:(0,n.w)(e,"hmrRefreshHash"),cacheLifeProfiles:T.cacheLife,staticPageGenerationTimeout:T.staticPageGenerationTimeout,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0},sharedContext:{buildId:E,deploymentId:O}},z=new l.x(e),X=new l.e(t),Y=u.k.fromNodeNextRequest(z,(0,u.t)(t)),Z=async({previousCacheEntry:r})=>{try{if(!Q&&M&&j&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=null===J?await v.handle(Y,W):await v.prerender(Y,W);e.fetchMetrics=W.renderOpts.fetchMetrics;let o=W.renderOpts.pendingWaitUntil;o&&a.waitUntil&&(a.waitUntil(o),o=void 0);let i=W.renderOpts.collectedTags;if(!F)return await (0,f.f)(z,X,n,o),null;{let e=await n.blob(),t=(0,p.S)(n.headers);i&&(t[m.M]=i),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==W.renderOpts.collectedRevalidate&&!(W.renderOpts.collectedRevalidate>=m.Q)&&W.renderOpts.collectedRevalidate,a=void 0===W.renderOpts.collectedExpire||W.renderOpts.collectedExpire>=m.Q?!1!==r&&r>0?T.expireTime:void 0:W.renderOpts.collectedExpire;return{value:{kind:y.x.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await v.onRequestError(e,t,{routerKind:"App Router",routePath:k,routeType:"route",revalidateReason:(0,c.f)({isStaticGeneration:null!==J,isOnDemandRevalidate:M})},!1,N),t}},ee=async n=>{try{var i,s;let n=await v.handleResponse({req:e,nextConfig:T,cacheKey:J,routeKind:r.f.APP_ROUTE,isFallback:!1,previewProps:q,prerenderManifest:U,isRoutePPREnabled:!1,isOnDemandRevalidate:M,revalidateOnlyGenerated:j,responseGenerator:Z,waitUntil:a.waitUntil,isMinimalMode:Q});if(null!==n&&"error"in n)throw n.error;if(!F)return;if((null==n||null==(i=n.value)?void 0:i.kind)!==y.x.APP_ROUTE)throw Error(`Invariant: app-route received invalid cache entry ${null==n||null==(s=n.value)?void 0:s.kind}`);Q||t.setHeader("x-nextjs-cache",M?"REVALIDATED":n.isMiss?"MISS":n.isStale?"STALE":"HIT"),P&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let o=(0,p.G)(n.value.headers);Q&&F||o.delete(m.M),!n.cacheControl||t.getHeader("Cache-Control")||o.get("Cache-Control")||o.set("Cache-Control",(0,h.f)(n.cacheControl)),await (0,f.f)(z,X,new Response(n.value.body,{headers:o,status:n.value.status||200}));return}catch(r){if(r instanceof g.NoFallbackError||await v.onRequestError(e,r,{routerKind:"App Router",routePath:H,routeType:"route",revalidateReason:(0,c.f)({isStaticGeneration:null!==J,isOnDemandRevalidate:M})},!1,N),F)throw r;if(t.headersSent){if(n){let e=r instanceof Error?r:Error("Unknown app route error");n.recordException(e),n.setStatus({code:o.J.ERROR,message:e.message}),n.setAttribute("error.type",e.name)}t.writableEnded||t.destroyed||t.end()}else await (0,f.f)(z,X,new Response(null,{status:500}));return}finally{(()=>{if(!n)return;let e=t.statusCode;n.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(n.setStatus({code:o.J.ERROR}),n.setAttribute("error.type",e.toString()));let r=B.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==d.q.handleRequest)return console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route")||H,i=`${G} ${a}`;n.setAttributes({"next.route":a,"http.route":a,"next.span_name":i}),n.updateName(i),R&&R!==n&&(R.setAttribute("http.route",a),R.updateName(i))})()}};K||void 0===e.url||null==b||b.setAttribute("http.target",e.url),await ee(b)}e.s(["handler",0,R,"patchFetch",0,function(){return(0,a.f)({workAsyncStorage:k,workUnitAsyncStorage:A})},"routeModule",0,v,"serverHooks",0,b,"workAsyncStorage",0,k,"workUnitAsyncStorage",0,A])},627331,e=>{var t=e.i(935898);let r=`
你是一位小学数学教研老师，专门负责"把题目里真正用到的知识点和公式说清楚、说准确"。

你的任务：拿到一份 Agent A 生成的 handoff JSON，修缮其中的知识点相关字段。其他字段原样保留，不要动。

如果下方提供了【参考知识库】，请优先参考其中的知识点表述和公式；如果没有，就根据题目自己判断。

## 需要修缮的字段

### 1. relatedKnowledge — 本题涉及的知识点清单
- 必须细到"具体公式/具体原理"的程度，不能只写"应用题""几何题"这种大类
- 每个知识点说清楚：叫什么、内容是什么、在这道题里怎么用
- 必须包含所有会用到的公式（包括中间步骤会用到的）
- **格式：数组，保持输入时的每项结构不变**（输入是中文字段对象就继续输出同字段对象，输入是字符串就继续输出字符串），只精炼字段内容，不要增删字段、不要把对象改写成字符串或反之
- 对象示例：{ "知识点": "总价公式", "考点": "总价=单价x数量", "策略方法": "先分别算各段费用，再求和", "总结归纳": "分段计费先分段后求和" }
- 字符串示例："路程公式：s=vt，路程等于速度乘时间"

### 2. knowledgeAnalysis.teachingFocus — 教学重点
- 用一句话说清这道题最核心要教会孩子什么
- 例如："掌握分段计费的解题思路，先分段算再相加"

### 3. knowledgeAnalysis.keyFormulaList — 关键公式清单
- 格式：字符串数组
- 只写公式本身，例如：\`["s=vt", "总价=单价x数量", "时间=路程/速度"]\`
- Agent B 会把这些公式随手记在分析区 board 上

### 4. knowledgeAnalysis.formulaHints — 公式提示（给 B 看的重要）
- 格式：字符串数组
- 列出解题过程中**可能用到**的所有小学数学定理和公式
- 每个提示说清楚：公式名 + 公式内容 + 在什么情况下用
- Agent B 看到这些提示后，会在分析区解题时把公式写出来
- 例如：
  - "路程公式：s=vt，已知速度和时间求路程时用"
  - "时间公式：t=s/v，已知路程和速度求时间时用"
  - "长方形面积：S=ab，长乘宽"
  - "正方形周长：C=4a，边长乘4"

### 5. knowledgeAnalysis.commonMistakes — 易错点清单
- 位置在 knowledgeAnalysis 内部（不是顶层独立字段）
- 格式：字符串数组
- 列出这道题孩子最容易犯的 2-4 个错误
- 例如：\`["忘记分段，直接用最高单价算全部", "搞混标准量和超标量"]\`

## 严格规则

- **只改知识点相关字段**：relatedKnowledge、knowledgeAnalysis（teachingFocus/keyFormulaList/formulaHints/commonMistakes）
- **其他字段原样保留**：problemText、problemType、boardPlan、coordinateSpec、zoneAnchors 等一律不动，一字不改；relatedKnowledge 每项的键结构保持不变
- **必须基于题目原文**：知识点必须是这道题真实会用到的，不能为了凑数加无关内容
- **宁少勿滥**：不确定的知识点不要瞎加
- **输出完整 JSON**：和输入结构一样，只是知识点字段更准了

## 输入输出

输入：一整个 handoff JSON 对象，可能附带参考知识库
输出：修缮后的完整 handoff JSON 对象

只输出 JSON，不要任何解释、Markdown 或额外文字。
`;var a=e.i(891362),n=e.i(272619),o=e.i(194578);let i=["relatedKnowledge"],s=["teachingFocus","keyFormulaList","formulaHints","commonMistakes"];function l(e,t){if(!t||"object"!=typeof t)return e;let r={...e};for(let e of i)void 0!==t[e]&&(r[e]=t[e]);if(t.knowledgeAnalysis&&"object"==typeof t.knowledgeAnalysis)for(let a of(r.knowledgeAnalysis={...e.knowledgeAnalysis||{}},s))void 0!==t.knowledgeAnalysis[a]&&(r.knowledgeAnalysis[a]=t.knowledgeAnalysis[a]);return r}async function u(e,t){if((0,n.E)(e,t))return!0;let i=new URL(e.url,"http://localhost").pathname;if("/refine"!==i&&"/apply"!==i||"POST"!==e.method)return!1;if("/apply"===i)try{let r=await (0,n.r)(e),o=r?.handoff;if(!o||"object"!=typeof o)return(0,n.a)(e,t,400,{ok:!1,error:"缺少修缮提案 handoff"});let i=(0,a.h)();if(!i?.handoff||"object"!=typeof i.handoff)return(0,n.a)(e,t,400,{ok:!1,error:"没有找到 handoff 存档，请先生成"});let s=l(i.handoff,o),u=(0,a.o)(s);return(0,n.a)(e,t,200,{ok:!0,filename:u,handoff:s})}catch(r){return(0,n.a)(e,t,500,{ok:!1,error:r?.message||String(r)})}try{var s;let i,u=await (0,n.r)(e);try{i=(0,n.g)(u)}catch(r){return(0,n.a)(e,t,400,{ok:!1,error:r.message})}let d=(0,a.h)(),c=d?.handoff;if(!c||"object"!=typeof c)return(0,n.a)(e,t,400,{ok:!1,error:"没有找到 handoff 存档，请先生成"});let f=[{type:"text",text:`【输入 handoff】
${JSON.stringify(c,null,2)}

请修缮其中的知识点相关字段，其他字段原样保留。输出完整的 JSON。`}],{response:p,data:h}=await (0,n.n)({...i,timeoutMs:6e4,retryOnAbort:!1,body:{temperature:Number(u.temperature??.3),stream:!1,response_format:{type:"json_object"},messages:[{role:"system",content:r},{role:"user",content:f}]}});if(!p.ok){let r=h?.error?.message||h?.message||`上游失败 ${p.status}`,a=/Unknown name .{0,2}(messages|response_format|stream|temperature).{0,2}/i.test(String(r));return(0,n.a)(e,t,200,{ok:!0,model:i.model,filename:d.filename,handoff:c,refineOk:!1,usage:null,warning:a?"上游中转站该模型为 Gemini 原生协议直通，不认 OpenAI 格式字段；已保留原知识库，请换有协议转换的接口地址或模型后重试":`上游模型接口返回 ${p.status}（${r}），已保留原知识库，可重试`})}let m=(s=(0,n.k)(h?.choices?.[0]?.message),(0,o.f)(s));m?.handoff&&"object"==typeof m.handoff&&(m=m.handoff);let g=l(c,m),w=!!m;return(0,n.a)(e,t,200,{ok:!0,model:i.model,filename:d.filename,handoff:g,usage:h?.usage||null,refineOk:w,...w?{}:{warning:"AI 这次没返回标准格式，已保留原内容，可重试"}})}catch(a){let r=a?.name==="AbortError"?504:500;return(0,n.a)(e,t,r,{ok:!1,error:a?.name==="AbortError"?"上游超时（60 秒）":a?.message||String(a)})}}async function d(e,{params:r}){let{action:a}=await r;return(0,t.f)(e,(e,t)=>u(e,t),{urlPath:`/${a}`})}async function c(e,{params:r}){let{action:a}=await r;return(0,t.f)(e,(e,t)=>u(e,t),{urlPath:`/${a}`})}e.s(["OPTIONS",0,c,"POST",0,d,"dynamic",0,"force-dynamic"],627331)}]})();

//# sourceMappingURL=_0av_e3ktfugfg._.js.map