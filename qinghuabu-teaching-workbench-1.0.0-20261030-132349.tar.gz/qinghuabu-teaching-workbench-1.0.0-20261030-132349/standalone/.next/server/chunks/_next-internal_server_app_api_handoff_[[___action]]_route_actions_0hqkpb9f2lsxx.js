module.exports=[671703,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_handoff_%5B%5B___action%5D%5D_route_actions_0hqkpb9f2lsxx.js.map