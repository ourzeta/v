module.exports=[485787,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_knowledge_%5Baction%5D_route_actions_0vw2zgxzsv79a.js.map