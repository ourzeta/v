module.exports=[370208,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_handoff_%5Bname%5D_route_actions_17ezt4qhozpr9.js.map