self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [
      {
        "source": "/audio-cache/:path*",
        "destination": "/api/asset/audio-cache/:path*"
      },
      {
        "source": "/audio/:path*",
        "destination": "/api/asset/audio/:path*"
      },
      {
        "source": "/pic/:path*",
        "destination": "/api/asset/pic/:path*"
      },
      {
        "source": "/board-result/:path*",
        "destination": "/api/asset/board-result/:path*"
      }
    ],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()