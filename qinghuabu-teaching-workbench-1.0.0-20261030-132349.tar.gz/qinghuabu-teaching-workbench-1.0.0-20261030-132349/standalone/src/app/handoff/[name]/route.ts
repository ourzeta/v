import { readCurrentHandoff, fullPath, HANDOFF_BASE_DIR } from '@server/handoffStoreHandler.js'
import { existsSync, readFileSync } from 'fs'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /handoff/:name | GET 静态服务 var/handoff | handler: server/handoffStoreHandler.js | 读: var/handoff/*.json | 无外呼
/**
 * GET /handoff/<file>.json — handoff 实体文件静态服务（1:1 移植自 vite 裸中间件）
 * 特例：current.json 返回指针解析后的 handoff 全量内容（而非指针文件本身）
 *
 * ★ KI-034 路径穿越修复（2026-10-30）：
 *   原实现 decodeURIComponent 后直接 fullPath()，无段校验——实测
 *   GET /handoff/..%2F..%2F..%2F..%2F.env 可拖出含密钥的 .env 全文（任意文件读取）。
 *   现与 /api/asset 同款双层防线：①拒绝 .. /分隔符/控制字符段；②resolve 后
 *   强校验必须仍在 var/handoff 之内。
 */

/** 防穿越段校验：拒绝空段/./../斜杠/反斜杠/控制字符（同 /api/asset 口径） */
function isSafeSegment(raw: string): boolean {
  if (!raw || raw === '.' || raw === '..') return false
  if (raw.includes('/') || raw.includes('\\') || raw.includes('\0')) return false
  return true
}

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ name: string }> },
) {
  const { name } = await params
  const cleanName = decodeURIComponent(name || '')
  if (!isSafeSegment(cleanName)) {
    return new Response(JSON.stringify({ ok: false, error: 'Not Found' }), {
      status: 404,
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
    })
  }

  const JSON_HEADERS = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
  }

  if (cleanName === 'current.json') {
    const cur = readCurrentHandoff()
    if (cur?.handoff) {
      return new Response(JSON.stringify(cur.handoff, null, 2), { headers: JSON_HEADERS })
    }
  }

  const filePath = fullPath(cleanName)
  // 二次防线：解析结果必须仍位于 var/handoff 之内（防一切花式逃逸）
  if (!filePath.startsWith(HANDOFF_BASE_DIR + '/')) {
    return new Response(JSON.stringify({ ok: false, error: 'Not Found' }), {
      status: 404,
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
    })
  }
  if (existsSync(filePath)) {
    return new Response(readFileSync(filePath, 'utf-8'), { headers: JSON_HEADERS })
  }

  return new Response(JSON.stringify({ ok: false, error: `Handoff not found: ${cleanName}` }), {
    status: 404,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  })
}
