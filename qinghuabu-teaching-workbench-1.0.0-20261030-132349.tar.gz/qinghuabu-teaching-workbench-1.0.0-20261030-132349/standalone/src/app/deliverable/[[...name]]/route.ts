import { fullPath, DELIVERABLE_BASE_DIR } from '@server/deliverableStoreHandler.js'
import { existsSync, readFileSync } from 'fs'
import { extname, resolve } from 'path'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /deliverable/:name | GET 静态服务 var/deliverable + fonts 回退 | handler: server/deliverableStoreHandler.js | 读: var/deliverable/*, public/fonts | 无外呼
/**
 * GET /deliverable/<file> — 产物静态服务（1:1 移植自 vite '/deliverable' 中间件）
 *   *.json → 命中返回 attachment 下载；未命中返回标准 JSON 404（绝不回退 index.html）
 *   *.html → 命中返回 html；未命中且文件名为 row-player.html 时回退项目内置播放器
 *   *.md   → 命中返回 text/markdown
 * 存储目录：var/deliverable（私有目录，由本路由独占响应，保证与原中间件语义一致）
 *
 * ★ KI-034 路径穿越修复（2026-10-30）：
 *   原实现各段 decodeURIComponent 后 join('/') 直接 fullPath()，无 .. 校验
 *   （讽刺：同文件 fonts/ 分支反而有完整段校验）——实测
 *   GET /deliverable/..%2F..%2Fpackage.json 可拖全仓 json/html/md。
 *   现与 /api/asset 同款双层防线：①逐段拒绝 .. /分隔符/控制字符；②resolve 后
 *   强校验必须仍在 var/deliverable 之内。
 */

/** 防穿越段校验：拒绝空段/./../斜杠/反斜杠/控制字符（同 /api/asset 口径） */
function isSafeSegment(raw: string): boolean {
  if (!raw || raw === '.' || raw === '..') return false
  if (raw.includes('/') || raw.includes('\\') || raw.includes('\0')) return false
  return true
}

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ name?: string[] }> },
) {
  const notFoundJson = (msg: string) =>
    new Response(JSON.stringify({ ok: false, error: msg }), {
      status: 404,
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
    })

  const { name } = await params
  const segments = (name || []).map((seg) => decodeURIComponent(seg))
  // 防穿越第一道：逐段校验（含空段/./../斜杠/反斜杠/控制字符）
  if (segments.some((seg) => !isSafeSegment(seg))) {
    return notFoundJson('Invalid deliverable path')
  }
  const rawName = segments.join('/').replace(
    /^\/+/,
    '',
  )
  const filename = rawName || 'current.html'
  const filePath = fullPath(filename)
  // 防穿越第二道：解析结果必须仍位于 var/deliverable 之内
  if (!filePath.startsWith(DELIVERABLE_BASE_DIR + '/')) {
    return notFoundJson('Invalid deliverable path')
  }

  // 播放器的相对字体路径在交付页下解析为 /deliverable/fonts/*。
  if (filename.startsWith('fonts/')) {
    const segments = filename.slice('fonts/'.length).split('/')
    if (segments.some(segment => !segment || segment === '.' || segment === '..' || /[\\:\0]/.test(segment))) {
      return notFoundJson('Invalid font path')
    }
    const mime: Record<string, string> = {
      '.css': 'text/css; charset=utf-8',
      '.ttf': 'font/ttf',
      '.otf': 'font/otf',
      '.woff': 'font/woff',
      '.woff2': 'font/woff2',
    }
    const contentType = mime[extname(filename).toLowerCase()]
    const fontPath = resolve(process.cwd(), 'public', 'fonts', ...segments)
    if (!contentType || !existsSync(fontPath)) return notFoundJson('Font not found')
    try {
      return new Response(new Uint8Array(readFileSync(fontPath)), {
        status: 200,
        headers: { 'Content-Type': contentType },
      })
    } catch {
      return new Response('Unable to read font', { status: 500 })
    }
  }

  if (filename.endsWith('.json')) {
    if (existsSync(filePath)) {
      try {
        const content = readFileSync(filePath, 'utf-8')
        return new Response(content, {
          status: 200,
          headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Content-Disposition': `attachment; filename="${filename}"`,
          },
        })
      } catch (err) {
        return new Response(
          JSON.stringify({ ok: false, error: 'Read file error: ' + (err as Error).message }),
          { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8' } },
        )
      }
    }
    return notFoundJson(`Deliverable JSON not found: ${filename}`)
  }

  if (filename.endsWith('.html')) {
    if (existsSync(filePath)) {
      try {
        const content = readFileSync(filePath, 'utf-8')
        return new Response(content, {
          status: 200,
          headers: { 'Content-Type': 'text/html; charset=utf-8' },
        })
      } catch (err) {
        return new Response('Read html error: ' + (err as Error).message, {
          status: 500,
          headers: { 'Content-Type': 'text/plain; charset=utf-8' },
        })
      }
    }
    // 回退：/deliverable/row-player.html 未就绪时回退项目 public/row-player.html
    if (filename === 'row-player.html') {
      const publicPlayerPath = resolve(process.cwd(), 'public', 'row-player.html')
      const rootPlayerPath = resolve(process.cwd(), 'row-player.html')
      const fallbackPath = existsSync(publicPlayerPath)
        ? publicPlayerPath
        : existsSync(rootPlayerPath)
          ? rootPlayerPath
          : null
      if (fallbackPath) {
        const content = readFileSync(fallbackPath, 'utf-8')
        return new Response(content, {
          status: 200,
          headers: { 'Content-Type': 'text/html; charset=utf-8' },
        })
      }
    }
  }

  if (filename.endsWith('.md')) {
    if (existsSync(filePath)) {
      try {
        const content = readFileSync(filePath, 'utf-8')
        return new Response(content, {
          status: 200,
          headers: { 'Content-Type': 'text/markdown; charset=utf-8' },
        })
      } catch (err) {
        return new Response('Read markdown error: ' + (err as Error).message, {
          status: 500,
          headers: { 'Content-Type': 'text/plain; charset=utf-8' },
        })
      }
    }
  }

  return notFoundJson(`Deliverable not found: ${filename}`)
}
