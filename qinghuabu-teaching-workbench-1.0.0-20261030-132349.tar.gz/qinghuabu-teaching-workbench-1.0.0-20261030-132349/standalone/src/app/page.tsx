"use client";

/**
 * 工作台主页 — 1:1 复刻原 DirectFlow.vue（step1 ↔ agent-b 二态切换，无路由）
 *
 * 原版逻辑（逐行对应）：
 *   - page = 'step1' → <Step1Entry @enter-board-draft="enterAgentB" />
 *   - page = 'agent-b' → <AgentBDirect :initial-handoff="handoff" @back-to-step1="backToStep1" />
 *   - enterAgentB: 只从实体文件读 —— fetch('/api/handoff')，文件是唯一真相来源
 *   - document.title 随页面切换
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { message } from "antd";
import Step1Entry from "@/components/teaching/Step1Entry";
import AgentBDirect from "@/components/teaching/AgentBDirect";

export default function WorkbenchPage() {
  const [page, setPage] = useState<"step1" | "agent-b">("step1");
  const [handoff, setHandoff] = useState<Record<string, unknown> | null>(null);
  const handoffRef = useRef<Record<string, unknown> | null>(null);

  useEffect(() => {
    handoffRef.current = handoff;
  }, [handoff]);

  useEffect(() => {
    document.title =
      page === "agent-b" ? "生成 · Agent B 五字段" : "教学板书 · 第1步 贴题识别";
  }, [page]);

  const enterAgentB = useCallback(async () => {
    // 只从实体文件读 —— 文件是唯一真相来源
    try {
      const res = await fetch("/api/handoff");
      const data = await res.json();
      if (data.ok && data.handoff) {
        setHandoff(data.handoff);
        setPage("agent-b");
      } else {
        message.error("未找到 handoff 存档，请先在第 1 步确认题目");
      }
    } catch (e) {
      message.error(`读取存档失败：${(e as Error)?.message || String(e)}`);
    }
  }, []);

  const backToStep1 = useCallback(() => {
    setPage("step1");
  }, []);

  return (
    <>
      {page === "step1" ? (
        <Step1Entry onEnterBoardDraft={enterAgentB} />
      ) : (
        <AgentBDirect initialHandoff={handoff} onBackToStep1={backToStep1} />
      )}
    </>
  );
}
