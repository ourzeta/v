import { existsSync, readFileSync, statSync } from "node:fs";
import { extname, join, resolve, sep } from "node:path";

export const dynamic = "force-dynamic";

// [TAG:ROUTE] /api/asset/:path | GET/HEAD 运行期写盘资产实时读盘 | 内联实现(无 handler) | 读: public/{audio-cache,audio,pic,board-result} | 双层防穿越 | 无外呼

/**
 * 动态资产路由 ★ 2026-10-29 音频链路根治修复
 *
 * 问题：Next.js 生产/standalone 模式下，public/ 静态服务只认构建时清单，
 * 运行期由 TTS 等处理器写进 public/audio-cache 的文件永远 404。
 * 实锤：发布域名 POST /api/tts/synthesize 合成成功（文件已落盘），
 * 紧接着 GET /audio-cache/<刚生成的文件> 返回 404。
 *
 * 方案：next.config.ts 把 /audio-cache、/audio、/pic、/board-result 四个
 * 运行期写盘目录 beforeFiles 重写到本路由，由本路由实时读盘返回。
 * URL 形状保持不变（前端播放器、row-player.html、交付 JSON 的
 * 序列化引用与离线 ../audio-cache/ 相对路径契约零改动）。
 *
 * 路径解析与各业务处理器同口径（server/fishAudioHandler.js 等）：
 * 一律以 process.cwd() 为根 —— dev 模式 cwd=项目根、本地 standalone
 * cwd=.next/standalone、发布部署 cwd=next-service-dist，三种形态下
 * 处理器写盘与本路由读盘始终指向同一目录，天然一致。
 */

const ALLOWED_ROOTS = new Set(["audio-cache", "audio", "pic", "board-result"]);

const MIME: Record<string, string> = {
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
  ".m4a": "audio/mp4",
  ".mp4": "video/mp4",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
};

function notFound() {
  return new Response(JSON.stringify({ ok: false, error: "Not Found" }), {
    status: 404,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function prepare(request: Request, segments: string[]) {
  // 防路径穿越：拒绝空段 / . / .. / 反斜杠 / 控制字符
  for (const seg of segments) {
    if (!seg || seg === "." || seg === ".." || seg.includes("\\") || seg.includes("\0") || seg.includes("/")) {
      return null;
    }
  }
  // 首段必须是运行期资产目录白名单
  if (!ALLOWED_ROOTS.has(segments[0])) return null;

  const publicDir = resolve(process.cwd(), "public");
  const filePath = join(publicDir, ...segments);
  // 二次防线：解析结果必须仍位于 public/ 之内
  if (!filePath.startsWith(publicDir + sep)) return null;
  if (!existsSync(filePath)) return null;

  const stat = statSync(filePath);
  if (!stat.isFile()) return null;

  const ext = extname(filePath).toLowerCase();
  const contentType = MIME[ext] || "application/octet-stream";

  // 缓存策略：audio-cache / audio / pic 的文件名为内容哈希或时间戳，
  // 一次写入不再覆写（重合成走 ?v=<ts> 查询参数换 URL），可长缓存；
  // board-result 的 JSON 会被原地覆写，只做协商缓存。
  const isMedia = segments[0] === "audio-cache" || segments[0] === "audio" || segments[0] === "pic";
  const cacheControl = isMedia
    ? "public, max-age=31536000, immutable"
    : "no-cache";

  const total = stat.size;
  const baseHeaders: Record<string, string> = {
    "content-type": contentType,
    "accept-ranges": "bytes",
    "cache-control": cacheControl,
    "last-modified": stat.mtime.toUTCString(),
    etag: `"${stat.size}-${Math.floor(stat.mtimeMs)}"`,
  };

  // Range 请求支持（音频播放器 seek 依赖）
  const rangeHeader = request.headers.get("range");
  if (rangeHeader) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader.trim());
    if (!m) {
      return { status: 416, headers: { "content-range": `bytes */${total}` }, body: null as Buffer | null };
    }
    const start = m[1] === "" ? 0 : parseInt(m[1], 10);
    const end = m[2] === "" ? total - 1 : Math.min(parseInt(m[2], 10), total - 1);
    if (Number.isNaN(start) || Number.isNaN(end) || start > end || start >= total || end >= total) {
      return { status: 416, headers: { "content-range": `bytes */${total}` }, body: null as Buffer | null };
    }
    // 本应用资产均为小文件（音频约 0.1~2MB），整读后切片足够且兼容性最好
    const chunk = readFileSync(filePath).subarray(start, end + 1);
    return {
      status: 206,
      headers: {
        ...baseHeaders,
        "content-range": `bytes ${start}-${end}/${total}`,
        "content-length": String(chunk.length),
      },
      body: chunk,
    };
  }

  const buffer = readFileSync(filePath);
  return {
    status: 200,
    headers: { ...baseHeaders, "content-length": String(buffer.length) },
    body: buffer,
  };
}

export async function GET(request: Request, { params }: { params: Promise<{ path?: string[] }> }) {
  const { path: segments } = await params;
  if (!segments || segments.length === 0) return notFound();
  const result = prepare(request, segments);
  if (!result) return notFound();
  return new Response(result.body ?? null, { status: result.status, headers: result.headers });
}

export async function HEAD(request: Request, { params }: { params: Promise<{ path?: string[] }> }) {
  const { path: segments } = await params;
  if (!segments || segments.length === 0) return notFound();
  const result = prepare(request, segments);
  if (!result) return notFound();
  const headers = { ...result.headers };
  delete (headers as Record<string, string | undefined>)["content-length"];
  return new Response(null, { status: result.status, headers });
}
