import { handleApi } from '@/server-node/compat'
import { handleDeliverableRequest } from '@server/deliverableStoreHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/deliverable/[action] | GET 当前/list/export(ZIP) · POST 保存/update-sync/update-layout/update-font | handler: server/deliverableStoreHandler.js | 读写: var/deliverable | export读: public/{audio-cache,pic,fonts}

/**
 * /api/deliverable/<action> 子路径（1:1）：
 *   GET  /api/deliverable/list
 *   POST /api/deliverable/update-sync
 *   POST /api/deliverable/update-layout
 *   POST /api/deliverable/update-font（★ 2026-10-25：板书字体切换写回）
 * connect 已剥去 /api/deliverable 前缀，handler 内部比较 /list、/update-sync、/update-layout、/update-font
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ action?: string[] }> },
) {
  const { action } = await params
  return handleApi(request, (req, res) => handleDeliverableRequest(req, res), {
    urlPath: `/${(action || []).join('/')}`,
  })
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ action?: string[] }> },
) {
  const { action } = await params
  return handleApi(request, (req, res) => handleDeliverableRequest(req, res), {
    urlPath: `/${(action || []).join('/')}`,
  })
}

export async function OPTIONS(
  request: Request,
  { params }: { params: Promise<{ action?: string[] }> },
) {
  const { action } = await params
  return handleApi(request, (req, res) => handleDeliverableRequest(req, res), {
    urlPath: `/${(action || []).join('/')}`,
  })
}
