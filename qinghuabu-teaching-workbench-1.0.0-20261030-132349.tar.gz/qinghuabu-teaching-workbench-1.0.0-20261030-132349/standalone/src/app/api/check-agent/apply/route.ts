import { handleApi } from '@/server-node/compat'
import { handleCheckApplyRequest } from '@server/checkAgentHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/check-agent/apply | POST 应用审校修正 | handler: server/checkAgentHandler.js | 写: public/board-result(原地覆写) | 无外呼

/** POST /api/check-agent/apply — Check 审计结果应用（1:1） */
export async function POST(request: Request) {
  return handleApi(request, (req, res) => handleCheckApplyRequest(req, res))
}

export async function OPTIONS(request: Request) {
  return handleApi(request, (req, res) => handleCheckApplyRequest(req, res))
}
