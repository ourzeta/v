import { handleApi } from '@/server-node/compat'
import { handleCheckAgentRequest } from '@server/checkAgentHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/check-agent/check | POST 五字段审校(失败降级本地ASR) | handler: server/checkAgentHandler.js | 读: public/board-result+var/handoff | 外呼: 用户配置 LLM(25s超时)

/** POST /api/check-agent/check — Check 审计链（1:1） */
export async function POST(request: Request) {
  return handleApi(request, (req, res) => handleCheckAgentRequest(req, res))
}

export async function OPTIONS(request: Request) {
  return handleApi(request, (req, res) => handleCheckAgentRequest(req, res))
}
