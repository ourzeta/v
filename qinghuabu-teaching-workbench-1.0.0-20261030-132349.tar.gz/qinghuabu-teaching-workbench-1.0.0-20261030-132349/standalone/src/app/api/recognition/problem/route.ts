import { handleApi } from '@/server-node/compat'
import { handleRecognitionRequest } from '@server/recognitionHandler.js'
import { AGENT_A_KNOWLEDGE_BASE } from '@server/docReferences.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/recognition/problem | POST 题目识别(图/文) | handler: server/recognitionHandler.js | 读: doc/knowledge-a.compact.json | 外呼: 用户配置 LLM(110s) | 内存LRU缓存

/** POST /api/recognition/problem — Agent A 题目识别（1:1 移植自 vite 中间件） */
export async function POST(request: Request) {
  return handleApi(request, (req, res) =>
    handleRecognitionRequest(req, res, AGENT_A_KNOWLEDGE_BASE),
  )
}

export async function OPTIONS(request: Request) {
  return handleApi(request, (req, res) =>
    handleRecognitionRequest(req, res, AGENT_A_KNOWLEDGE_BASE),
  )
}
