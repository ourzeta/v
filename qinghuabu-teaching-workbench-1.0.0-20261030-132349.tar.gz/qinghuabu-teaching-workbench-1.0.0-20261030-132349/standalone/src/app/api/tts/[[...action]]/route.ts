import { handleApi } from '@/server-node/compat'
import { handleFishAudioRequest } from '@server/fishAudioHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/tts/[action] | POST synthesize/save-local/batch · GET info | handler: server/fishAudioHandler.js | 写: public/audio-cache(+audio/pic) | 外呼: api.fish.audio(3key轮询,无超时=KI-039)

/**
 * /api/tts 及子路径（1:1）：
 *   GET  /api/tts | /api/tts/info      — 语音配置信息
 *   POST /api/tts/synthesize           — 单条合成（Key 轮换）
 *   POST /api/tts/save-local           — 合成并本地存档
 *   POST /api/tts/batch                — 批量合成
 * 原中间件挂载在 /api/tts，connect 剥前缀（handler 内的 replace 是直挂兜底，实际收到的
 * 已是剥前缀路径），故此处以 urlPath 复刻剥前缀语义。
 */
function run(request: Request, action?: string[]) {
  return handleApi(request, (req, res) => handleFishAudioRequest(req, res), {
    urlPath: `/${(action || []).join('/')}`,
  })
}

export async function GET(request: Request, { params }: { params: Promise<{ action?: string[] }> }) {
  const { action } = await params
  return run(request, action)
}

export async function POST(request: Request, { params }: { params: Promise<{ action?: string[] }> }) {
  const { action } = await params
  return run(request, action)
}

export async function OPTIONS(request: Request, { params }: { params: Promise<{ action?: string[] }> }) {
  const { action } = await params
  return run(request, action)
}
