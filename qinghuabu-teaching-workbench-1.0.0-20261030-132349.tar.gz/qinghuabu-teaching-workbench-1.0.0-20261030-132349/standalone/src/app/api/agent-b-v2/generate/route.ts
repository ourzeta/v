import { handleApi } from '@/server-node/compat'
import { handleAgentBV2Request } from '@server/agentBV2Handler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/agent-b-v2/generate | POST 生成五字段分镜 | handler: server/agentBV2Handler.js | 写: public/board-result | 外呼: 用户配置 LLM endpoint

/** POST /api/agent-b-v2/generate — Agent B 板书脚本生成（1:1） */
export async function POST(request: Request) {
  return handleApi(request, (req, res) => handleAgentBV2Request(req, res))
}

export async function OPTIONS(request: Request) {
  return handleApi(request, (req, res) => handleAgentBV2Request(req, res))
}
