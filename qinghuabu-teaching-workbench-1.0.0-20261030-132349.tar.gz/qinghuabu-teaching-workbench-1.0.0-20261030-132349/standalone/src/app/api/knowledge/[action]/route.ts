import { handleApi } from '@/server-node/compat'
import { handleKnowledgeRefineRequest } from '@server/knowledgeRefineHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/knowledge/:action | POST refine(知识修缮)/apply(应用回写) | handler: server/knowledgeRefineHandler.js | 读写: var/handoff | 外呼: 用户配置 LLM(60s)

/**
 * POST /api/knowledge/refine | /api/knowledge/apply — 知识点修缮链（1:1）
 * 原中间件挂载在 /api/knowledge/，connect 已剥前缀，handler 内部比较 /refine、/apply
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ action: string }> },
) {
  const { action } = await params
  return handleApi(request, (req, res) => handleKnowledgeRefineRequest(req, res), {
    urlPath: `/${action}`,
  })
}

export async function OPTIONS(
  request: Request,
  { params }: { params: Promise<{ action: string }> },
) {
  const { action } = await params
  return handleApi(request, (req, res) => handleKnowledgeRefineRequest(req, res), {
    urlPath: `/${action}`,
  })
}
