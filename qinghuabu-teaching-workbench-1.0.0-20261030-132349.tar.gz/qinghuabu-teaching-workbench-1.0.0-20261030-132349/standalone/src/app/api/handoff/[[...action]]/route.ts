import { handleApi } from '@/server-node/compat'
import { handleHandoffStoreRequest } from '@server/handoffStoreHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/handoff/[action] | GET 当前/list · POST 保存交接档 | handler: server/handoffStoreHandler.js | 读写: var/handoff | 无外呼

/**
 * /api/handoff 及子路径（1:1）：
 *   GET  /api/handoff          — 读取当前 handoff 存档
 *   GET  /api/handoff/list     — 列出全部存档
 *   POST /api/handoff          — 写入存档
 * 原中间件挂载在 /api/handoff，connect 剥前缀，handler 内部比较 '/'、'/list'
 */
function run(request: Request, action?: string[]) {
  return handleApi(request, (req, res) => handleHandoffStoreRequest(req, res), {
    urlPath: `/${(action || []).join('/')}`,
  })
}

export async function GET(request: Request, { params }: { params: Promise<{ action?: string[] }> }) {
  const { action } = await params
  return run(request, action)
}

export async function POST(request: Request, { params }: { params: Promise<{ action?: string[] }> }) {
  const { action } = await params
  return run(request, action)
}

export async function OPTIONS(request: Request, { params }: { params: Promise<{ action?: string[] }> }) {
  const { action } = await params
  return run(request, action)
}
