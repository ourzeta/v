import { handleApi } from '@/server-node/compat'
import { handleScreenshotStoreRequest } from '@server/screenshotStoreHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/screenshot | POST 题目截图存档(GET为死分支) | handler: server/screenshotStoreHandler.js | 写: public/pic | 无外呼

/**
 * GET/POST /api/screenshot — 截图存档（public/pic/）
 * 原中间件挂载在 /api/screenshot，handler 内部期望剥前缀后的 path = '/'
 */
export async function GET(request: Request) {
  return handleApi(request, (req, res) => handleScreenshotStoreRequest(req, res), { urlPath: '/' })
}

export async function POST(request: Request) {
  return handleApi(request, (req, res) => handleScreenshotStoreRequest(req, res), { urlPath: '/' })
}

export async function OPTIONS(request: Request) {
  return handleApi(request, (req, res) => handleScreenshotStoreRequest(req, res), { urlPath: '/' })
}
