export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/health | GET 健康检查 | 内联实现(无 handler) | 无盘 IO | 无外呼

/** GET /api/health — 健康检查（契约字段不变；service 名随架构更名 vite→nextjs，出参仍为单源真身） */
export async function GET() {
  return new Response(
    JSON.stringify({
      ok: true,
      status: 'healthy',
      service: 'qinghuabu-nextjs-dev',
      timestamp: new Date().toISOString(),
    }),
    { headers: { 'Content-Type': 'application/json; charset=utf-8' } },
  )
}
