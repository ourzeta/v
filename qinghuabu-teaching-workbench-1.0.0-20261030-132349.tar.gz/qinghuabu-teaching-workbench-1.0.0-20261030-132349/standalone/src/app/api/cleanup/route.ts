import { handleApi } from '@/server-node/compat'
import { handleCleanupRequest } from '@server/cleanupHandler.js'

export const dynamic = 'force-dynamic'

// [TAG:ROUTE] /api/cleanup | POST 删过期生成物(破坏性,保当前指针档) | handler: server/cleanupHandler.js | 删: public/*4目录+var/2目录 | 无外呼

/** POST /api/cleanup — 清理过期生成文件（handler 内部期望 path = '/'） */
export async function POST(request: Request) {
  return handleApi(request, (req, res) => handleCleanupRequest(req, res), { urlPath: '/' })
}

export async function OPTIONS(request: Request) {
  return handleApi(request, (req, res) => handleCleanupRequest(req, res), { urlPath: '/' })
}
