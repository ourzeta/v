import type { Metadata } from "next";
import "./globals.css";
import "antd/dist/reset.css";
import "@/style-origin.css";
import TeachingProviders from "@/components/teaching/TeachingProviders";

export const metadata: Metadata = {
  title: "小学数学讲解视频生成工作台",
  description: "基于大模型的小学数学题识别、分步口播与板书动作生成的教学视频工作台",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "小学数学讲解视频生成工作台",
    description: "基于大模型的小学数学题识别、分步口播与板书动作生成的教学视频工作台",
  },
};

/**
 * RootLayout — 1:1 复刻原 index.html：
 *   ① fetch 防篡改补丁（Object.defineProperty 守卫，必须先于一切业务代码执行）
 *   ② 字体宪法 v2.4：主 490 栗壳坚坚体同步加载，其余 5 个异步不阻塞首屏
 *   ③ /snapdom.js 截图库
 *   ④ #app 挂载点 id（style-origin.css 的 html,body,#app 规则依赖）
 *   ⑤ antd reset.css + style.css（原 main.js 引入顺序：reset → style.css）
 */
const FETCH_GUARD_SCRIPT = `(function() {
  var origDefineProperty = Object.defineProperty;
  var initialNativeFetch = window.fetch;
  var customFetch;
  var hasCustomSet = false;
  Object.defineProperty = function(obj, prop, desc) {
    if (obj === window && prop === 'fetch') {
      var origGet = desc && desc.get;
      return origDefineProperty.call(Object, obj, prop, {
        configurable: true,
        enumerable: true,
        get: function() {
          if (hasCustomSet) return customFetch;
          return origGet ? origGet.call(window) : (customFetch || initialNativeFetch);
        },
        set: function(val) {
          customFetch = val;
          hasCustomSet = true;
        }
      });
    }
    return origDefineProperty.apply(this, arguments);
  };
  try {
    var desc = Object.getOwnPropertyDescriptor(window, 'fetch');
    if (desc && desc.configurable && !desc.set) {
      Object.defineProperty(window, 'fetch', desc);
    }
  } catch (e) {}
})();`;

/**
 * 字体宪法 v2.4 — 编程式加载（1:1 复刻原 index.html 的 link onload/onError 策略）：
 *   主 490 栗壳坚坚体：preload 同步加载，onload 切 rel=stylesheet（不阻塞渲染管线语义一致）
 *   其余 5 个：media=print 异步加载 + onload 切 all（不阻塞首屏）
 *   React JSX 的 <link onLoad={字符串}> 非法（React 要求函数），故用内联脚本创建
 * ★ 2026-10-26 字体本地化（用户上传字体包）：主字体 490 栗坚 + 157 韶华改本地源
 *   /fonts/board-local.css（public/fonts/，与 CDN 同版本 TTF）——除号 .-. / 分数横杆的
 *   画布绘制按 measureText 墨芯锚定，CDN 不可达时按回退印刷体度量即坏象。本地源零
 *   CDN 依赖。157 已并入本地 css，异步数组减一员；507/511/510/509 无本地文件，保留 CDN。
 */
const FONT_LOADER_SCRIPT = `(function() {
  var main = document.createElement('link');
  main.rel = 'preload'; main.as = 'style';
  main.href = '/fonts/board-local.css';
  main.onload = function() { main.rel = 'stylesheet'; };
  main.onerror = function() { console.warn('[Font] 本地板书字体加载异常，按字体栈降级'); };
  document.head.appendChild(main);
  ['507', '511', '510', '509'].forEach(function(id) {
    var l = document.createElement('link');
    l.rel = 'stylesheet'; l.media = 'print';
    l.href = 'https://fontsapi.zeoseven.com/' + id + '/main/result.css';
    l.onload = function() { l.media = 'all'; };
    document.head.appendChild(l);
  });
})();`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: FETCH_GUARD_SCRIPT }} />
        <script dangerouslySetInnerHTML={{ __html: FONT_LOADER_SCRIPT }} />
        {/* 快照库（本地存档用，存 /pic/shot-时间戳.jpg，不发给 B） */}
        <script defer src="/snapdom.js" />
      </head>
      <body suppressHydrationWarning>
        <div id="app" className="min-h-screen">
          <TeachingProviders>{children}</TeachingProviders>
        </div>
      </body>
    </html>
  );
}
