import type { Metadata } from "next";
import BoardPreviewApp from "@/components/teaching/BoardPreviewApp";

// Task 4-c：BoardPreviewApp.vue → /board-preview 路由页。
// 原 MPA 入口 board-preview.html <title>画布预览 · 全屏</title>，metadata title 保持一致；
// public/board-preview.html shim 已 location.replace('/board-preview')，URL 契约不变。
export const metadata: Metadata = {
  title: "画布预览 · 全屏",
};

export default function Page() {
  return <BoardPreviewApp />;
}
