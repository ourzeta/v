// [TAG:BRIDGE] src/server-node/compat.ts handleApi | 全部 /api/* 路由共用的 Web Request→Node req/res 翻译桥 | 404/500 兜底在此 | rg "[TAG:" 可拉全业务脉络

/**
 * Node req/res 兼容层 — 让原 vite 中间件 handler（Node 风格 req/res）在
 * Next.js Route Handler（Web Request/Response）里零逻辑改动运行。
 *
 * 原处理器使用的 API 面（审计结果）：
 *   req: method / url / headers / body(可选) / 异步可迭代 body 流
 *   res: setHeader / end / statusCode / headersSent / destroy
 *
 * 语义对齐点：
 *   1. connect 挂载中间件会剥掉挂载前缀 → 通过 urlPath 覆写复刻
 *   2. readJsonBody 原本就是「流式收集 + JSON.parse(catch→{})」→ 这里始终走流
 *   3. 204/205/304 响应体必须为 null（Web Response 规范）
 */

export interface NodeLikeReq {
  method: string
  url: string
  headers: Record<string, string>
  body?: unknown
  /** 事件式流读取（fishAudioHandler 本地 readJsonBody 使用） */
  on(event: 'data' | 'end' | 'error', cb: (chunk?: Buffer | Error) => void): unknown
  pause?(): unknown
  resume?(): unknown
  [Symbol.asyncIterator](): AsyncIterableIterator<Buffer | string>
}

export interface NodeLikeRes {
  statusCode: number
  headersSent: boolean
  setHeader(name: string, value: string | string[]): void
  end(chunk?: Buffer | string | null): void
  destroy?(err?: Error): void
}

type NodeHandler = (
  req: NodeLikeReq,
  res: NodeLikeRes,
) => Promise<boolean | void> | boolean | void

class ShimRes implements NodeLikeRes {
  statusCode = 200
  headersSent = false
  ended = false
  private headers = new Headers()
  private chunks: (Buffer | string)[] = []

  setHeader(name: string, value: string | string[]) {
    this.headers.set(name, Array.isArray(value) ? value.join(', ') : String(value))
  }

  end(chunk?: Buffer | string | null) {
    if (this.ended) return
    if (chunk !== undefined && chunk !== null) this.chunks.push(chunk)
    this.headersSent = true
    this.ended = true
  }

  destroy() {
    this.ended = true
  }

  toResponse(): Response {
    const status = this.statusCode || 200
    const nullBody = status === 204 || status === 205 || status === 304
    let body: BodyInit | null = null
    if (!nullBody && this.chunks.length > 0) {
      const buf = Buffer.concat(
        this.chunks.map((c) => (typeof c === 'string' ? Buffer.from(c, 'utf-8') : c)),
      )
      body = new Uint8Array(buf)
    }
    return new Response(body, { status, headers: this.headers })
  }
}

export async function handleApi(
  request: Request,
  handler: NodeHandler,
  opts?: { urlPath?: string },
): Promise<Response> {
  const url = new URL(request.url)
  const pathname = opts?.urlPath ?? url.pathname
  const reqUrl = pathname + (url.search || '')

  const headers: Record<string, string> = {}
  request.headers.forEach((value, key) => {
    headers[key] = value
  })

  // 始终缓冲 body 文本，经异步迭代器喂给 handler（与 connect 流式语义一致）
  let bodyText: string | undefined
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    try {
      bodyText = await request.text()
    } catch {
      bodyText = ''
    }
  }

  const req: NodeLikeReq = {
    method: request.method,
    url: reqUrl,
    headers,
    // 供「req.body 已解析」的兼容分支使用（原 connect 环境不预设，保持 undefined）
    body: undefined,
    // 事件式读取（fishAudioHandler 本地 readJsonBody 用 req.on('data'/'end')）
    on(event: 'data' | 'end' | 'error', cb: (chunk?: Buffer | Error) => void) {
      if (event === 'data') {
        if (bodyText !== undefined && bodyText !== '') {
          cb(Buffer.from(bodyText, 'utf-8'))
        }
      } else if (event === 'end') {
        cb()
      } else if (event === 'error') {
        // 不产生错误
      }
      return req
    },
    pause() {
      return req
    },
    resume() {
      return req
    },
    [Symbol.asyncIterator]: async function* (this: unknown) {
      if (bodyText !== undefined && bodyText !== '') {
        yield Buffer.from(bodyText, 'utf-8')
      }
    },
  }

  const res = new ShimRes()
  try {
    const handled = await handler(req, res)
    if (!handled && !res.ended) {
      // handler 明确返回 false 且未写响应 → 复刻 next() 落空：404
      return new Response(JSON.stringify({ ok: false, error: 'Not Found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
      })
    }
    if (!res.ended) res.end()
    return res.toResponse()
  } catch (error) {
    if (res.ended) return res.toResponse()
    return new Response(
      JSON.stringify({ ok: false, error: error instanceof Error ? error.message : String(error) }),
      { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8' } },
    )
  }
}
