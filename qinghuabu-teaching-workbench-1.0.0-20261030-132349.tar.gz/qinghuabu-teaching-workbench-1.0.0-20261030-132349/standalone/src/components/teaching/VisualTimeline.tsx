'use client'

/**
 * 1:1 移植自 /home/z/teaching-board/src/components/VisualTimeline.vue
 *
 * - defineProps { rows, activeIndex, playingIndex } / defineEmits ['select-row', 'play-audio']
 *   → props + onSelectRow(index) / onPlayAudio({ index, url }) 回调
 * - @wheel="onWheel" → 原生 wheel 监听（passive:false）：React 合成 onWheel 在根节点为
 *   passive 注册，preventDefault 会失效，故用 addEventListener 1:1 保留原拦截语义
 * - watch([playingIndex, activeIndex])（无 immediate）→ useEffect + 首帧跳过；nextTick → rAF
 */
import { useCallback, useEffect, useRef } from 'react'
import { ROUGH_NOTATION_TOOL_ID, ROUGH_NOTATION_ENABLED_ACTIONS } from '@/board-tools/roughNotationTool.js'
import { AGENT_B_V2_ROW_GAP_MS } from '@/agent-b-v2/timing.js'
import './VisualTimeline.css'

export interface VisualTimelineProps {
  rows?: any[]
  activeIndex?: number
  /** ★ 当前正在播放的 row index（用于在时间轴块上显示"正在播放"状态） */
  playingIndex?: number
  /** ★ 原 emit('select-row')：行定位 */
  onSelectRow?: (index: number) => void
  /** ★ 原 emit('play-audio')：试听，payload { index, url } */
  onPlayAudio?: (payload: { index: number; url: string }) => void
}

export default function VisualTimeline({
  rows = [],
  activeIndex = -1,
  // ★ 当前正在播放的 row index（用于在时间轴块上显示"正在播放"状态）
  playingIndex = -1,
  onSelectRow,
  onPlayAudio,
}: VisualTimelineProps) {
  const trackRef = useRef<HTMLDivElement | null>(null)
  // ★ Vue watch 无 immediate → 跳过 React effect 首帧执行
  const followFirstRunRef = useRef(true)

  // 动作类型标签：只显示 underline/circle。

  const ACTION_LABELS: Record<string, string> = { underline: '下划线', circle: '画圈' }

  // ★ 提取本行的合法标注动作（actionSpec 数组，排除 capabilityGap 缺口项）
  // ★ Task 46 归一（三个幽灵之一）：entry.startDelay 无人写入恒 0——真源排期在
  //   row.rowTimeline.actionTimeline[].startOffsetMs（timing.js applyAgentBV2Timeline 产出，
  //   action 引用与 actionSpec 同源可对上）；这里解出注入克隆体 startDelay（秒），
  //   下游三处消费点（钉位置/钉 title/指标行 tooltip）不改。无时间线/对不上 → 兜底 0（口播一开即触发）。
  function getActions(row: any) {
    if (!Array.isArray(row?.actionSpec)) return []
    const timeline = Array.isArray(row?.rowTimeline?.actionTimeline) ? row.rowTimeline.actionTimeline : []
    return row.actionSpec
      .filter((e: any) => !e?.capabilityGap && e?.action?.tool === ROUGH_NOTATION_TOOL_ID
        && ROUGH_NOTATION_ENABLED_ACTIONS.includes(e.action.action))
      .map((e: any) => {
        const tl = timeline.find((t: any) => t && t.action === e)
        const sec = tl && Number.isFinite(Number(tl.startOffsetMs)) ? tl.startOffsetMs / 1000 : 0
        return { ...e, startDelay: sec }
      })
  }

  // 动作类型（entry.action 是工具对象 { tool, action: 'underline'|... }）
  function getActionType(entry: any) {

    return entry?.action?.action || ''
  }

  // 动作触发延时（秒）：startDelay 由 getActions 从 rowTimeline.actionTimeline[].startOffsetMs
  // 解包注入（Task 46 归一，旧 entry.startDelay 幽灵字段无人写入）；无值时默认 0 = 口播一开就触发
  function getActionStartDelay(entry: any) {
    const v = Number(entry?.startDelay)
    return Number.isFinite(v) && v >= 0 ? v : 0
  }

  // 动作目标描述（target.exactText 或 targetId）
  function getActionTargetDesc(entry: any) {
    const t = entry?.action?.target
    if (typeof t === 'string' && t.trim()) return t
    if (t && typeof t === 'object') return t.exactText ? `“${t.exactText}”` : (t.region || '')
    return '目标未描述'
  }

  // 按类型统计（徽章用）
  function getActionTypeCounts(row: any) {
    const counts: Record<string, number> = {}
    for (const a of getActions(row)) {
      const type = getActionType(a)
      if (!type) continue
      counts[type] = (counts[type] || 0) + 1
    }
    return Object.entries(counts).map(([type, count]) => ({ type, count }))
  }

  // 动作指标行 tooltip
  function getActionTitle(row: any) {
    const acts = getActions(row)
    if (!acts.length) return '本 Row 无标注动作（仅写字）'
    return acts
      .map(
        (a, i) =>
          `动作${i + 1}：+${getActionStartDelay(a).toFixed(1)}s ${ACTION_LABELS[getActionType(a)] || getActionType(a)} ${getActionTargetDesc(a)}`
      )
      .join('\n')
  }

  // 动作钉在微观条上的百分比位置（2%~95% 防溢出）
  function getActionPinPercent(row: any, entry: any) {
    const dur = getDuration(row)
    if (dur <= 0) return 2
    const pct = (getActionStartDelay(entry) / dur) * 100
    return Math.min(95, Math.max(2, Math.round(pct)))
  }

  // ★ 滚轮横滚：滚轮 deltaY 直接映射为横向滚动——不用 shift+滚轮，
  // 用户一滚滚轮就能看到后面的行（“行数超过就没了听都不能听”的直接解药）
  const onWheel = useCallback((e: WheelEvent) => {
    const el = trackRef.current
    if (!el) return
    // 容器未溢出时不拦截（垂直滚动不受影响）
    if (el.scrollWidth <= el.clientWidth) return
    e.preventDefault()
    el.scrollLeft += (e.deltaY || 0) + (e.deltaX || 0)
  }, [])

  // 原生 wheel 监听（等价模板 @wheel 绑定，passive:false 保 preventDefault 生效）
  useEffect(() => {
    const el = trackRef.current
    if (!el) return
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  }, [onWheel])

  // ★ 播放/选中跟随：正在播放或编辑中的行块自动滚进视野（横向居中）
  useEffect(() => {
    // ★ 原 watch 无 immediate：跳过首帧（挂载即选中不触发滚动，仅变更时滚动）
    if (followFirstRunRef.current) {
      followFirstRunRef.current = false
      return
    }
    const idx = playingIndex >= 0 ? playingIndex : activeIndex
    if (idx < 0 || !trackRef.current) return
    // nextTick → rAF（等 DOM 更新后执行）
    const raf = requestAnimationFrame(() => {
      const el = trackRef.current
      if (!el) return
      const block = el.querySelector(`.timeline-row-block:nth-child(${idx + 1})`)
      if (block instanceof HTMLElement) {
        block.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' })
      }
    })
    return () => cancelAnimationFrame(raf)
  }, [playingIndex, activeIndex])

  // ★ 提取 row 的音频 URL（优先 audioUrl，兜底缓存 rowAudioCache，再兜底 audio.mp3）
  //  注意：父组件传入的 row 已含 audioUrl 与 audioDurationMs 字段（若已生成）
  function getAudioUrl(row: any) {
    if (!row) return ''
    return row.audioUrl || row.mp3 || row.audio || ''
  }

  // ★ 试听按钮点击：emit 给父组件，由父组件调 playAudioUrl 统一管理音频实例
  //  这样可以复用父组件的 activeAudio / playingAudioIndex 状态，不会多实例冲突
  function onPlayClick(idx: number, row: any) {
    const url = getAudioUrl(row)
    if (!url) return
    onPlayAudio?.({ index: idx, url })
  }

  // 提取 row 的时长（单位：秒）
  function getDuration(row: any) {
    // ★ 优先使用真实音频时长（如果有）
    if (row.audioDurationMs && row.audioDurationMs > 0) {
      return row.audioDurationMs / 1000
    }
    if (row.audioDuration && row.audioDuration > 0) return row.audioDuration
    if (row.estimatedDurationMs && row.estimatedDurationMs > 0) return row.estimatedDurationMs / 1000
    if (row.rowTimeline?.rowTotalDurationMs && row.rowTimeline.rowTotalDurationMs > 0) {
      return row.rowTimeline.rowTotalDurationMs / 1000
    }
    const textLen = (row.speech || '').length
    return Math.max(2.5, Number((textLen / 2.8).toFixed(1)))
  }

  // 提取板书内容是否存在
  function hasBoard(row: any) {
    if (!row.board) return false
    if (typeof row.board === 'string') return Boolean(row.board.trim())
    const content = row.board.content || ''
    return Boolean(content.trim())
  }

  // 提取 board.startDelay（单位：秒）
  function getStartDelay(row: any) {
    if (!hasBoard(row)) return 0
    const board = row.board
    if (board && typeof board === 'object') {
      if (typeof board.startDelay === 'number' && Number.isFinite(board.startDelay) && board.startDelay >= 0) {
        return Number(board.startDelay.toFixed(1))
      }
      if (typeof board.startDelay === 'string') {
        const m = board.startDelay.match(/[\d.]+/)
        if (m) {
          const val = parseFloat(m[0])
          if (Number.isFinite(val) && val >= 0) return Number(val.toFixed(1))
        }
      }
    }
    if (row.rowTimeline?.boardStartDelayMs != null) {
      return Number((row.rowTimeline.boardStartDelayMs / 1000).toFixed(1))
    }
    // 默认智能自适应起手点（前置 1.5s 口播铺垫）
    const dur = getDuration(row)
    return Number(Math.min(2.2, Math.max(1.0, dur * 0.2)).toFixed(1))
  }

  // 计算板书前纯口播铺垫百分比
  function getPreludePercent(row: any) {
    const dur = getDuration(row)
    if (dur <= 0) return 0
    if (!hasBoard(row)) return 100
    const delay = getStartDelay(row)
    const pct = (delay / dur) * 100
    return Math.min(85, Math.max(5, Math.round(pct)))
  }

  // 估算累计起始时间点
  function getEstimatedStart(targetIdx: number) {
    // 2026-10-15 归一：优先吃 timing.js 预计算的 estimatedStartMs（唯一真源时间轴），
    // 仅在行数据不带时间轴字段时本地兜底估算（rowGap 用真源常量，不再平行写死）
    const est = Number(rows?.[targetIdx]?.estimatedStartMs)
    if (Number.isFinite(est) && est >= 0) return est
    let accMs = 0
    for (let i = 0; i < targetIdx; i++) {
      const d = getDuration(rows[i]) * 1000
      accMs += d + AGENT_B_V2_ROW_GAP_MS
    }
    return accMs
  }

  // 计算块宽度弹性基准
  function getBlockWidth(row: any) {
    const dur = getDuration(row)
    const basePx = Math.max(160, Math.min(260, Math.round(dur * 24)))
    return `${basePx}px`
  }

  // 总音频时长
  const totalDurationSec = (() => {
    if (!rows.length) return '0.0'
    const total = rows.reduce((sum, r) => sum + getDuration(r), 0)
    return total.toFixed(1)
  })()

  // 带有板书的 Row 计数
  const boardRowCount = rows.filter(hasBoard).length

  // ★ 标注动作总数（header 统计）
  const actionCount = rows.reduce((sum, r) => sum + getActions(r).length, 0)

  // 平均起手延时
  const avgStartDelay = (() => {
    const boardRows = rows.filter(hasBoard)
    if (!boardRows.length) return '0.0'
    const sum = boardRows.reduce((acc, r) => acc + getStartDelay(r), 0)
    return (sum / boardRows.length).toFixed(1)
  })()

  function getMiniTimelineTitle(row: any) {
    const dur = getDuration(row).toFixed(1)
    const delay = getStartDelay(row).toFixed(1)
    if (!hasBoard(row)) return `总音频时长 ${dur}s（本行无板书）`
    return `总音频时长 ${dur}s | 0s~+${delay}s 纯口播铺垫 | +${delay}s 开始落笔书写板书`
  }

  function onBlockClick(index: number) {
    onSelectRow?.(index)
  }

  return (
    <div className="visual-timeline-root">
      {/* 顶部状态栏与图例 */}
      <div className="timeline-header">
        <div className="timeline-title-area">
          <span className="timeline-main-icon">🎬</span>
          <span className="timeline-title">时序全景时间轴</span>
          <span className="timeline-subtitle">Row 组音频时长与板书落笔起手点映射</span>
        </div>

        <div className="timeline-summary-stats">
          <span className="summary-pill">
            <span className="pill-dot total-dot" />
            共 <strong>{rows.length}</strong> 组 Row
          </span>
          <span className="summary-pill">
            <span className="pill-dot audio-dot" />
            音频总长 <strong>{totalDurationSec}s</strong>
          </span>
          {boardRowCount > 0 && (
            <span className="summary-pill">
              <span className="pill-dot board-dot" />
              板书 <strong>{boardRowCount}</strong> 处（平均起手 <strong>+{avgStartDelay}s</strong>）
            </span>
          )}
          {actionCount > 0 && (
            <span className="summary-pill">
              <span className="pill-dot action-dot" />
              标注动作 <strong>{actionCount}</strong> 个
            </span>
          )}
        </div>

        <div className="timeline-legend">
          <span className="legend-item"><span className="legend-badge stage-question" />题目</span>
          <span className="legend-item"><span className="legend-badge stage-analysis" />分析</span>
          <span className="legend-item"><span className="legend-badge stage-solution" />解答</span>
          <span className="legend-item"><span className="legend-badge stage-summary" />总结</span>
          <span className="legend-divider">|</span>
          <span className="legend-item"><span className="legend-icon">🎵</span>MP3音频</span>
          <span className="legend-item"><span className="legend-icon">✍️</span>+n秒板书起手</span>
          <span className="legend-item"><span className="legend-icon">🎭</span>标注动作(下划线/画圈)</span>
          <span className="legend-item"><span className="legend-icon">🎯</span>动作触发时点</span>
        </div>
      </div>

      {/* 核心横向时间轴轨道：每个 Row 组映射为一个独立区块 */}
      {/* ★ 滚轮横滚：鼠标滚轮直接横向滑动（无需 shift+滚轮，用户才“看得到”后面的行） */}
      <div className="timeline-track-container" ref={trackRef}>
        <div className="timeline-track">
          {rows.map((row, idx) => (
            <div
              key={row._rowKey || idx}
              className={[
                'timeline-row-block',
                `stage-theme-${row.stage || '分析'}`,
                activeIndex === idx ? 'is-active' : '',
                hasBoard(row) ? 'has-board' : '',
              ]
                .filter(Boolean)
                .join(' ')}
              style={{ flexBasis: getBlockWidth(row) }}
              onClick={() => onBlockClick(idx)}
            >
              {/* 块顶部：序号与环节 */}
              <div className="block-top-bar">
                <span className="block-index-badge">Row {idx + 1}</span>
                <span className={`block-stage-pill stage-${row.stage || '分析'}`}>
                  {row.stage || '分析'}
                </span>
              </div>

              {/* 核心指标1：MP3 音频时长 */}
              <div className="block-metric-row audio-row" title="本 Row 组 MP3 语音音频持续时长">
                <div className="metric-label-group">
                  <span className="metric-icon">🎵</span>
                  <span className="metric-name">MP3时长</span>
                </div>
                <span className="metric-val audio-val">{getDuration(row).toFixed(1)}s</span>
              </div>

              {/* ★ 试听按钮：点击立即试听本 Row 的音频（缓存 mp3） */}
              {getAudioUrl(row) ? (
                <button
                  className={`block-play-btn${playingIndex === idx ? ' is-playing' : ''}`}
                  title={playingIndex === idx ? '暂停试听' : '试听本 Row 组音频'}
                  onClick={(e) => {
                    e.stopPropagation()
                    onPlayClick(idx, row)
                  }}
                >
                  <span className="play-btn-icon">{playingIndex === idx ? '⏸' : '▶'}</span>
                  <span className="play-btn-text">{playingIndex === idx ? '暂停试听' : '试听'}</span>
                </button>
              ) : (
                <div className="block-play-btn block-play-btn-empty" title="本 Row 尚未生成音频">
                  <span className="play-btn-text-muted">未生成音频</span>
                </div>
              )}

              {/* 核心指标2：板书动画起手延时（只读展示，由系统语义与音频自动驱动） */}
              <div
                className={[
                  'block-metric-row',
                  'offset-row',
                  !hasBoard(row) ? 'no-board-offset' : '',
                ]
                  .filter(Boolean)
                  .join(' ')}
                title={
                  hasBoard(row)
                    ? `口播进行到 +${getStartDelay(row).toFixed(1)}s 时，右手开始落笔书写`
                    : '本 Row 仅朗读，无板书书写'
                }
              >
                <div className="metric-label-group">
                  <span className="metric-icon">✍️</span>
                  <span className="metric-name">板书起手</span>
                </div>
                <div className="offset-adjust-box">
                  {!hasBoard(row) ? (
                    <span className="metric-val zero-offset">0.0s (无板书)</span>
                  ) : (
                    <span className="metric-val highlight-offset">+{getStartDelay(row).toFixed(1)}s</span>
                  )}
                </div>
              </div>

              {/* Action metric: underline/circle only. */}
              <div
                className={['block-metric-row', 'action-row', !getActions(row).length ? 'no-action-row' : '']
                  .filter(Boolean)
                  .join(' ')}
                title={getActionTitle(row)}
              >
                <div className="metric-label-group">
                  <span className="metric-icon">🎭</span>
                  <span className="metric-name">标注动作</span>
                </div>
                <div className="action-badges">
                  {!getActions(row).length && <span className="metric-val zero-offset">0 个（仅写字）</span>}
                  {getActionTypeCounts(row).map((t) => (
                    <span key={t.type} className={`action-badge act-${t.type}`}>
                      {ACTION_LABELS[t.type] || t.type} {t.count}
                    </span>
                  ))}
                </div>
              </div>

              {/* 块内部微观时序分段条：直观展示口播铺垫期与落笔书写期的比例关系 */}
              <div className="mini-timeline-track" title={getMiniTimelineTitle(row)}>
                <div
                  className="mini-bar-audio-prelude"
                  style={{ width: getPreludePercent(row) + '%' }}
                >
                  {getPreludePercent(row) > 20 && <span className="mini-bar-label">纯口播</span>}
                </div>
                {hasBoard(row) && (
                  <div
                    className="mini-board-start-pin"
                    style={{ left: getPreludePercent(row) + '%' }}
                    title="板书开始落笔时间点"
                  >
                    <span className="pin-marker">✍️</span>
                  </div>
                )}
                {/* ★ 动作触发时点钉：每个标注动作按 startDelay 在微观条上打点（动作容身之地之二） */}
                {getActions(row).map((act, ai) => (
                  <div
                    key={'act-pin-' + ai}
                    className="mini-action-pin"
                    style={{ left: getActionPinPercent(row, act) + '%' }}
                    title={`+${getActionStartDelay(act).toFixed(1)}s 触发 ${ACTION_LABELS[getActionType(act)] || getActionType(act)}（${getActionTargetDesc(act)}）`}
                  >
                    <span className="pin-marker">🎯</span>
                  </div>
                ))}
                <div
                  className="mini-bar-board-writing"
                  style={{ width: (100 - getPreludePercent(row)) + '%' }}
                >
                  {(100 - getPreludePercent(row)) > 25 && (
                    <span className="mini-bar-label">
                      {hasBoard(row) ? '板书书写' : '朗读进行'}
                    </span>
                  )}
                </div>
              </div>

              {/* 口播文案微缩预览 */}
              <div className="block-speech-preview" title={row.speech}>
                {row.speech || '（无口播）'}
              </div>

              {/* 块底部：起止时间戳 */}
              <div className="block-footer-time">
                <span>{(getEstimatedStart(idx) / 1000).toFixed(1)}s</span>
                <span className="arrow-sep">➔</span>
                <span>{((getEstimatedStart(idx) + getDuration(row) * 1000) / 1000).toFixed(1)}s</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
