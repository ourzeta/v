'use client'

/**
 * 1:1 移植自 /home/z/teaching-board/src/components/GlobalPulseLoading.vue
 *
 * - 原 reactive 单例 globalLoadingState（services/globalLoading.js，零改动）通过
 *   useSyncExternalStore + vueShim 订阅：version 变化驱动重渲染，JSX 直读
 *   globalLoadingState.visible / .text / .subtext / .cancelable
 * - Vue <Transition name="pulse-fade"> → 挂载/延迟卸载 + 渐入渐出 class 状态机等价实现
 *   （enter: 首帧 enter-from + enter-active，两帧后移除 enter-from 触发 0.25s 过渡；
 *     leave: 挂 leave-active + leave-to，250ms 后卸载 DOM）
 * - watch/immediate 的状态复位走 React 官方「渲染期调整状态」模式（零时延，等价 Vue 同步 watch）
 */
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { getReactiveVersion, subscribeReactive } from '@/lib/vueShim.js'
import { globalLoadingState, hideGlobalLoading } from '@/services/globalLoading.js'
import './GlobalPulseLoading.css'

export default function GlobalPulseLoading() {
  const version = useSyncExternalStore(
    (cb) => subscribeReactive(globalLoadingState, cb),
    () => getReactiveVersion(globalLoadingState),
    () => getReactiveVersion(globalLoadingState),
  )
  // version 仅驱动重渲染（读 proxy 属性不订阅），显式引用避免 lint unused
  void version

  const visible = globalLoadingState.visible
  const displayMainText =
    ((globalLoadingState.text || '').trim()
      // 移除末尾已有的省略号以使用独立带脉冲动画的省略号
      .replace(/\.{3,}$/, '')
      .replace(/…$/, '') || '数据分析中')

  // 原 elapsedSeconds ref → useState
  const [elapsedSeconds, setElapsedSeconds] = useState(0)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // ★ 原 watch(globalLoadingState.visible, immediate:true) 的 startTimer 复位段：
  //   渲染期调整（React 官方 adjusting-state 模式：visible 变化当帧生效，等价 Vue 同步 watch；
  //   挂载且 visible=true 时 elapsed 已是初值 0，与 startTimer 复位语义一致）
  const [prevVisibleTimer, setPrevVisibleTimer] = useState(visible)
  if (visible !== prevVisibleTimer) {
    setPrevVisibleTimer(visible)
    if (visible) {
      setElapsedSeconds(0)
    }
  }

  // startTimer 的 interval 段 / stopTimer（visible=false 或卸载时清理）
  useEffect(() => {
    if (!visible) return
    timerRef.current = setInterval(() => {
      setElapsedSeconds((s) => s + 1)
    }, 1000)
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
    }
  }, [visible])

  // === 原 <Transition name="pulse-fade"> 等价实现 ===
  // rendered: DOM 是否挂载；fadeCls: 当前过渡 class
  const [rendered, setRendered] = useState(visible)
  const [fadeCls, setFadeCls] = useState(visible ? 'pulse-fade-enter-from pulse-fade-enter-active' : '')
  const [prevVisibleTrans, setPrevVisibleTrans] = useState(visible)

  // visible 变化当帧：enter → 挂 enter-from+enter-active；leave → 挂 leave-active+leave-to
  if (visible !== prevVisibleTrans) {
    setPrevVisibleTrans(visible)
    if (visible) {
      setRendered(true)
      setFadeCls('pulse-fade-enter-from pulse-fade-enter-active')
    } else {
      setFadeCls('pulse-fade-leave-active pulse-fade-leave-to')
    }
  }

  // 过渡推进（setState 均在 rAF/timeout 回调内）：enter 两帧后移除 enter-from 触发
  // 0.25s 渐入、260ms 后清 class；leave 250ms 过渡结束后卸载 DOM
  useEffect(() => {
    if (!visible) {
      if (!rendered) return
      const done = setTimeout(() => {
        setRendered(false)
        setFadeCls('')
      }, 250)
      return () => clearTimeout(done)
    }
    let raf2 = 0
    const raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => setFadeCls('pulse-fade-enter-active'))
    })
    const done = setTimeout(() => setFadeCls(''), 260)
    return () => {
      cancelAnimationFrame(raf1)
      cancelAnimationFrame(raf2)
      clearTimeout(done)
    }
    // rendered 仅作 leave 分支守卫读值，不作为重启依据
  }, [visible])

  function handleManualDismiss() {
    hideGlobalLoading(true)
  }

  if (!rendered) return null

  return (
    <div
      id="global-pulse-loading-mask"
      className={`global-pulse-overlay ${fadeCls}`.trim()}
      role="status"
      aria-live="polite"
    >
      <div id="global-pulse-loading-card" className="pulse-card">
        {/* 轻微脉冲动效核心 */}
        <div className="pulse-beacon-container">
          <div className="pulse-beacon-outer" />
          <div className="pulse-beacon-inner" />
          <div className="pulse-beacon-core">
            <svg
              className="pulse-icon-svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {/* 数据分析 / 波动信号矢量图形 */}
              <path d="M3 12h3l3-8 4 16 3-8h5" />
              <circle cx="19" cy="12" r="1.5" fill="currentColor" />
            </svg>
          </div>
        </div>

        {/* 主文案与动态省略号 */}
        <div className="pulse-text-wrap">
          <h4 className="pulse-title">
            <span>{displayMainText}</span>
            <span className="pulse-animated-dots">
              <span className="dot d1">.</span>
              <span className="dot d2">.</span>
              <span className="dot d3">.</span>
            </span>
          </h4>
          {globalLoadingState.subtext && (
            <p className="pulse-subtext">{globalLoadingState.subtext}</p>
          )}
        </div>

        {/* 细密平滑的脉冲微光进度流动条 */}
        <div className="pulse-gleam-track">
          <div className="pulse-gleam-bar" />
        </div>

        {/* 关怀计时与超时取消提示 */}
        {elapsedSeconds >= 8 && (
          <div className="pulse-timeout-action">
            <span className="elapsed-badge">已处理 {elapsedSeconds}s</span>
            {globalLoadingState.cancelable && (
              <button
                id="global-pulse-loading-close-btn"
                type="button"
                className="pulse-dismiss-btn"
                title="关闭遮罩层"
                onClick={handleManualDismiss}
              >
                关闭遮罩
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
