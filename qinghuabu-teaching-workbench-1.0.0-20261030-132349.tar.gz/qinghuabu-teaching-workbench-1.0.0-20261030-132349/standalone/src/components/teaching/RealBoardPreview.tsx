'use client'

/* @qh-core LANE=SHARED POINT=TRUE_PREVIEW 1726x980 capture source */
/**
 * 1:1 移植自 /home/z/teaching-board/src/components/RealBoardPreview.vue
 *
 * 契约核对：worklog「共享组件固定契约」props { problemText, topicLayout, boardPlan,
 * showAllLabels, showGrid, showZoneGuides, sourceImageUrl, keepOriginal, interactive }
 * 与源 SFC defineProps 完全一致；源码另含超集 prop（canvasImageUrl/zoneEditable/
 * backgroundImageUrl/actionSpec/boardRows/autoPlay/canvasParams）与 emit 'pick-coord'，
 * 按转换规则以源码为准全部保留。回调映射：
 *   emit('pick-coord')          → onPickCoord(payload)
 *   emit('topic-measured',p)    → onTopicMeasured(p)
 *   emit('update:topic-layout') → onUpdateTopicLayout(layout)
 *   emit('layout-change')       → onLayoutChange(layout)
 *   emit('update:problem-text') → onUpdateProblemText(text)
 */
import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import BoardContentLayer from './BoardContentLayer'
import {
  CANVAS_W as DESIGN_W,
  CANVAS_H as DESIGN_H,
} from '@/utils/canvasCoords.js'
import { BOARD_FONT_SIZE, HANDWRITING_FONT_STACK, ANALYSIS_TEXT_COLOR, BOARD_TEXT_COLOR, BOARD_LINE_HEIGHT_EXTRA_PX } from '@/services/stepHandoff.js'
import { naturalLhRatioFor, naturalLhWithFractionMargin } from '@/lib/naturalLineHeight.js'
import { createBoardToolRuntime } from '@/board-tools/boardToolCatalog.js'
// ponytail: parseBoardContent 归并到 contract.js#normalizeBoard 唯一真源
// （原 SFC 此 import 位于脚本中部，TSX 统一提升至顶部，注释随行保留）
import { normalizeBoard } from '@/agent-b-v2/contract.js'
// ponytail: 板书文字渲染前过 superFilter 12 步清洗 + DOM 堆叠渲染真源
// ★ 2026-10-24 夏夏教义：零 KaTeX（题干除外）；÷→.-. 点-横-点堆叠、a/b→\frac 上下堆叠、
//   ²³→1/3 字号右上角上标；堆叠行按 2 行高度排（防换行重影）。
import { normalizeBoardLine, renderBoardSegmentHtml, hasStackGlyph } from '@/utils/superFilter.js'
import './RealBoardPreview.css'

export interface RealBoardPreviewProps {
  canvasImageUrl?: string
  problemText?: string
  /** 完整规划：四标签+区+题目；没有则只显示题目标签/题文默认位 */
  boardPlan?: Record<string, any> | null
  /** 兼容只传 topicLayout */
  topicLayout?: Record<string, any> | null
  showGrid?: boolean
  showAllLabels?: boolean
  showZoneGuides?: boolean
  /** ★ Task 58 布局修订闭环：四区框编辑态透传（预览页布局编辑模式） */
  zoneEditable?: boolean
  interactive?: boolean
  sourceImageUrl?: string
  keepOriginal?: boolean
  /**
   * ★ Task 22 夏夏拍板：AgentA 排版成品截图 = 画布底图原装引用。
   * 传入后 L1 层直接显示截图（题目/四标签/分区已在图内），
   * BoardContentLayer 题目二次排版整层退位，本组件专注 L3 板书动作+音频配合。
   * 不传（如 Step1Entry 生产方）则维持原有排版行为。
   */
  backgroundImageUrl?: string
  /** Agent B 输出的动作数组，自动在 L3 层播放 */
  actionSpec?: any[]
  /** 当前交付物的五字段行，供 L3 板书文本和 exactText 锚点使用 */
  boardRows?: any[]
  /** 是否自动播放 actionSpec，默认 true */
  autoPlay?: boolean
  /**
   * ★ Task 9 修复: 画布舞台参数 (canvasParams)
   *  真相源: handoff.canvasParams (Agent A 给) → AgentBDirect/Step1Entry 透传
   *  含 canvasSize / fontSize.question.px / fontSize.analysis.px / lineHeight 等
   *  若不传则 fallback 到 stepHandoff.js 的 BOARD_FONT_SIZE / QUESTION_FONT_SIZE 常量
   */
  canvasParams?: Record<string, any> | null
  // —— emits → 回调 props ——
  onPickCoord?: (payload: Record<string, any>) => void
  onTopicMeasured?: (payload: { bottomPct: number; heightPct: number }) => void
  onUpdateTopicLayout?: (layout: any) => void
  onLayoutChange?: (layout: any) => void
  onUpdateProblemText?: (text: string) => void
  /** 原 <slot name="playback" /> */
  playback?: React.ReactNode
}

export default function RealBoardPreview({
  canvasImageUrl = '/canvas.png',
  problemText = '',
  boardPlan = null,
  topicLayout = null,
  showGrid = false,
  showAllLabels = false,
  showZoneGuides = false,
  zoneEditable = false,
  interactive = true,
  sourceImageUrl = '',
  keepOriginal = false,
  backgroundImageUrl = '',
  actionSpec = [],
  boardRows = [],
  autoPlay = true,
  canvasParams = null,
  onPickCoord,
  onTopicMeasured,
  onUpdateTopicLayout,
  onLayoutChange,
  onUpdateProblemText,
  playback,
}: RealBoardPreviewProps) {
  // 题目区由 BoardContentLayer 固定印刷字体；此处仅处理手写板书三区。
  const boardFontSize = (() => {
    // analysis / solution / summary 都用同一个 BOARD_FONT_SIZE
    const px = Number(canvasParams?.fontSize?.analysis?.px)
    return px > 0 ? px : BOARD_FONT_SIZE
  })()
  // ★ v2.1 板书字体切换：fontStack 从 canvasParams.fontSource.handwriting 派生（上游按用户选择
  //   用真源构造器 handwritingFontSourceFor 填入）；旧档/未传则兑底默认栈。单一控制点不变。
  const handwritingFontStack = (() => {
    const stack = canvasParams?.fontSource?.handwriting?.fontStack
    return (typeof stack === 'string' && stack.includes('"')) ? stack : HANDWRITING_FONT_STACK
  })()

  // ★ 字体宪法 v2.2（2026-10-16 夏夏拍板）：自然行高 + 2px 分数余量——CSS 无法对 line-height: normal
  //   做加法，用 canvas 度量字体栈自然比数 + 2px 折算无单位 line-height（与 row-player naturalLhRatio
  //   同一度量体系）。度量不可用回落 .board-text-anchor 基础样式 normal；手写字体 CDN 异步加载完成
  //   （loadingdone）后重测——字体没到之前量到的是回退栈，到了必须换真度量。
  // ★ v2.3（2026-10-22 夏夏拍板）：本层是板书层（分析/解答/总结），行距余量用 BOARD_LINE_HEIGHT_EXTRA_PX=4px
  //   （2px 分数余量 + 2px 行距呼吸）；题目层（BoardContentLayer）维持 2px 不变。
  const [boardLhRatio, setBoardLhRatio] = useState<number | null>(null)
  function remeasureBoardLh() {
    setBoardLhRatio(naturalLhRatioFor(handwritingFontStack, boardFontSize))
  }
  const boardTextLh = naturalLhWithFractionMargin(boardLhRatio, boardFontSize, BOARD_LINE_HEIGHT_EXTRA_PX) // 板书层 v2.3 余量 4px

  // 原 watch([handwritingFontStack, boardFontSize], remeasureBoardLh) + onMounted(remeasureBoardLh)
  // → 合并为一个 effect（挂载执行一次 = onMounted；依赖变更执行 = watch）；
  //   setState 包 rAF 规避 set-state-in-effect（canvas 度量为纯计算，晚一帧无感知）
  useEffect(() => {
    const raf = requestAnimationFrame(remeasureBoardLh)
    return () => cancelAnimationFrame(raf)
  }, [handwritingFontStack, boardFontSize])

  // 原 onMounted：document.fonts 监听（字体异步加载完成后重测自然行高）
  useEffect(() => {
    // SSR 守卫：用三元而非 `&&` 短路（false?.x 不短路，TS 严格模式报错）
    const fonts = typeof document !== 'undefined' ? document.fonts : null
    if (fonts) {
      fonts.ready?.then(remeasureBoardLh)
      fonts.addEventListener?.('loadingdone', remeasureBoardLh)
    }
    // 原 onBeforeUnmount
    return () => {
      const fonts = typeof document !== 'undefined' ? document.fonts : null
      fonts?.removeEventListener?.('loadingdone', remeasureBoardLh)
    }
  }, [])

  // ★ Task 9: 画布尺寸 (没传则 fallback 1726×980 常量)
  // （源 SFC 中此二 computed 未被模板消费，按 1:1 原样保留）
  const canvasWidth = (() => {
    const w = Number(canvasParams?.canvasSize?.width)
    return w > 0 ? w : DESIGN_W
  })()
  const canvasHeight = (() => {
    const h = Number(canvasParams?.canvasSize?.height)
    return h > 0 ? h : DESIGN_H
  })()
  void canvasWidth
  void canvasHeight

  const [hover, setHover] = useState<Record<string, any> | null>(null)
  const boardRef = useRef<HTMLDivElement | null>(null)
  const roughSvgRef = useRef<SVGSVGElement | null>(null)
  // 原 setup 内 let runtime = null → 组件实例级 ref
  const runtimeRef = useRef<any>(null)

  function resolveCanvas() {
    return roughSvgRef.current
  }

  function resolveRegion(region: string) {
    if (!boardRef.current) return null
    return boardRef.current.querySelector(`[data-board-region="${region}"]`)
  }

  function resolveRegionBounds(region: string) {
    const zone = boardPlan?.[region]
    if (!zone) return null
    return {
      x: (zone.x / 100) * DESIGN_W,
      y: (zone.y / 100) * DESIGN_H,
      width: (zone.w / 100) * DESIGN_W,
      height: (zone.h / 100) * DESIGN_H,
    }
  }

  function initRuntime() {
    if (runtimeRef.current) return
    runtimeRef.current = createBoardToolRuntime({
      resolveCanvas,
      resolveRegion,
      resolveRegionBounds,
      boardPlan,
    })
  }

  // ★ Task 46 挂账记档：app 预览域无排期语义（挂载即播、不等板书/口播、不消费 triggerKeyword 时点）；
  //   完整排期在 row-player.html compile（真源 timing.js 同构镜像）。预览只保结构一致性。
  function normalizeActionSpecItem(item: any) {
    // B 输出格式：{ action: { tool, order, ... } } 或 { capabilityGap: {...} }
    // 代码期望格式：{ tool, order, ... }
    if (item?.capabilityGap) return null
    if (item?.action && typeof item.action === 'object') {
      // ★ Task 46 结构透传：解包 {...item.action} 会剥掉 entry 级 triggerKeyword/stage——
      //   runtime 不消费也无害，保留可保结构不丢失（导出/Check/编辑器链路同款字段）
      return {
        ...item.action,
        ...(item.triggerKeyword != null ? { triggerKeyword: item.triggerKeyword } : {}),
        ...(item.stage != null ? { stage: item.stage } : {}),
      }
    }
    return item
  }

  // ponytail: 板书文字渲染前过 superFilter 12 步清洗 (÷→.-., ×→x, a/b→\frac, $删除等)
  function parseBoardContent(board: any) {
    return { content: normalizeBoard(board).content }
  }

  function resolveBoardRegion(row: any) {
    const stage = String(row?.stage || '')
    if (stage === '解答' || stage === '解答过程') return 'solution'
    if (stage === '总结' || stage === '总结提升') return 'summary'
    return 'analysis'
  }

  function regionStyle(region: string) {
    const zone = boardPlan?.[region]
    if (!zone) return {}
    return {
      left: `${zone.x}%`,
      top: `${zone.y}%`,
      width: `${zone.w}%`,
      minHeight: `${zone.h}%`,
    }
  }

  // ponytail: 板书文字渲染前过 superFilter 12 步清洗 (÷→.-., ×→x, a/b→\frac, $删除等)
  const boardTextRows = useMemo(
    () =>
      (boardRows || [])
        .map((row, index) => {
          const board = parseBoardContent(row?.board)
          if (!board.content.trim()) return null
          // 每行板书内容过 superFilter，拆行级条目（行高需逐行判定，见模板 stacked 逻辑）
          const lines = board.content
            .split('\n')
            .map((line: string) => normalizeBoardLine(line))
            .filter((line: string) => line.length)
            .map((line: string) => ({ text: line, stacked: hasStackGlyph(line) }))
          if (!lines.length) return null
          const region = resolveBoardRegion(row)
          // ★ 夏夏教义「算作2行高度，防止换行重影」：含堆叠结构（\frac/.-.）的行，行高加倍防相邻行重影
          return { id: `${region}-${index}`, region, lines }
        })
        .filter(Boolean),
    [boardRows],
  )

  function playActionSpec() {
    if (!runtimeRef.current || !autoPlay) return
    runtimeRef.current.clear()
    if (actionSpec?.length) {
      const normalized = actionSpec.map(normalizeActionSpecItem).filter(Boolean)
      if (normalized.length) {
        // R5 步骤级隔离（2026-10-13）：单个动作失败/取消只 warn 并跳过，
        // 不炸整场播放，也不再向全局抛 unhandled rejection。
        runtimeRef.current.enqueueAll(normalized).forEach((task: any) => {
          task?.catch?.((err: any) => {
            console.warn('[RealBoardPreview] 动作已隔离（单步失败/取消不阻断播放）:', err?.message || err)
          })
        })
      }
    }
  }

  // 原 onMounted(() => nextTick(() => { initRuntime(); playActionSpec() })) — nextTick → rAF
  useEffect(() => {
    const raf = requestAnimationFrame(() => {
      initRuntime()
      playActionSpec()
    })
    return () => cancelAnimationFrame(raf)
  }, [])

  // 原 watch(() => props.actionSpec, () => nextTick(playActionSpec), { deep: true })
  // → deep 监听以 JSON 快照为依赖（内容变更才重播；规避 React 每渲染新数组引用引发的无谓重播）；
  //   Vue watch 无 immediate → 跳过首帧（挂载播放由上面 onMounted effect 负责）
  const actionSpecKey = useMemo(() => JSON.stringify(actionSpec ?? []), [actionSpec])
  const actionSpecWatchFirstRunRef = useRef(true)
  useEffect(() => {
    if (actionSpecWatchFirstRunRef.current) {
      actionSpecWatchFirstRunRef.current = false
      return
    }
    const raf = requestAnimationFrame(playActionSpec)
    return () => cancelAnimationFrame(raf)
  }, [actionSpecKey])

  // 原 onBeforeUnmount(() => { runtime?.clear(); runtime = null })
  useEffect(() => {
    return () => {
      runtimeRef.current?.clear()
      runtimeRef.current = null
    }
  }, [])

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    if (!interactive) return
    const rect = e.currentTarget.getBoundingClientRect()
    const xPct = ((e.clientX - rect.left) / rect.width) * 100
    const yPct = ((e.clientY - rect.top) / rect.height) * 100
    const px = Math.round((xPct / 100) * DESIGN_W)
    const py = Math.round((yPct / 100) * DESIGN_H)
    setHover({
      xPct: xPct.toFixed(1),
      yPct: yPct.toFixed(1),
      px,
      py,
    })
  }
  function onLeave() {
    setHover(null)
  }
  function onClick() {
    if (!interactive || !hover) return
    onPickCoord?.({ ...hover })
  }

  return (
    <div className="real-board-wrap">
      <div
        ref={boardRef}
        className={`board${interactive ? ' interactive' : ''}`}
        data-board-canvas="true"
        style={
          {
            aspectRatio: `${DESIGN_W} / ${DESIGN_H}`,
            // ★ 字体宪法 v2：区域文字颜色真源派生（分析红 / 其余黑）
            '--board-analysis-color': ANALYSIS_TEXT_COLOR,
            '--board-ink-color': BOARD_TEXT_COLOR,
          } as CSSProperties
        }
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        onClick={onClick}
      >
        <div className="board-layer board-layer-l1" data-board-layer="L1">
          {/* ★ Task 22: AgentA 排版截图原装引用优先（与画布同源同比例，铺满零变形）；无截图回退纸张底图 */}
          <img
            className="board-paper"
            src={backgroundImageUrl || canvasImageUrl}
            alt="甲方画布"
            draggable={false}
          />
        </div>

        {/* ★ Task 22: 有背景截图时题目排版层退位（截图内已含 AgentA 排版成品） */}
        {!backgroundImageUrl && (
          <BoardContentLayer
            problemText={problemText}
            boardPlan={boardPlan}
            topicLayout={topicLayout}
            showGrid={showGrid}
            showAllLabels={showAllLabels}
            showZoneGuides={showZoneGuides}
            zoneEditable={zoneEditable}
            sourceImageUrl={sourceImageUrl}
            keepOriginal={keepOriginal}
            canvasParams={canvasParams}
            onTopicMeasured={(p) => onTopicMeasured?.(p)}
            onUpdateTopicLayout={(l) => onUpdateTopicLayout?.(l)}
            onLayoutChange={(l) => onLayoutChange?.(l)}
            onUpdateProblemText={(t) => onUpdateProblemText?.(t)}
          />
        )}

        {/* L3 生成内容播放层：Agent B 输出在这里播放 */}
        <div className="board-layer board-layer-l3" data-board-layer="L3">
          <svg
            ref={roughSvgRef}
            className="rough-drawing-layer"
            data-board-overlay="rough-drawings"
            viewBox={`0 0 ${DESIGN_W} ${DESIGN_H}`}
            preserveAspectRatio="none"
            aria-hidden="true"
          />

          {['analysis', 'solution', 'summary'].map((region) => (
            <div
              key={region}
              className={`board-region-layer board-region-layer-${region}`}
              style={regionStyle(region)}
              data-board-region={region}
            >
              {boardTextRows
                .filter((entry: any) => entry.region === region)
                .map((item: any) => (
                  <span
                    key={item.id}
                    className="board-text-anchor"
                    style={{
                      fontSize: `${boardFontSize}px`,
                      fontFamily: handwritingFontStack,
                    }}
                  >
                    {/* v-html 真源渲染：\frac 上下堆叠分数 / .-. 点-横-点除号 / ²³ 1/3 字号上标（零 KaTeX）。
                         ★ 夏夏教义「算作2行高度，防止换行重影」：堆叠行行高加倍；
                         度量值不可用时 CSS 无法对 normal 做乘法，回落 2.4（≈normal 1.2 的两倍） */}
                    {item.lines.map((line: any, li: number) => (
                      <span
                        key={li}
                        className="board-line-html"
                        style={{
                          display: 'block',
                          lineHeight: line.stacked
                            ? (boardTextLh ? Number(boardTextLh) * 2 : '2.4')
                            : (boardTextLh ?? 'normal'),
                        }}
                      >
                        {/* 原 v-html（eslint-disable-next-line vue/no-v-html）→ dangerouslySetInnerHTML */}
                        <span dangerouslySetInnerHTML={{ __html: renderBoardSegmentHtml(line.text) }} />
                      </span>
                    ))}
                  </span>
                ))}
            </div>
          ))}
          <div className="annotation-layer" data-board-overlay="annotations" aria-hidden="true" />
          {playback}
        </div>

        {/* L4 用户画笔层：只保留边界，交互由下一步 Agent C 实现 */}
        <div className="board-layer board-layer-l4" data-board-layer="L4" aria-hidden="true" />

        {hover && (
          <div className="hover-readout">
            画布: ({hover.px}, {hover.py})px · ({hover.xPct}%, {hover.yPct}%)
            <span className="hint">点击复制</span>
          </div>
        )}
      </div>
    </div>
  )
}
