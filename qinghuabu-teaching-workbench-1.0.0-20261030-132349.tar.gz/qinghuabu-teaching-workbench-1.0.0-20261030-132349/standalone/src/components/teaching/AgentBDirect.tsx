'use client'

/* @qh-core LANE=B-V2 POINT=UI_WORKBENCH five-field table primary */
// AgentBDirect.vue（5472 行）→ React 1:1 移植（Task 4-b）
// 原文件：/home/z/teaching-board/src/agent-b-v2/AgentBDirect.vue
// Vue→React 对应关系：ref→useState+ref 镜像（useSyncedRef：同一异步流程内先 set 后读，读到的永远是新值，
// 等价 Vue ref.value）、computed→渲染期直算/lazy 函数、watch→useEffect、emit→props 回调、
// nextTick→requestAnimationFrame、<style scoped>→AgentBDirect.css（:deep() 改普通后代选择器）。
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import {
  Alert,
  Badge,
  Button,
  Card,
  Descriptions,
  Dropdown,
  Input,
  InputNumber,
  Layout,
  Listy,
  message,
  Popconfirm,
  Popover,
  Select,
  Space,
  Steps,
  Table,
  Tabs,
  Tag,
  Tooltip,
} from 'antd'
import {
  CheckCircleOutlined,
  DownloadOutlined,
  ThunderboltOutlined,
  ToolOutlined,
  PlusOutlined,
  DeleteOutlined,
  SoundOutlined,
  SafetyCertificateOutlined,
  HolderOutlined,
  ReloadOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined,
  PlayCircleOutlined,
  SaveOutlined,
  CopyOutlined,
  PauseCircleOutlined,
  KeyOutlined,
  VideoCameraOutlined,
  FileDoneOutlined,
  MoreOutlined,
} from '@ant-design/icons'
import QhPageHeader from '@/components/teaching/QhPageHeader'
import ProcessLoadingModal from '@/components/teaching/ProcessLoadingModal'
import { saveLiveBoardPreview, readLayoutRevision } from '@/board-preview/liveBoardPreview.js'
import { generateAgentBV2Rows } from '@/agent-b-v2/service.js'
import { ensureAgentBRowIds, applyAgentBV2Timeline, computeRowGroupTimeline, countCharacters, estimateSpeechDurationMs, rowHasRealAudio, AGENT_B_V2_SPEECH_RATE, AGENT_B_V2_ROW_GAP_MS, AUDIO_SPEED_POLICY_TEXT } from '@/agent-b-v2/timing.js'
import { listSkills, DEFAULT_SKILL_ID } from '@/agent-b-v2/skills/index.js'
import { checkAgentRows, applyCheckResult } from '@/check-agent/service.js'
import { batchPolishRowsMathAsr } from '@/lib/mathAsrConverter.js'
import {
  agentBApiConfig,
  saveAgentBApiConfig,
  isAgentBApiReady,
  parseApiKeys as parseAgentBApiKeys,
} from '@/lib/agentBApiConfig.js'
import { userApiConfig } from '@/lib/userApiConfig.js'
// ★ 2026-10-14：refine/apply 原为全 App 仅剩的裸 fetch+resp.json()——平台网关切断/代理吐
// HTML 错误页时直接炸 SyntaxError（夏夏实测"点优化确认出现 json 报错"）。换共享安全封装。
import { safeJsonFetch } from '@/lib/safeJsonFetch.js'
import { exportSpeechMarkdown, exportStoryboardMarkdown } from '@/lib/speechMarkdown.js'
// ★ Task 40：#017 归一共享真源（客户端 JSON 导出出口接线，与服务端双出口同一实现）
import { normalizeDeliverableAssetPaths } from '@/lib/deliverableAssetPaths.js'
import VisualTimeline from '@/components/teaching/VisualTimeline'
import { showGlobalLoading, hideGlobalLoading } from '@/services/globalLoading.js'
// 画布参数唯一真源：src/services/stepHandoff.js
// ★ 字体宪法 v2（2026-10-15）：题目字体/行高口径全部真源派生，不再硬编码
// ★ v2.1（同日）：板书字体下拉切换器——选择值唯一键 uiSettings.handwritingFontChoice，
//   派生口 = resolveHandwritingFont + buildCanvasParams(fontChoice)（交付态整体构造），
//   注册表 = HANDWRITING_FONT_CHOICES
// ★ v2.4（2026-10-25）：下拉扩为 3 选 1（lijian 栗壳坚坚体默认 / qiaomu 乔木 / shaohua 韶华），
//   真源 stepHandoff 字体宪法 v2.4；旧默认时代的 'qiaomu' 记忆一次性迁移到新默认
import {
  QUESTION_FONT_SIZE,
  BOARD_FONT_SIZE,
  QUESTION_FONT_FAMILY,
  LINE_HEIGHT_POLICY_TEXT,
  CANVAS_SIZE,
  HANDWRITING_FONT_CHOICE_DEFAULT,
  resolveHandwritingFont,
  buildCanvasParams,
  extractZoneAnchors,
  applyBoardPlanRevision,
} from '@/services/stepHandoff.js'
// ★ Task 60 坐标归一：默认四区布局唯一真源派生（boardLayout.js），本文件 3 处 fallback
//   原手押的抖动快照值（两组误冻结的历史值系）全部改 import 派生，哨兵锁死不再漂移
import { DEFAULT_BOARD_PLAN } from '@/utils/boardLayout.js'
// ★ Task 63 片1（夏夏「做减法」）：锚定校验换真引擎——findRange 与 row-player 字节级同源
//   （boardAnchorCore.js 唯一 ESM 真源），近似 pool.includes 镜像退役，哨兵 B13 锁死不漂移
import {
  findRange,
  buildBoardAnchorFlow,
  buildQuestionAnchorFlow,
  REGION_STAGE_ZH,
} from '@/board-tools/boardAnchorCore.js'
// ponytail: 拆分 composables (从 AgentBDirect.vue 抽出纯逻辑)
import { useBCache } from '@/agent-b-v2/composables/useBCache.js'
// 解析 board 字段，兼容历史坐标前缀和当前对象格式。
// ponytail: parseBoard 归并到 contract.js#normalizeBoard 唯一真源
// 保留 parseBoard 名字兼容模板 6 处调用，内部委托 normalizeBoard
// 差异: null startDelay（无显式值时） vs normalizeBoard 的 0，模板里 v-if/.value 都按 falsy 处理
// （源 SFC 该 import 原位于 script 中段 L324，ESM 语义等价提升到顶部 import 区）
import { normalizeBoard } from '@/agent-b-v2/contract.js'
// ★ 2026-10-24 夏夏教义「不要用 KaTeX 这个（除了题目）」：板书列零 KaTeX，
//   KaTeX 唯一合法区 = 题干 mathText.js。板书渲染唯一真源 = superFilter.renderBoardTextHtml
//   （÷→.-. 点-横-点堆叠、a/b→\frac 上下堆叠、²³→1/3 字号右上角上标，先转义再构建标记）。
import { renderBoardTextHtml } from '@/utils/superFilter.js'
import { getReactiveVersion, subscribeReactive } from '@/lib/vueShim.js'
import {
  safeDeepClone,
  GENERATING_STEPS,
  genProjectCodeTs,
  readStoredFontChoice,
  ACTION_TYPE_OPTIONS,
  LAYOUT_PRESETS,
  actionLabel,
  actionContent,
  formatDisplayTime,
  displayValue,
  formatRegion,
  getAudioFilename,
  copyAudioUrl,
} from './agentb/agentBShared'
import ToolsCard from './agentb/ToolsCard'
import KnowledgeDetailModal from './agentb/KnowledgeDetailModal'
import CheckResultModal from './agentb/CheckResultModal'
import RefineCompareModal from './agentb/RefineCompareModal'
import ApiConfigModal from './agentb/ApiConfigModal'
import DeliverableModal from './agentb/DeliverableModal'
import './AgentBDirect.css'

/** Vue ref → React 等价桥：state 管渲染，ref 镜像同步可读（同一异步流程内先 set 后读，读到的永远是新值，等价 Vue ref.value） */
function useSyncedRef<T>(initial: T) {
  const [state, setState] = useState<T>(initial)
  const ref = useRef<T>(initial)
  const set = (next: T | ((prev: T) => T)) => {
    const resolved = typeof next === 'function' ? (next as (prev: T) => T)(ref.current) : next
    ref.current = resolved
    setState(resolved)
  }
  return [state, set, ref] as const
}

function rowsWithoutInternalIds(rows: any[]) {
  return rows.map(({ _rowUid, _rowKey, ...row }) => row)
}

/** 音色下拉选项（value = Fish Audio reference_id；label 面向用户） */
const VOICE_REFERENCE_OPTIONS = [
  { label: '音色 A（默认）', value: 'fcee4dd834844f28a92b246e0d996104' },
  { label: '音色 B', value: '9d88188c6ddf4441a396af0e02aa2434' },
]
const VOICE_REFERENCE_DEFAULT = VOICE_REFERENCE_OPTIONS[0].value
const VOICE_REFERENCE_STORAGE_KEY = 'agent-b-voice-reference-id'
/** TTS 模型（4 处合成口共用，禁止字面量复制） */
const VOICE_MODEL = 's2.1-pro-free'

export interface AgentBDirectProps {
  /** 对应原 :initial-handoff="handoff" */
  initialHandoff: Record<string, any> | null
  /** 对应原 emit('back-to-step1') */
  onBackToStep1: () => void
}

export default function AgentBDirect({ initialHandoff, onBackToStep1 }: AgentBDirectProps) {
  const [localHandoff, setLocalHandoff, localHandoffRef] = useSyncedRef<any>(safeDeepClone(initialHandoff))
  // computed handoff = localHandoff（渲染期直读；逻辑内 handoff.value → localHandoffRef.current）
  const handoff = localHandoff || {}

  // 智能教研优雅思考步骤（分散等待时长，直观感知深度创作进程）——GENERATING_STEPS 见 agentb/agentBShared
  const [generatingStepIndex, setGeneratingStepIndex, generatingStepIndexRef] = useSyncedRef<number>(0)
  const generatingTimerRef = useRef<any>(null)
  const [handoffDetailsExpanded, setHandoffDetailsExpanded] = useState(true)

  function startGeneratingTimer() {
    setGeneratingStepIndex(0)
    clearInterval(generatingTimerRef.current)
    generatingTimerRef.current = setInterval(() => {
      setGeneratingStepIndex((generatingStepIndexRef.current + 1) % GENERATING_STEPS.length)
    }, 2800)
  }

  function stopGeneratingTimer() {
    clearInterval(generatingTimerRef.current)
    generatingTimerRef.current = null
  }

  // onMounted：handoff 缺关键参数时从服务端拉兜底
  useEffect(() => {
    ;(async () => {
      if (!localHandoffRef.current || !localHandoffRef.current.canvasParams || !localHandoffRef.current.zoneAnchors || !localHandoffRef.current.screenshotUrl) {
        try {
          const res = await fetch('/api/handoff')
          const data = await res.json()
          if (data?.ok && data?.handoff) {
            setLocalHandoff(safeDeepClone(data.handoff))
          }
        } catch {
          // 容错降级
        }
      }
    })()
  }, [])

  // onUnmounted：清定时器与音频实例
  useEffect(() => {
    return () => {
      stopGeneratingTimer()
      stopCurrentAudio()
    }
  }, [])

  // props 变化时同步更新 localHandoff（父组件重新传入 handoff 时）——watch(() => props.initialHandoff, deep)
  useEffect(() => {
    if (initialHandoff) setLocalHandoff(safeDeepClone(initialHandoff))
  }, [initialHandoff])

  const [rows, setRowsState, rowsRef] = useSyncedRef<any[]>([])

  function setRows(next: any[] | ((current: any[]) => any[])) {
    const previousRows = rowsRef.current
    const previousById = new Map(previousRows.map(row => [row._rowUid, row]))
    let speechChanged = false
    let nextRows = ensureAgentBRowIds(typeof next === 'function' ? next(previousRows) : next).map((row: any) => {
      const previous = previousById.get(row._rowUid)
      if (!previous || previous.speech === row.speech) return row
      speechChanged = true
      const clean = { ...row }
      for (const key of ['audioUrl', 'audioDurationMs', 'duration', 'durationLabel', 'mp3', 'audio', 'voice']) delete clean[key]
      return clean
    })
    if (speechChanged) nextRows = applyAgentBV2Timeline(nextRows, { rowGapMs: canvasParamsRef.current.rowGapMs })
    const playingIndex = playingAudioIndexRef.current
    if (playingIndex != null) {
      const playingRow = previousRows[playingIndex]
      const nextIndex = nextRows.findIndex((row: any) => row._rowUid === playingRow?._rowUid)
      if (nextIndex < 0 || nextRows[nextIndex].speech !== playingRow?.speech) stopCurrentAudio()
      else if (nextIndex !== playingIndex) setPlayingAudioIndex(nextIndex)
    }
    setRowsState(nextRows)
    try { bCacheSet(nextRows, generatedModelRef.current) } catch (_e) { /* 缓存失败不阻断 */ }
  }
  const [state, setState, stateRef] = useSyncedRef<string>('idle')
  const [errorText, setErrorText, errorTextRef] = useSyncedRef<string>('')
  const [generatedModel, setGeneratedModel, generatedModelRef] = useSyncedRef<string>('')
  const [checkState, setCheckState, checkStateRef] = useSyncedRef<string>('idle')
  const [checkChanges, setCheckChanges, checkChangesRef] = useSyncedRef<any[]>([])
  const [checkSource, setCheckSource, checkSourceRef] = useSyncedRef<string>('check_agent') // 'check_agent' | 'math_asr'
  const [pendingCheckRows, setPendingCheckRows, pendingCheckRowsRef] = useSyncedRef<any>(null)
  const [checkResultOpen, setCheckResultOpen] = useSyncedRef<boolean>(false)
  const [checkFailedFallback, setCheckFailedFallback, checkFailedFallbackRef] = useSyncedRef<boolean>(false)
  const [deliverableGenerating, setDeliverableGenerating] = useSyncedRef<boolean>(false)
  const [deliverableResult, setDeliverableResult, deliverableResultRef] = useSyncedRef<any>(null)
  const [deliverableModalOpen, setDeliverableModalOpen] = useSyncedRef<boolean>(false)

  const [toolsOpen, setToolsOpen, toolsOpenRef] = useSyncedRef<boolean>(false)
  const [refineLoading, setRefineLoading, refineLoadingRef] = useSyncedRef<boolean>(false)
  const [refineApplying, setRefineApplying, refineApplyingRef] = useSyncedRef<boolean>(false)
  const [refineResultOpen, setRefineResultOpen] = useSyncedRef<boolean>(false)
  const [refineResult, setRefineResult, refineResultRef] = useSyncedRef<any>(null)
  const [refineAppliedAt, setRefineAppliedAt] = useSyncedRef<string>('')
  const skillList = listSkills()
  const [selectedSkillId, setSelectedSkillId, selectedSkillIdRef] = useSyncedRef<string>(DEFAULT_SKILL_ID)
  // ponytail: a-select 风格切换下拉的 options (替代旧"提示词"按钮, 不查看提示词内容)
  const skillOptions = skillList.map((s: any) => ({ value: s.id, label: s.id === DEFAULT_SKILL_ID ? '系统标准' : s.name || s.id }))
  function onSkillChange(val: any) {
    setSelectedSkillId(val)
    message.success(`已切换讲课风格：${skillList.find((s: any) => s.id === val)?.name || val}`)
  }
  const [apiConfigOpen, setApiConfigOpen] = useSyncedRef<boolean>(false)
  const [cleanupLoading, setCleanupLoading] = useSyncedRef<boolean>(false)

  async function cleanupGeneratedFiles() {
    setCleanupLoading(true)
    try {
      const res = await fetch('/api/cleanup', { method: 'POST' })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || '清理失败')
      const size = data.bytes >= 1024 * 1024
        ? `${(data.bytes / 1024 / 1024).toFixed(1)} MB`
        : `${Math.round(data.bytes / 1024)} KB`
      message.success(data.count ? `已清理 ${data.count} 个文件，释放 ${size}` : '没有可清理的垃圾文件')
      if ('caches' in window) {
        for (const key of await (window as any).caches.keys()) await (window as any).caches.delete(key)
      }
    } catch (error: any) {
      message.error(`清理失败：${error?.message || String(error)}`)
    } finally {
      setCleanupLoading(false)
    }
  }

  function onSaveApiConfig() {
    saveAgentBApiConfig()
    const keyCount = parseAgentBApiKeys(agentBApiConfig.apiKey).length
    if (keyCount > 1) {
      message.success(`Agent B 配置已保存，已配置 ${keyCount} 个密钥轮询使用`)
    } else {
      message.success('Agent B API 配置已保存')
    }
    setApiConfigOpen(false)
  }
  // ★ Task 13：死功能链砍除——自定义提示词弹窗无 UI 入口（promptEditOpen 恒 false，
  // customSystemPrompt 恒空串），整链（ref→弹窗→useBCache 键位→service 传参→server 分支）全砍
  // computed currentSkillName（渲染期直算）
  const currentSkill = skillList.find((s: any) => s.id === selectedSkillId)
  const currentSkillName = currentSkill?.name || selectedSkillId
  const checkRunIdRef = useRef(0)

  // 画布参数配置（导出时跟着要素表一起导出）
  const [canvasParams, , canvasParamsRef] = useSyncedRef<any>({
    coordinateMode: 'percentage',
    questionFontSize: QUESTION_FONT_SIZE,
    questionFontFamily: QUESTION_FONT_FAMILY,
    lineHeightPolicy: LINE_HEIGHT_POLICY_TEXT,
    rowGapMs: AGENT_B_V2_ROW_GAP_MS,
    speechSpeed: AGENT_B_V2_SPEECH_RATE,
  })

  // ★ v2.1 板书字体下拉切换器：选择随 uiSettings.handwritingFontChoice 写入交付物（数据随档走）；跨会话 localStorage 记忆
  // ★ v2.4（2026-10-25 夏夏令默认换栗壳坚坚体）：旧键值一次性迁移——readStoredFontChoice 内含迁移逻辑
  //   （源 SFC setup 同步调用；React 侧 localStorage 初始化推迟到挂载 effect，SSR 安全，见 Task 4-a 同款决策）
  const [boardFontChoice, setBoardFontChoice, boardFontChoiceRef] = useSyncedRef<string>(HANDWRITING_FONT_CHOICE_DEFAULT)
  useEffect(() => {
    setBoardFontChoice(readStoredFontChoice())
  }, [])

  // ★ 音色下拉（Fish Audio reference_id）：三处合成口（单行试听/重新生成/批量/修复行）共用此值，禁止字面量；
  //   跨会话 localStorage 记忆；挂载后再读，SSR 安全
  const [voiceReferenceId, setVoiceReferenceId, voiceReferenceIdRef] = useSyncedRef<string>(VOICE_REFERENCE_DEFAULT)
  useEffect(() => {
    const stored = localStorage.getItem(VOICE_REFERENCE_STORAGE_KEY)
    if (stored && VOICE_REFERENCE_OPTIONS.some((o) => o.value === stored)) setVoiceReferenceId(stored)
  }, [])

  // ★ 板书列预览字体：板书内容=手写体是字体宪法（题目之外一律手写）；除号 .-. 的减号/上下点、
  //   分数横杆都是手写体真字符，无字体栈即落 UI 印刷体（电脑硬刷体减号坏象）。与
  //   RealBoardPreview 同源：resolveHandwritingFont 唯一派生口，禁止字面量。
  const boardPreviewFontStack = resolveHandwritingFont(boardFontChoice).fontStack


  // board 列编辑状态：-1 表示无编辑，>=0 表示正在编辑的行索引
  const [editingBoardIndex, setEditingBoardIndex] = useSyncedRef<number>(-1)

  function parseBoard(board: any) {
    const n = normalizeBoard(board)
    // 把 0 还原为 null 以保持原模板显示语义（避免 +0s）
    return { content: n.content, startDelay: n.startDelay || null }
  }

  function renderBoardContent(board: any) {
    const { content } = parseBoard(board)
    if (!content) return ''
    // 每行先过 superFilter 12 步清洗，再转安全 HTML（堆叠记号不出字面）
    return renderBoardTextHtml(content)
  }

  // 列空间合理分配与自由折叠模式（支持按需折叠每列，超大留白，杜绝劣质滑动条）
  const [layoutPreset, setLayoutPreset] = useSyncedRef<string>('standard') // 'standard' | 'speech_focus' | 'board_focus' | 'custom'
  const [collapsedCols, setCollapsedCols, collapsedColsRef] = useSyncedRef<any>({
    speech: false,
    board: false,
    actionSpec: false,
  })

  function setLayoutPresetFn(preset: string) {
    setLayoutPreset(preset)
    setCollapsedCols({ ...collapsedColsRef.current, ...(LAYOUT_PRESETS[preset] || {}) })
  }

  function toggleColumn(colKey: string) {
    setLayoutPreset('custom')
    setCollapsedCols({ ...collapsedColsRef.current, [colKey]: !collapsedColsRef.current[colKey] })
  }

  // computed columns（渲染期直算；表头折叠按钮直接并入 title ReactNode，等价原 #headerCell）
  const isSpeechCol = collapsedCols.speech
  const isBoardCol = collapsedCols.board
  const isActionCol = collapsedCols.actionSpec
  const columns: any[] = [
    {
      title: '排序',
      key: 'index',
      width: 70,
      align: 'center',
      // #bodyCell：序号与拖拽把手列
      render: (_: any, record: any, index: number) => (
        <div className="cell-index-box">
          <div className="index-badge-row">
            <div
              className="row-drag-handle"
              draggable={true}
              title="按住鼠标拖拽此行调整顺序"
              onDragStart={(e: any) => onHandleDragStart(e, index)}
              onDragEnd={onRowDragEnd}
            >
              <HolderOutlined />
            </div>
            <span className="studio-row-badge">{index + 1}</span>
            {/* ★ 行打勾图标：试听完/已生成音频时立刻出现绿色勾，视觉反馈"这行备好了" */}
            {(record.audioUrl) && (
              <span
                className="row-audio-check"
                title={`第 ${index + 1} 行已有音频 · 真实时长 ${record.audioDurationMs ? (Math.round(record.audioDurationMs / 100) / 10) + 's' : '读取中'}`}
              >
                <CheckCircleOutlined />
              </span>
            )}
          </div>
        </div>
      ),
    },
    {
      title: '环节',
      key: 'stage',
      width: 88,
      align: 'center',
      // #bodyCell：环节列 (Stage)
      render: (_: any, record: any, index: number) => (
        <div className="cell-stage-box">
          <Popover trigger="click" placement="bottomLeft" overlayStyle={{ minWidth: '120px' }} content={
            <>
              <div className="stage-picker-title">切换环节</div>
              <Space orientation="vertical" size={4} style={{ display: 'flex' }}>
                {['题目', '分析', '解答', '总结'].map((opt: string) => (
                  <Button
                    key={opt}
                    size="small"
                    type={record.stage === opt ? 'primary' : 'text'}
                    className="stage-picker-btn"
                    onClick={() => updateRow(index, 'stage', opt)}
                  >
                    {opt}
                  </Button>
                ))}
              </Space>
            </>
          }>
            <button type="button" className={`stage-capsule stage-${record.stage}`} title="点击切换教学环节" aria-label={`第 ${index + 1} 行环节：${record.stage}，点击切换`}>
              {record.stage}
            </button>
          </Popover>
        </div>
      ),
    },
    {
      title: '口播稿',
      key: 'speech',
      width: isSpeechCol ? 78 : undefined,
      minWidth: isSpeechCol ? 78 : 300,
      // #bodyCell：口播稿列 (Speech)
      render: (_: any, record: any, index: number) => (
        <div className="cell-speech-box">
          {/* 口播列折叠态：精巧微缩胶囊，点击一键展开 */}
          {collapsedCols.speech ? (
            <div
              className="collapsed-cell-card speech-collapsed"
              title="口播稿已折叠，点击展开"
              onClick={() => toggleColumn('speech')}
            >
              <SoundOutlined className="collapsed-icon" />
              <span className="collapsed-text">{getRowEstimatedSeconds(record.speech).charCount}字</span>
              {record.audioUrl && <span className="collapsed-audio-dot" title="已记录音频">🎵</span>}
              <span className="collapsed-tip">展开</span>
            </div>
          ) : (
            /* 口播列展开态：舒展大卡片 */
            <div className="speech-textarea-card">
              <Input.TextArea
                value={record.speech}
                variant="borderless"
                aria-label={`第 ${index + 1} 行口播稿`}
                autoSize={{ minRows: 2, maxRows: 8 }}
                className="studio-speech-input"
                placeholder="输入口播稿…"
                onChange={(event: any) => updateRow(index, 'speech', event.target.value)}
              />
              <div className="speech-stat-footer">
                <div className="speech-stat-left">
                  <span className="speech-stat-chars">{getRowEstimatedSeconds(record.speech).charCount} 字</span>
                  <span className="speech-stat-divider">·</span>
                  <span className="speech-stat-time">
                    {record.audioDurationMs ? `音频 ${Math.round(record.audioDurationMs / 100) / 10} 秒` : `预估 ${getRowEstimatedSeconds(record.speech).seconds} 秒`}
                  </span>
                </div>
                <div className="speech-audio-actions">
                  <Button
                    size="small"
                    className="speech-btn-horn"
                    type={playingAudioIndex === index ? 'primary' : 'text'}
                    loading={synthesizingRowIndex === index}
                    title={playingAudioIndex === index ? '暂停播放' : (record.audioUrl ? '播放试听' : '生成本行语音')}
                    onClick={() => handlePlayOrSynthesizeSpeech(index, record)}
                    icon={playingAudioIndex === index ? <PauseCircleOutlined /> : <SoundOutlined />}
                  >
                    {playingAudioIndex === index ? '暂停' : (record.audioUrl ? '试听' : '生成语音')}
                  </Button>
                  <Dropdown
                    trigger={['click']}
                    menu={{ items: [
                      { key: 'preview', label: '播放已保存音频', icon: <PlayCircleOutlined />, disabled: !record.audioUrl, onClick: () => playAudioUrl(record.audioUrl, index, { alwaysRestart: true }) },
                      { key: 'regenerate', label: '重新生成语音', icon: <ReloadOutlined />, onClick: () => handleRegenerateSpeech(index, record) },
                      { key: 'save', label: '保存音频到本地', icon: <SaveOutlined />, onClick: () => handleSaveLocalSpeech(index, record) },
                      { type: 'divider' },
                      { key: 'copy', label: '复制音频链接', icon: <CopyOutlined />, disabled: !record.audioUrl, onClick: () => copyAudioUrl(record.audioUrl) },
                      { key: 'download', label: <a href={record.audioUrl || undefined} download={getAudioFilename(record.audioUrl)}>下载音频</a>, icon: <DownloadOutlined />, disabled: !record.audioUrl },
                    ] }}
                  >
                    <Button
                      type="text"
                      size="small"
                      className="speech-more-actions"
                      aria-label={`第 ${index + 1} 行语音操作`}
                      title="语音操作"
                      loading={regeneratingRowIndex === index || savingLocalRowIndex === index}
                      icon={<MoreOutlined />}
                    />
                  </Dropdown>
                </div>
              </div>
            </div>
          )}
        </div>
      ),
    },
    {
      title: '板书',
      key: 'board',
      width: isBoardCol ? 78 : undefined,
      minWidth: isBoardCol ? 78 : 300,
      // #bodyCell：板书内容列 (Board)
      render: (_: any, record: any, index: number) => (
        <div className="cell-board-box">
          {/* 板书列折叠态：精巧微缩胶囊，点击一键展开 */}
          {collapsedCols.board ? (
            <div
              className="collapsed-cell-card board-collapsed"
              title="板书内容已折叠，点击展开"
              onClick={() => toggleColumn('board')}
            >
              <span className="collapsed-icon">✍️</span>
              <span className="collapsed-text">{parseBoard(record.board).content.slice(0, 12) || '板书'}</span>
              <span className="collapsed-tip">展开</span>
            </div>
          ) : editingBoardIndex !== index ? (
            /* 板书列展开态 */
            <div
              className="board-card-view"
              role="button"
              tabIndex={0}
              aria-label={`编辑第 ${index + 1} 行板书`}
              onClick={() => setEditingBoardIndex(index)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                  event.preventDefault()
                  setEditingBoardIndex(index)
                }
              }}
            >
              <div className="board-card-topbar">
                <div className="board-tags-left">
                  {parseBoard(record.board).startDelay && (
                    <span
                      className="board-delay-tag"
                      title={`本行语音播放 +${parseBoard(record.board).startDelay}s 后动笔写板书`}
                    >
                      +{parseBoard(record.board).startDelay}s
                    </span>
                  )}
                </div>
                <span className="board-edit-hint">点击编辑板书</span>
              </div>
              <div className="board-math-render" style={{ fontFamily: boardPreviewFontStack }} dangerouslySetInnerHTML={{ __html: renderBoardContent(record.board) || '<span class="board-empty-hint">添加板书</span>' }} />
            </div>
          ) : (
            <div className="board-card-edit">
              <div className="board-edit-label">板书内容:</div>
              <Input.TextArea
                aria-label={`第 ${index + 1} 行板书内容`}
                value={parseBoard(record.board).content}
                autoSize={{ minRows: 2, maxRows: 8 }}
                className="board-content-input"
                onChange={(event: any) => updateBoardContent(index, event.target.value)}
              />
              {/* ★ Task 40：每行落笔延迟（书写延迟时间）手动编辑——branch2 旧血统被 squash
                   丢失的功能回归：0~60 秒（旧血统同区间），改后立即重算时间轴并刷 B 缓存 */}
              <div className="board-delay-edit">
                <span className="board-delay-edit-label">落笔延迟（秒）：</span>
                <InputNumber
                  aria-label="落笔延迟（秒）"
                  value={parseBoard(record.board).startDelay}
                  min={0}
                  max={60}
                  step={0.5}
                  precision={1}
                  size="small"
                  className="board-delay-input"
                  title="本行语音开始播放后，延迟多少秒才动笔写板书（0 = 语音一起笔）"
                  onChange={(value: any) => updateBoardStartDelay(index, value)}
                />
              </div>
              <div className="board-edit-actions">
                <Button size="small" type="primary" className="board-done-btn" onClick={() => setEditingBoardIndex(-1)}>
                  完成
                </Button>
              </div>
            </div>
          )}
        </div>
      ),
    },
    {
      title: '动作',
      key: 'actionSpec',
      width: isActionCol ? 64 : 104,
      align: 'center',
      // #bodyCell：板书动作列 (ActionSpec)
      render: (_: any, record: any, index: number) => (
        <div className="cell-action-box">
          {/* 动作列折叠态：极细胶囊 */}
          {collapsedCols.actionSpec ? (
            <div className="collapsed-action-wrap">
              {record.actionSpec && record.actionSpec.length ? (
                <Popover
                  trigger="click"
                  placement="left"
                  content={
                    <>
                      <div className="action-popover-title">当前行板书动作详情</div>
                      <Listy
                        items={record.actionSpec.map((item: any, index: number) => ({ ...item, __key: index }))}
                        rowKey={(item: any) => item.__key}
                        virtual={false}
                        className="action-popover-list"
                        style={{ width: 360, maxHeight: 400, overflow: 'auto' }}
                        itemRender={(item: any) => (
                          <Space orientation="vertical" size="small" style={{ width: '100%' }}>
                            <Space size={4} wrap>
                              {item.action?.order && <Tag color="blue">#{item.action.order}</Tag>}
                              <Tag color="cyan">{actionLabel(item)}</Tag>
                            </Space>
                            <div className="action-popover-content">{actionContent(item)}</div>
                          </Space>
                        )}
                      />
                    </>
                  }
                >
                  <div className="collapsed-action-pill" title="点击查看动作指令参数">
                    <span className="action-badge-icon">⚡</span>
                    <span className="action-badge-num">{record.actionSpec.length}</span>
                  </div>
                </Popover>
              ) : (
                <span className="action-empty-dash">—</span>
              )}
            </div>
          ) : record.actionSpec && record.actionSpec.length ? (
            /* 动作列展开态：★ Task 43 动作 1.0 编辑器（具象化——两动作/锚定文字/触发关键词，夏夏拍板） */
            <Popover
              trigger="click"
              placement="left"
              content={
                <>
                  <div className="action-popover-title">板书动作编辑（两动作 · 红色 · row 内互斥）</div>
                  <div className="action-edit-list">
                    {record.actionSpec.map((item: any, ai: number) => (
                      <div key={ai} className="action-edit-item">
                        <Space size={4} wrap style={{ width: '100%' }}>
                          <Tag color="blue">#{ai + 1}</Tag>
                          <Select
                            value={actionToolValue(item)}
                            size="small"
                            style={{ width: 108 }}
                            options={ACTION_TYPE_OPTIONS}
                            onChange={(v: any) => changeActionType(index, ai, v)}
                          />
                          <Button
                            type="text"
                            size="small"
                            danger
                            title="删除该动作"
                            onClick={() => removeRowAction(index, ai)}
                          >
                            删
                          </Button>
                        </Space>
                        {item.action?.tool === 'rough-notation' ? (
                          <>
                            <div className="action-edit-label">锚定文字（须在已写板书 / 题目原文中，按板书字面写）</div>
                            <Input
                              value={item.action?.target?.exactText}
                              size="small"
                              placeholder="要标记的完整原文"
                              status={(actionAnchorStatus(index, item) || undefined) as any}
                              onChange={(e: any) => updateActionExactText(index, ai, e.target.value)}
                            />
                            {actionAnchorStatus(index, item) === 'error' && (
                              <div className="action-edit-warn">
                                ⚠ 板书与题目均未找到该文字，播放时此动作会被跳过（分数请按板书字面写）
                              </div>
                            )}
                            <div className="action-edit-label">触发关键词（可选：口播说到该词时起笔）</div>
                            <Input
                              value={item.triggerKeyword}
                              size="small"
                              placeholder="本行口播原文中的词，空则默认串行"
                              status={(actionKeywordStatus(index, item) || undefined) as any}
                              onChange={(e: any) => updateActionKeyword(index, ai, e.target.value)}
                            />
                            {actionKeywordStatus(index, item) === 'error' && (
                              <div className="action-edit-warn">
                                ⚠ 关键词不在本行口播原文中，播放时将退回默认串行
                              </div>
                            )}
                          </>
                        ) : null}
                      </div>
                    ))}
                    <Button size="small" type="dashed" block style={{ marginTop: 8 }} onClick={() => addRowAction(index)}>
                      ＋ 添加动作
                    </Button>
                  </div>
                </>
              }
            >
              <button type="button" className="action-badge-pill active" title="点击编辑动作">
                {record.actionSpec.length} 项
              </button>
            </Popover>
          ) : (
            /* 无动作：一键添加 */
            <Button
              type="text"
              size="small"
              className="action-add-btn"
              title="添加第一个动作（下划线）"
              aria-label={`第 ${index + 1} 行添加动作`}
              onClick={() => addRowAction(index)}
            >
              添加
            </Button>
          )}
        </div>
      ),
    },
    {
      title: '操作',
      key: 'operations',
      width: 56,
      align: 'center',
      render: (_: any, record: any, index: number) => (
        <div className="cell-ops-box">
          <Popover
            trigger="click"
            placement="leftTop"
            content={
              <Space orientation="vertical" size={4} className="row-operations-menu">
                <Button type="text" size="small" className="btn-op-move" disabled={index === 0} onClick={() => moveRow(index, index - 1)} icon={<ArrowUpOutlined />}>上移此行</Button>
                <Button type="text" size="small" className="btn-op-move" disabled={index === rows.length - 1} onClick={() => moveRow(index, index + 1)} icon={<ArrowDownOutlined />}>下移此行</Button>
                <Button type="text" size="small" className="btn-op-add" onClick={() => insertRowAfter(index)} icon={<PlusOutlined />}>下方新增一行</Button>
                <Popconfirm title="确定要删除这一行吗？" okText="确定删除" cancelText="取消" onConfirm={() => deleteRow(index)}>
                  <Button type="text" danger size="small" className="btn-op-del" icon={<DeleteOutlined />}>删除此行</Button>
                </Popconfirm>
              </Space>
            }
          >
            <Button type="text" size="small" className="row-operations-trigger" aria-label={`第 ${index + 1} 行操作`} title="行操作" icon={<MoreOutlined />} />
          </Popover>
        </div>
      ),
    },
  ]

  // ponytail: 唯一字数+时长真源来自 timing.js (countCharacters 剥标点 + estimateSpeechDurationMs 含 1500ms 下限 + 标点停顿)
  function getRowEstimatedSeconds(speech: any) {
    const charCount = countCharacters(speech)
    const sec = Math.max(1, Math.round(estimateSpeechDurationMs(speech, { speed: canvasParamsRef.current?.speechSpeed || AGENT_B_V2_SPEECH_RATE }) / 1000))
    return { charCount, seconds: sec }
  }

  // 计算全表总预估时长与总字数（computed totalEstimatedStats → lazy 函数，serialize 逻辑内同源调用）
  function computeTotalEstimatedStats() {
    const rowsCur = rowsRef.current
    if (!rowsCur.length) return { charCount: 0, text: '0秒', seconds: 0 }
    let totalChars = 0
    let totalSpeechMs = 0
    rowsCur.forEach((r: any) => {
      totalChars += countCharacters(r.speech)
      // ★ Task 43 C 口径（夏夏拍板）：行时长认实测音频 audioDurationMs 唯一主时钟，
      // 无音频才退 160cpm 估算——对齐 timing.js computeRowGroupTimeline / row-player 同款优先链，
      // 总时长不再系统性高估（160cpm 慢于 TTS 真实语速）
      const measuredMs = Number(r.audioDurationMs)
      if (Number.isFinite(measuredMs) && measuredMs > 0) {
        totalSpeechMs += Math.round(measuredMs)
      } else {
        totalSpeechMs += estimateSpeechDurationMs(r.speech, { speed: canvasParamsRef.current?.speechSpeed || AGENT_B_V2_SPEECH_RATE })
      }
    })
    // ★ Task 52（夏夏「234 统一」分叉 4b）：gap 口径同步 timing.js/row-player——音频行 gap=0
    //   （onended 自然紧接），仅无音频行计入演示停顿；旧版一律 (n-1)×gap，音频行间虚长 1 秒/行
    const gapUnitMs = canvasParamsRef.current?.rowGapMs || AGENT_B_V2_ROW_GAP_MS
    const totalGapMs = rowsCur.slice(0, -1).reduce((acc: number, r: any) => acc + (rowHasRealAudio(r) ? 0 : gapUnitMs), 0)
    const totalSec = Math.round((totalSpeechMs + totalGapMs) / 1000)
    const m = Math.floor(totalSec / 60)
    const s = totalSec % 60
    const timeStr = `${m > 0 ? `${m}分` : ''}${s}秒`
    return { charCount: totalChars, text: timeStr, seconds: totalSec }
  }
  const totalEstimatedStats = computeTotalEstimatedStats()

  // 计算全表板书动作规范总数（computed totalActionCount → lazy 函数）
  function computeTotalActionCount() {
    const rowsCur = rowsRef.current
    if (!rowsCur.length) return 0
    return rowsCur.reduce((acc: number, r: any) => acc + (Array.isArray(r.actionSpec) ? r.actionSpec.length : 0), 0)
  }
  const totalActionCount = computeTotalActionCount()

  // ponytail: 合并所有行的 actionSpec 给画布预览播放
  // 纯前端本地数学算式口播兜底秒级转换（双保险核心）
  function runInstantMathAsrPolish() {
    if (!rowsRef.current.length) {
      message.warning('请先生成五字段执行表后再进行 ASR 兜底转换')
      return
    }
    const result = batchPolishRowsMathAsr(rowsRef.current)
    if (!result.changes.length) {
      message.success('当前口播稿已全部符合数学自然读音规范，无需调整 ╰(๑◕ ▿ ◕๑)╯')
      return
    }
    setPendingCheckRows(result.rows)
    setCheckChanges(result.changes)
    setCheckSource('math_asr')
    setCheckState('ready')
    setCheckResultOpen(true)
    setCheckFailedFallback(false)
    message.success(`已完成数学算式纯前端兜底分析，共发现 ${result.changes.length} 处规范化建议，已打开对比弹窗`)
  }

  // 行键来自统一 setRows/timeline 入口，编辑、重排和缓存恢复均保持同一身份。
  const tableRows = rows.map((row: any) => ({ ...row, _rowKey: row._rowUid }))

  // ↓ 以下 computed 全部渲染期直算（依赖 handoff/state/rows）
  const problemTypeLabel = ({
    geometry: '几何题',
    calculation: '计算题',
    word: '应用题',
  } as any)[handoff?.problemType] || handoff?.problemType || '未确认'
  const pureTextLabel = (handoff?.imageKind || 'text_only') === 'text_only' ? '是' : '否'
  const boardFocusLabel = ({
    geometry_diagram: '几何图解',
    calculation_process: '演算过程',
    relation_understanding: '关系理解',
    mixed: '综合分析',
  } as any)[handoff?.boardFocus] || handoff?.boardFocus || '未确认'
  const relatedKnowledge = Array.isArray(handoff?.relatedKnowledge)
    ? handoff.relatedKnowledge
    : []
  const knowledgeAnalysis = handoff?.knowledgeAnalysis || null
  const coreKnowledge = Array.isArray(knowledgeAnalysis?.coreKnowledge)
    ? knowledgeAnalysis.coreKnowledge
    : []
  const [selectedKnowledge, setSelectedKnowledge] = useState<any>(null)
  const keyFormulaList = Array.isArray(knowledgeAnalysis?.keyFormulaList)
    ? knowledgeAnalysis.keyFormulaList
    : []
  const uncertainItems = Array.isArray(handoff?.uncertainItems)
    ? handoff.uncertainItems
    : []
  const suggestedLayoutLabel = ({
    left_right: '左右布局',
    top_bottom: '上下布局',
  } as any)[handoff?.suggestedLayout?.layout] || handoff?.suggestedLayout?.layout || '无'
  const confirmedAtLabel = formatDisplayTime(handoff?.confirmedAt)
  const zoneParameterRows = (() => {
    const anchors = handoff?.zoneAnchors || {}
    const labels: Record<string, string> = { question: '题目区', analysis: '分析区', solution: '解答区', summary: '总结区' }
    return Object.entries(labels).map(([key, label]) => ({
      key,
      label,
      value: formatRegion(anchors[key]?.regionStartCoord),
    }))
  })()
  const handoffFlowSteps = [
    { title: '识别题目', status: 'finish', content: '第1步已确认' },
    { title: '判断题型', status: handoff?.problemType ? 'finish' : 'wait', content: problemTypeLabel },
    { title: '画布排版', status: handoff?.boardPlan ? 'finish' : 'wait', content: '真画布与四区布局' },
    {
      title: '知识关联',
      status: relatedKnowledge.length ? 'finish' : 'wait',
      content: relatedKnowledge.length ? `${relatedKnowledge.length} 条可选参考` : '可选，按题目判断',
    },
    { title: '组装输入', status: 'finish', content: '题目、图片、布局、工具' },
    {
      title: state === 'generating' ? '正在生成' : rows.length ? '已生成' : '待生成',
      status: state === 'generating' ? 'process' : rows.length ? 'finish' : 'wait',
      content: state === 'generating'
        ? '正在生成 Agent B 五字段'
        : rows.length
          ? `已生成 ${rows.length} 行`
          : '准备就绪 · 点击生成',
    },
  ]

  function invalidateCheck() {
    checkRunIdRef.current += 1
    setCheckState('idle')
    setPendingCheckRows(null)
  }

  function updateRow(index: number, field: string, value: any) {
    invalidateCheck()
    const list = rowsRef.current.slice()
    list[index] = { ...list[index], [field]: value }
    if (field === 'speech' || field === 'stage') {
      setRows(applyAgentBV2Timeline(list))
    } else {
      setRows(list)
    }
  }

  // 编辑 board.content，布局由渲染层负责。
  function updateBoardContent(index: number, content: string) {
    invalidateCheck()
    const current = parseBoard(rowsRef.current[index].board)
    const list = rowsRef.current.slice()
    list[index] = {
      ...list[index],
      board: { content, startDelay: current.startDelay },
    }
    setRows(list)
  }

  // ★ Task 40（2026-10-16）：手动书写延迟（落笔时机）唯一真源写入口。
  // branch2 旧血统（36d169d→298e5a3，未合入 HEAD）曾有每行「落笔时机 0-60 秒」输入框 +
  // updateBoardStartDelay，dependabot squash（36a960c）并线时静默丢失；数据结构 board.startDelay
  // 全链路本就认手动值（timing.js 手动值优先 / row-player normRow startDelay 消费 /
  // asrPolish「人工已显式设定时机，保留」），本处只补 UI 写入口。
  // 铁律（同 setRowAudioUrl 先例）：写真源 rows.value + applyAgentBV2Timeline 重算
  //（estimatedStartMs 系 startDelay 派生，改延迟必须重算）+ bCacheSet 同步刷（防刷新蒸发）。
  function updateBoardStartDelay(index: number, delay: any) {
    invalidateCheck()
    const current = parseBoard(rowsRef.current[index].board)
    const n = typeof delay === 'number' && !isNaN(delay) && delay >= 0 ? Math.min(delay, 60) : 0
    const list = rowsRef.current.slice()
    list[index] = {
      ...list[index],
      board: { content: current.content, startDelay: n },
    }
    const nextRows = applyAgentBV2Timeline(list)
    setRows(nextRows)
  }

  function actionToolValue(item: any) {
    const a = item?.action || {}
    return a.action || 'underline'
  }

  function updateRowActions(rowIndex: number, mutate: (list: any[]) => void) {
    const row = rowsRef.current[rowIndex]
    if (!row) return
    invalidateCheck()
    const next = (Array.isArray(row.actionSpec) ? row.actionSpec : []).filter(Boolean).map((x: any) => JSON.parse(JSON.stringify(x)))
    mutate(next)
    next.forEach((x: any, i: number) => { if (x.action) x.action.order = i + 1 })   // order 重编（1 起，与 moveRow 同款）
    const list = rowsRef.current.slice()
    list[rowIndex] = { ...row, actionSpec: next }
    const nextRows = applyAgentBV2Timeline(list)
    setRows(nextRows)
  }

  function changeActionType(rowIndex: number, ai: number, value: any) {
    updateRowActions(rowIndex, (list) => {
      const cur = list[ai]
      if (!cur) return
      const old = cur.action || {}
      const keepKw = cur.triggerKeyword != null ? { triggerKeyword: cur.triggerKeyword } : {}
      list[ai] = { ...keepKw, action: {
        tool: 'rough-notation',
        action: value,
        target: {
          region: old?.target?.region || old?.region || 'solution',
          exactText: old?.target?.exactText || '',
          occurrence: Math.round(old?.target?.occurrence ?? 1) || 1,
        },
        order: old.order || ai + 1,
        options: {},
      } }
    })
  }

  function updateActionExactText(rowIndex: number, ai: number, value: any) {
    updateRowActions(rowIndex, (list) => {
      const cur = list[ai]
      if (cur?.action?.tool === 'rough-notation' && cur.action.target) {
        cur.action.target = { ...cur.action.target, exactText: String(value ?? '') }
      }
    })
  }

  function updateActionKeyword(rowIndex: number, ai: number, value: any) {
    updateRowActions(rowIndex, (list) => {
      const cur = list[ai]
      if (!cur) return
      const kw = String(value ?? '').trim()
      if (kw) cur.triggerKeyword = kw
      else delete cur.triggerKeyword
    })
  }

  function addRowAction(rowIndex: number) {
    updateRowActions(rowIndex, (list) => {
      list.push({ action: {
        tool: 'rough-notation', action: 'underline',
        target: { region: 'solution', exactText: '', occurrence: 1 },
        order: list.length + 1, options: {},
      } })
    })
  }

  function removeRowAction(rowIndex: number, ai: number) {
    updateRowActions(rowIndex, (list) => { list.splice(ai, 1) })
  }

  function boardAnchorPool(rowIndex: number, region: string) {
    const src = rowsRef.current.slice(0, rowIndex + 1)   // 先前行+本行：对齐播放器 task.boardChars 累积语义
    const lines = src
      .filter((r: any) => !region || r?.stage === region || r?.stage === (REGION_STAGE_ZH as any)[region])
      .flatMap((r: any) => String(r?.board?.content || '').split('\n'))
      .filter(Boolean)
    return buildBoardAnchorFlow(lines)
  }
  function actionAnchorStatus(rowIndex: number, item: any) {
    const text = String(item?.action?.target?.exactText || '').trim()
    if (!text) return ''
    const tg = item?.action?.target || {}
    const occ = tg.occurrence || 1   // 与播放器一字不差（含旧档畸形值的 miss 行为也一致）：校验=播放预演
    const qPool = buildQuestionAnchorFlow(localHandoffRef.current?.problemText || '')
    const qHit = () => findRange(qPool, text, occ, { allowWrap: true })
    if (tg.region === 'question') return qHit() ? '' : 'error'
    const stg = String(tg.region || '')
    const bucketed = stg === 'analysis' || stg === 'solution' || stg === 'summary'
    if (findRange(boardAnchorPool(rowIndex, bucketed ? stg : ''), text, occ)) return ''
    if (!stg) return qHit() ? '' : 'error'   // 旧档缺 region：板书全局→题目，对齐播放器兜底顺序
    return 'error'
  }

  /* 触发关键词校验：必须逐字存在于本行口播原文（Task 43 契约），miss 走默认串行 */
  function actionKeywordStatus(rowIndex: number, item: any) {
    const kw = String(item?.triggerKeyword || '').trim()
    if (!kw) return ''
    return String(rowsRef.current[rowIndex]?.speech || '').includes(kw) ? '' : 'error'
  }

  // 视觉时间轴事件：点击某 Row 组定位并高亮表格对应行
  function onSelectRowFromTimeline(index: number) {
    setEditingBoardIndex(index)
    const allRows = document.querySelectorAll('.studio-table .ant-table-row')
    if (allRows && allRows[index]) {
      allRows[index].scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  }

  // ★ 时序全景时间轴块的试听按钮回调：复用 playAudioUrl 统一管理音频实例
  //  payload: { index, url }
  function onPlayAudioFromTimeline(payload: { index: number; url: string } = {} as any) {
    const { index, url } = payload || ({} as any)
    if (typeof index !== 'number' || !url) return
    playAudioUrl(url, index)
  }

  // ========= 口播语音 TTS 控制（Fish Audio 接口）=========
  // 异步回填用持久行 ID 和原口播定位；重排不串行，改稿或删除后拒收旧结果。
  function findAudioRowIndex(rowUid: string, speech: string) {
    return rowsRef.current.findIndex(row => row._rowUid === rowUid && row.speech === speech)
  }

  function setRowAudioUrl(rowUid: string, speech: string, url: string) {
    const index = findAudioRowIndex(rowUid, speech)
    if (!url || index < 0) return -1
    const list = rowsRef.current.slice()
    list[index] = { ...list[index], audioUrl: url }
    delete list[index].audioDurationMs
    delete list[index].duration
    setRows(applyAgentBV2Timeline(list))
    return index
  }
  const [playingAudioIndex, setPlayingAudioIndex, playingAudioIndexRef] = useSyncedRef<number | null>(null)
  const [synthesizingRowIndex, setSynthesizingRowIndex] = useSyncedRef<number | null>(null)
  const [regeneratingRowIndex, setRegeneratingRowIndex] = useSyncedRef<number | null>(null)
  const [savingLocalRowIndex, setSavingLocalRowIndex] = useSyncedRef<number | null>(null)
  // ★ 一键语音批量合成状态（2026-10-25 夏夏需求）：running 驱动按钮 loading，done/total 驱动按钮进度文案
  const [batchAudioState, setBatchAudioState, batchAudioStateRef] = useSyncedRef<{ running: boolean; done: number; total: number }>({ running: false, done: 0, total: 0 })
  const activeAudioRef = useRef<any>(null)

  function stopCurrentAudio() {
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.pause()
        activeAudioRef.current.currentTime = 0
      } catch (_err) {
        // ignore
      }
      activeAudioRef.current = null
    }
    setPlayingAudioIndex(null)
  }

  function readAudioDuration(url: string): Promise<number | null> {
    if (!url || typeof window === 'undefined' || !window.Audio) return Promise.resolve(null)
    return new Promise<number | null>((resolve) => {
      const audio = new window.Audio()
      const finish = (value: any) => {
        audio.removeEventListener('loadedmetadata', onMetadata)
        audio.removeEventListener('error', onError)
        resolve(Number.isFinite(value) && value > 0 ? Math.round(value * 1000) : null)
      }
      const onMetadata = () => finish(audio.duration)
      const onError = () => finish(null)
      audio.addEventListener('loadedmetadata', onMetadata, { once: true })
      audio.addEventListener('error', onError, { once: true })
      audio.src = url
    })
  }

  async function recordAudioMetadata(rowUid: string, speech: string, url: string) {
    const durationMs = await readAudioDuration(url)
    const index = findAudioRowIndex(rowUid, speech)
    if (index < 0 || rowsRef.current[index].audioUrl !== url) return -1
    if (durationMs) {
      const list = rowsRef.current.slice()
      list[index] = { ...list[index], audioDurationMs: durationMs }
      setRows(applyAgentBV2Timeline(list))
    }
    return index
  }

  async function playAudioUrl(url: string, index: number, options: { alwaysRestart?: boolean } = {}) {
    const record = rowsRef.current[index]
    if (!url || !record) return
    const { _rowUid: rowUid, speech } = record
    if (!options.alwaysRestart && playingAudioIndexRef.current === index && activeAudioRef.current) {
      stopCurrentAudio()
      return
    }
    stopCurrentAudio()

    if (typeof window === 'undefined' || !window.Audio) return
    const audio = new window.Audio(url)
    audio.preload = 'auto'
    // 关键修复：开头吞字根因 = 浏览器在 canplay 时缓冲不够就开始播，前几十毫秒还在解码。
    // 三个对策：
    //  (a) 用 canplaythrough 替代 canplay，等"足够播完整条"再开始
    //  (b) play 前 audio.currentTime = 0 强制回到最开头（防止上次残留进度）
    //  (c) play 前再 await 一个 120ms 的预热 tick，让解码管线充满
    activeAudioRef.current = audio
    setPlayingAudioIndex(index)

    audio.addEventListener('ended', () => {
      if (activeAudioRef.current === audio) {
        setPlayingAudioIndex(null)
        activeAudioRef.current = null
        void recordAudioMetadata(rowUid, speech, url)
      }
    })
    audio.addEventListener('error', () => {
      message.error('音频加载或播放失败')
      if (activeAudioRef.current === audio) {
        setPlayingAudioIndex(null)
        activeAudioRef.current = null
      }
    })

    try {
      // 只由原生 ended 事件结束本次试听，不使用预估时长或定时器切换。
      await new Promise((resolve, reject) => {
        const onCanPlayThrough = () => {
          audio.removeEventListener('canplaythrough', onCanPlayThrough)
          audio.removeEventListener('error', onLoadError)
          resolve(null)
        }
        const onLoadError = (event: any) => {
          audio.removeEventListener('canplaythrough', onCanPlayThrough)
          audio.removeEventListener('error', onLoadError)
          reject(event)
        }
        // canplaythrough = 浏览器认为已缓冲足够连续播完整条；比 canplay 更稳，几乎不会吞开头
        audio.addEventListener('canplaythrough', onCanPlayThrough, { once: true })
        audio.addEventListener('error', onLoadError, { once: true })
        audio.load()
      })
      // 强制回 0，避免某些浏览器复用 element 时残留 currentTime > 0
      try { audio.currentTime = 0 } catch (_) {}
      // 120ms 预热 tick：让音频解码管线充满，避免首帧被截
      await new Promise((r) => setTimeout(r, 120))
      if (activeAudioRef.current !== audio || findAudioRowIndex(rowUid, speech) < 0) return
      await audio.play()
    } catch (err) {
      console.warn('播放被浏览器安全策略阻止或中断:', err)
      if (activeAudioRef.current === audio) stopCurrentAudio()
    }
  }

  // 1. 小喇叭：手动生成本内容语音 / 试听播放
  async function handlePlayOrSynthesizeSpeech(index: number, record: any) {
    const currentUrl = record.audioUrl
    if (currentUrl) {
      playAudioUrl(currentUrl, index)
      return
    }

    const { _rowUid: rowUid, speech } = record
    const text = (speech || '').trim()
    if (!text) {
      message.warning('请先输入本行的口播文案内容')
      return
    }

    setSynthesizingRowIndex(index)
    showGlobalLoading('数据分析中...', `正在合成第 ${index + 1} 步拟真口播语音...`)
    try {
      const res = await fetch('/api/tts/synthesize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          referenceId: voiceReferenceIdRef.current,
          model: VOICE_MODEL,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok || !data.audioUrl) {
        throw new Error(data.error || '语音合成失败')
      }
      if (setRowAudioUrl(rowUid, speech, data.audioUrl) < 0) return
      const currentIndex = await recordAudioMetadata(rowUid, speech, data.audioUrl)
      if (currentIndex < 0) return
      message.success(`第 ${currentIndex + 1} 步口播语音生成成功`)
      playAudioUrl(data.audioUrl, currentIndex)
    } catch (err: any) {
      message.error(`语音生成失败: ${err.message || String(err)}`)
    } finally {
      hideGlobalLoading()
      setSynthesizingRowIndex(null)
    }
  }

  // 2. 重新生成语音
  async function handleRegenerateSpeech(index: number, record: any) {
    const { _rowUid: rowUid, speech } = record
    const text = (speech || '').trim()
    if (!text) {
      message.warning('请先输入本行的口播文案内容')
      return
    }

    setRegeneratingRowIndex(index)
    stopCurrentAudio()
    showGlobalLoading('数据分析中...', `正在重新生成第 ${index + 1} 步口播语音...`)
    try {
      const res = await fetch('/api/tts/synthesize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          referenceId: voiceReferenceIdRef.current,
          model: VOICE_MODEL,
          forceRefresh: true,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok || !data.audioUrl) {
        throw new Error(data.error || '重新生成语音失败')
      }
      if (setRowAudioUrl(rowUid, speech, data.audioUrl) < 0) return
      const currentIndex = await recordAudioMetadata(rowUid, speech, data.audioUrl)
      if (currentIndex < 0) return
      message.success(`第 ${currentIndex + 1} 步口播语音已重新生成`)
      playAudioUrl(data.audioUrl, currentIndex)
    } catch (err: any) {
      message.error(`重新生成失败: ${err.message || String(err)}`)
    } finally {
      hideGlobalLoading()
      setRegeneratingRowIndex(null)
    }
  }

  // 3. 保存本地并记录下载URL（与截图同规范配套存入 public/audio/ 与 public/pic/）
  async function handleSaveLocalSpeech(index: number, record: any) {
    const { _rowUid: rowUid, speech } = record
    const text = (speech || '').trim()
    if (!text) {
      message.warning('请先输入本行的口播文案内容')
      return
    }

    setSavingLocalRowIndex(index)
    showGlobalLoading('数据分析中...', `正在保存第 ${index + 1} 步音频至配套目录...`)
    try {
      const res = await fetch('/api/tts/save-local', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          referenceId: voiceReferenceIdRef.current,
          model: VOICE_MODEL,
          stepIndex: index,
          audioUrl: record.audioUrl || null,
          projectCode: deliverableResultRef.current?.projectCode || localHandoffRef.current?.projectCode || '',
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok || !data.urlPath) {
        throw new Error(data.error || '保存本地语音失败')
      }
      if (setRowAudioUrl(rowUid, speech, data.urlPath) < 0) return
      if (await recordAudioMetadata(rowUid, speech, data.urlPath) < 0) return
      message.success(`语音已保存至本地配套目录，并已记录下载 URL: ${data.urlPath}`)
    } catch (err: any) {
      message.error(`保存本地失败: ${err.message || String(err)}`)
    } finally {
      hideGlobalLoading()
      setSavingLocalRowIndex(null)
    }
  }

  // 4. ★ 一键语音（2026-10-25 夏夏需求）：批量生成全部缺失行音频——并发 3 恰好对齐 3 枚 Fish Key
  //    轮询（服务端 currentKeyIndex 逐请求轮换：3 路并发各占一枚，不抓着一枚 key 往死里用，
  //    免费接口并发限流友好）；波次推进 = 一行完成立即补位下一行（非整批等待）。
  //    每行独立回填 setRowAudioUrl + recordAudioMetadata（与行内小喇叭同款链路，绿勾/时长/时序全联动）。
  async function handleBatchGenerateAudio() {
    if (batchAudioStateRef.current.running) return
    const rowsNow: any[] = rowsRef.current || []
    // 目标行快照：有口播文案且尚无音频的行（文案在启动时捕获，避免执行中被用户编辑干扰）
    const targets: Array<{ idx: number; rowUid: string; speech: string; text: string }> = []
    rowsNow.forEach((r: any, i: number) => {
      const hasAudio = r.audioUrl
      const text = (r.speech || '').trim()
      if (text && !hasAudio) targets.push({ idx: i, rowUid: r._rowUid, speech: r.speech, text })
    })
    const noTextCount = rowsNow.filter((r: any) => !(r.speech || '').trim()).length
    if (targets.length === 0) {
      message.info(
        noTextCount > 0
          ? `当前 ${rowsNow.length} 行音频已齐全（${noTextCount} 行无口播文案，天然不需要语音）`
          : `当前 ${rowsNow.length} 行音频已齐全，无需批量生成；要重做某一行请用行内 ↻ 重新生成`
      )
      return
    }

    const CONCURRENCY = 3
    setBatchAudioState({ running: true, done: 0, total: targets.length })
    message.info(`🎵 一键语音启动：${targets.length} 行待合成 · 并发 ${CONCURRENCY}（对齐 3 枚 Fish Key 轮询）${noTextCount > 0 ? ` · ${noTextCount} 行无文案已跳过` : ''}`)

    let cursor = 0
    let done = 0
    let ok = 0
    const failures: number[] = []
    const worker = async () => {
      while (cursor < targets.length) {
        const target = targets[cursor++]
        try {
          if (findAudioRowIndex(target.rowUid, target.speech) < 0) continue
          const res = await fetch('/api/tts/synthesize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              text: target.text,
              referenceId: voiceReferenceIdRef.current,
              model: VOICE_MODEL,
            }),
          })
          const data = await res.json()
          if (!res.ok || !data.ok || !data.audioUrl) throw new Error(data.error || '语音合成失败')
          if (setRowAudioUrl(target.rowUid, target.speech, data.audioUrl) < 0) continue
          if (await recordAudioMetadata(target.rowUid, target.speech, data.audioUrl) < 0) continue
          ok++
        } catch {
          failures.push(target.idx)
        } finally {
          done++
          setBatchAudioState({ running: true, done, total: targets.length })
        }
      }
    }
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, targets.length) }, () => worker()))

    setBatchAudioState({ running: false, done: targets.length, total: targets.length })
    const skipped = targets.length - ok - failures.length
    if (skipped > 0) {
      message.info(`一键语音结束：成功 ${ok} 行，失败 ${failures.length} 行，${skipped} 行因口播改动或删除跳过旧结果`)
    } else if (failures.length === 0) {
      message.success(`✅ 一键语音完成：${ok}/${targets.length} 行全部合成成功（执行表绿勾与真实时长已实时回填）`)
    } else {
      const failText = failures.map((i) => `第 ${i + 1} 行`).join('、')
      message.warning(`一键语音结束：成功 ${ok}/${targets.length}，失败 ${failures.length} 行（${failText}）。多为免费接口瞬时限流，稍后对失败行点行内 ↻ 重试即可`)
    }
  }

  function insertRowAfter(index: number) {
    invalidateCheck()
    const newRow = {
      stage: rowsRef.current[index]?.stage || '分析',
      speech: '',
      board: { content: '' },
      actionSpec: [],
    }
    const list = rowsRef.current.slice()
    list.splice(index + 1, 0, newRow)
    setRows(applyAgentBV2Timeline(list))
    message.success('已在下方插入空白行，快来写下补充内容吧 ╰(๑◕ ▿ ◕๑)╯')
  }

  function deleteRow(index: number) {
    if (rowsRef.current.length <= 1) {
      message.warning('不能全部删完哦，最少要保留一行内容哈 ฅ(⌯꒦ິ³꒦ິ⌯)ฅ')
      return
    }
    invalidateCheck()
    const list = rowsRef.current.slice()
    list.splice(index, 1)
    setRows(applyAgentBV2Timeline(list))
    message.success('已成功删除该行 ٩(｡•ω•｡)و')
  }

  // Row 组手动拖拽排序与时间轴自动重算
  const [draggingIndex, setDraggingIndex, draggingIndexRef] = useSyncedRef<number>(-1)
  const [dragOverIndex, setDragOverIndex, dragOverIndexRef] = useSyncedRef<number>(-1)
  const [dropPosition, setDropPosition, dropPositionRef] = useSyncedRef<string>('') // 'before' | 'after' | ''

  function cleanupDrag() {
    setDraggingIndex(-1)
    setDragOverIndex(-1)
    setDropPosition('')
  }

  function onHandleDragStart(event: any, index: number) {
    setDraggingIndex(index)
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move'
      event.dataTransfer.setData('text/plain', String(index))
      const tr = event.target?.closest?.('tr')
      if (tr && event.dataTransfer.setDragImage) {
        event.dataTransfer.setDragImage(tr, 30, 20)
      }
    }
  }

  function onRowDragOver(event: any, index: number) {
    if (draggingIndexRef.current === -1) return
    event.preventDefault()
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'move'
    }

    if (draggingIndexRef.current === index) {
      setDragOverIndex(-1)
      setDropPosition('')
      return
    }

    setDragOverIndex(index)
    const rect = event.currentTarget.getBoundingClientRect()
    const offset = event.clientY - rect.top
    setDropPosition(offset < rect.height / 2 ? 'before' : 'after')
  }

  function onRowDragLeave(event: any, index: number) {
    if (event.currentTarget && event.relatedTarget && event.currentTarget.contains(event.relatedTarget)) {
      return
    }
    if (dragOverIndexRef.current === index) {
      setDragOverIndex(-1)
      setDropPosition('')
    }
  }

  function onRowDrop(event: any, index: number) {
    event.preventDefault()
    const sourceIndex = draggingIndexRef.current
    if (sourceIndex === -1 || sourceIndex === index) {
      cleanupDrag()
      return
    }

    // ponytail: 4 分支 if/else 改三元链（shrink -7 行）
    // after+source<index 或 before+source>index → target = index
    // after+source>index → target = index+1
    // before+source<index → target = index-1
    // dropPos==''（无明确位） → target = index
    const isAfter = dropPositionRef.current === 'after'
    const isBefore = dropPositionRef.current === 'before'
    const targetIndex = Math.max(0, Math.min(rowsRef.current.length - 1,
      (isAfter && sourceIndex > index) ? index + 1 :
      (isBefore && sourceIndex < index) ? index - 1 : index
    ))

    if (sourceIndex !== targetIndex) {
      moveRow(sourceIndex, targetIndex)
    }
    cleanupDrag()
  }

  function onRowDragEnd() {
    cleanupDrag()
  }

  function customRow(_record: any, index = 0) {
    // Vue 版返回 class 对象；React onRow 需 className 字符串（三态等价拼接）
    const rowClass = [
      draggingIndex === index ? 'table-row-dragging' : '',
      dragOverIndex === index && dropPosition === 'before' ? 'table-row-dragover-top' : '',
      dragOverIndex === index && dropPosition === 'after' ? 'table-row-dragover-bottom' : '',
    ].filter(Boolean).join(' ')
    return {
      className: rowClass || undefined,
      // React 合成事件为驼峰命名（ant-design-vue customRow 的 onDragover/onDragleave/onDrop 同语义）
      onDragOver: (e: any) => onRowDragOver(e, index),
      onDragLeave: (e: any) => onRowDragLeave(e, index),
      onDrop: (e: any) => onRowDrop(e, index),
    }
  }

  function moveRow(fromIndex: number, toIndex: number) {
    if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0) return
    if (fromIndex >= rowsRef.current.length || toIndex >= rowsRef.current.length) return

    invalidateCheck()
    const list = [...rowsRef.current]
    const [movedItem] = list.splice(fromIndex, 1)
    list.splice(toIndex, 0, movedItem)

    // 重新规范化 actionSpec 中的全局 order（单手一维递增，保证全局动作编号与时间线播放顺序严格一致）
    let globalOrder = 1
    list.forEach((r: any) => {
      if (Array.isArray(r.actionSpec)) {
        r.actionSpec.forEach((item: any) => {
          if (item?.action && typeof item.action === 'object') {
            item.action.order = globalOrder++
          }
        })
      }
    })

    // 核心：在拖拽完成后自动重新计算整个视频的时间轴序列
    setRows(applyAgentBV2Timeline(list, {
      rowGapMs: canvasParamsRef.current?.rowGapMs || AGENT_B_V2_ROW_GAP_MS,
    }))

    message.success(`已调整行顺序（第 ${fromIndex + 1} 行 ➔ 第 ${toIndex + 1} 行），并已自动重新计算全片视频时间轴 ╰(๑◕ ▿ ◕๑)╯`)
  }

  // 监听演播室 Row 间隔与语速参数变化，实时重新计算全片时间轴
  // （watch([canvasParams.rowGapMs, canvasParams.speechSpeed])；无 immediate，rows 空时为 no-op）
  useEffect(() => {
    if (rowsRef.current.length) {
      setRows(applyAgentBV2Timeline(rowsRef.current, {
        rowGapMs: canvasParamsRef.current?.rowGapMs || AGENT_B_V2_ROW_GAP_MS,
      }))
    }
  }, [canvasParams.rowGapMs, canvasParams.speechSpeed])

  // B 生成缓存：localStorage，2 小时过期（夏夏拍板 Task 43，原 24h），Shift+点击强制刷新
  // ponytail: 抽到 composables/useBCache.js，传 getter 避免循环依赖
  const { bCacheKey, bCacheGet, bCacheSet } = useBCache({
    getHandoff: () => localHandoffRef.current,
    getSelectedSkillId: () => selectedSkillIdRef.current,
    // ★ R8-⑤：模型进缓存键——env 预设/用户改配置后旧缓存失效（bCacheGet 另有比对防御）
    getModel: () => agentBApiConfig.model || '',
  })
  void bCacheKey

  async function generateRows(force = false) {
    if (stateRef.current === 'generating') return
    // ★ Task 58 布局修订合成链（夏夏拍板 2026-10-22）：预览页（board-preview 布局编辑模式）保存的
    // 布局修订在此吃进——按题目全文匹配（handoff 活档内容无 projectCode，problemText 是两端
    // 都必有的稳定键），覆写 handoff.boardPlan 真相源，并强制绕过 bCache（布局变了必须真重新
    // 生成，旧 rows 是按旧布局生成的）。修订标记常驻：换新题自然失配；同档多次重新生成每次都吃到
    // 最新修订。定位：布局调整前移生成环——到播放页才调布局已是「生米煮熟」，内容不会重新编排。
    try {
      const revision = readLayoutRevision()
      const currentProblemText = String(localHandoffRef.current?.problemText || '')
      if (
        revision?.boardPlan &&
        revision.problemText &&
        revision.problemText === currentProblemText
      ) {
        // ★ Task 60：applyBoardPlanRevision 三处同步（boardPlan+zoneAnchors+topicLayout）——
        // 只覆写 boardPlan 会让 zoneAnchors（LLM 动作落点）与 topicLayout（题目/标签渲染优先源）
        // 仍持旧坐标，「动作按旧坐标、文字按新布局」错位（60-a 实测揪出的镜像不同步）
        setLocalHandoff(applyBoardPlanRevision(localHandoffRef.current, revision.boardPlan))
        force = true
        message.info(`检测到布局修订（保存于 ${revision.savedAt || '未知时间'}）：已按新四区坐标更新布局，本次重新生成将跳过缓存`, 6)
      }
    } catch (_) { /* 修订标记损坏不阻断生成 */ }
    if (!force) {
      const cached = bCacheGet()
      if (cached) {
        // 2026-10-15 提速归一：旧缓存（写字 400ms/字、rowGap 1500ms 时代算的时间轴）恢复时一律重算，
        // 防止旧常量时代的 estimatedStartMs/estimatedDurationMs 混进新速度体系（防散关键一步）
        setRows(applyAgentBV2Timeline(cached.rows, {
          rowGapMs: canvasParamsRef.current?.rowGapMs || AGENT_B_V2_ROW_GAP_MS,
        }))
        setGeneratedModel(cached.model)
        setState('ready')
        message.info(`已使用缓存结果（${cached.rows.length}行），Shift+点击可强制刷新`)
        // ★ 音频生成只认用户点击（夏夏裁定 2026-10-27）：agentB 产物须先人工改稿 + 跑 Check Agent，
        //   之后用户自己点「一键语音」。缓存恢复点禁止自动调 handleBatchGenerateAudio——未改稿音频=废音频烧配额。
        return
      }
    }
    invalidateCheck()
    setState('generating')
    setErrorText('')
    startGeneratingTimer()
    try {
      // B 生成只请求剧本；不加载板书字体或发起字体网络请求。
      const result = await generateAgentBV2Rows({
        handoff: localHandoffRef.current,
        skillId: selectedSkillIdRef.current,
        rowGapMs: canvasParamsRef.current.rowGapMs,
        canvasParams: { ...canvasParamsRef.current },
      })
      setRows(result.rows)
      setGeneratedModel(result.model)
      setState('ready')
      bCacheSet(result.rows, result.model)
      message.success(`已生成 ${rowsRef.current.length} 行五字段执行表`)
      // ★ 音频生成只认用户点击（夏夏裁定 2026-10-27）：先改稿 + 跑 Check Agent，再由用户点「一键语音」。
      //   生成完成点禁止自动调 handleBatchGenerateAudio（越权自动 TTS = 废音频烧配额）。
      // 歧义弹窗：检测到弃用字段时提示用户（v2.0 startCoord / triggerAt / durationMs 等）
      if (Array.isArray(result.deprecationWarnings) && result.deprecationWarnings.length) {
        result.deprecationWarnings.forEach((w: string) => message.warning(w, 5))
      }
    } catch (error: any) {
      setState('error')
      setErrorText(error?.message || String(error))
      // ponytail: 静默软提示 — 不直接弹 message.error，改为 console.warn + 可展开的 errorText 条
      // 用户看到的是红色状态条(errorText ref 已绑定到模板上的 a-alert)，不是突兀的弹出框
      console.warn('[Agent B 生成失败]', errorTextRef.current)
    } finally {
      stopGeneratingTimer()
    }
  }

  async function checkRows(mode = 'standard') {
    if (!rowsRef.current.length || checkStateRef.current === 'checking') return
    checkRunIdRef.current += 1
    const runId = checkRunIdRef.current
    setCheckState('checking')
    setErrorText('')
    setCheckChanges([])
    try {
      const result = await checkAgentRows({
        rows: rowsWithoutInternalIds(rowsRef.current),
        mode,
      })
      if (runId !== checkRunIdRef.current) return
      setPendingCheckRows(result.rows)
      setCheckChanges(result.changes)
      setCheckSource('check_agent')
      setCheckState('ready')
      setCheckResultOpen(true)
      setCheckFailedFallback(result.checkStatus === 'failed_fallback')
      if (result.checkStatus === 'local_asr_polished') {
        message.success(result.changes.length ? `ASR 规范优化完成，发现 ${result.changes.length} 处口播/板书改进` : 'ASR 检查完成，当前内容已符合规范')
      } else if (checkFailedFallbackRef.current) {
        message.warning(`Check Agent 返回格式异常，已回退原表（${result.checkError || '未提供错误详情'}）。当前显示的是原表，未做任何修改。`)
      } else {
        message.success(result.changes.length ? `Check 完成，发现 ${result.changes.length} 处建议` : 'Check 完成，未发现需要修正的内容')
      }
    } catch (error: any) {
      if (runId !== checkRunIdRef.current) return
      setCheckState('error')
      setErrorText(error?.message || String(error))
      // ponytail: 静默软提示 — 不直接弹
      console.warn('[Check Agent 失败]', errorTextRef.current)
    }
  }

  function applyCheckChanges() {
    if (!pendingCheckRowsRef.current || !checkChangesRef.current.length) return
    const changeCount = checkChangesRef.current.length
    const isAsr = checkSourceRef.current === 'math_asr'
    // Check 只改四列；按原表位置保留行身份和未改口播的现有音频。
    const checkedRows = pendingCheckRowsRef.current.map((checked: any, index: number) => ({
      ...rowsRef.current[index],
      stage: checked.stage,
      speech: checked.speech,
      board: checked.board,
      actionSpec: checked.actionSpec,
    }))
    setRows(applyAgentBV2Timeline(checkedRows, {
      rowGapMs: canvasParamsRef.current?.rowGapMs || AGENT_B_V2_ROW_GAP_MS,
    }))
    if (!isAsr) {
      // Check Agent 结果同步写回服务端文件（文件即真相源）
      applyCheckResult(rowsWithoutInternalIds(rowsRef.current)).catch(() => {
        message.warning('本地已应用，但保存到服务端失败，刷新后会恢复为原版本')
      })
    }
    setPendingCheckRows(null)
    setCheckChanges([])
    setCheckState('idle')
    setCheckResultOpen(false)
    setCheckFailedFallback(false)
    message.success(isAsr ? `已应用 ${changeCount} 处数学读音口播规范化修改` : `已应用 ${changeCount} 处 Check 修改`)
  }

  function discardCheckChanges() {
    setPendingCheckRows(null)
    setCheckResultOpen(false)
    setCheckFailedFallback(false)
  }

  function exportSpeech() {
    if (!rowsRef.current.length) return
    exportSpeechMarkdown(rowsRef.current, {
      problemText: localHandoffRef.current?.problemText || '',
      model: generatedModelRef.current || agentBApiConfig.model || '',
      generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
      handoffCanvasParams: localHandoffRef.current?.canvasParams || null,
      // ★ v2.1：板书区字体行随当前下拉选择派生（否则导出 MD 恒写 handoff 默认态乔木 507）
      handwritingFontChoice: boardFontChoiceRef.current,
    })
    message.success('口播稿 MD 已导出')
  }

  function exportStoryboard() {
    if (!rowsRef.current.length) return
    const ratioData = localHandoffRef.current?.stageRatioSuggestion || localHandoffRef.current?.['环节配比占比'] || null
    exportStoryboardMarkdown(rowsRef.current, {
      problemText: localHandoffRef.current?.problemText || '',
      model: generatedModelRef.current || agentBApiConfig.model || '',
      generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
      canvasParams: JSON.parse(JSON.stringify(canvasParamsRef.current)),
      handoffCanvasParams: localHandoffRef.current?.canvasParams || null,
      // ★ v2.1：板书区字体行随当前下拉选择派生（同 exportSpeech）
      handwritingFontChoice: boardFontChoiceRef.current,
      handoffBoardPlan: localHandoffRef.current?.boardPlan || null,
      screenshotUrl: localHandoffRef.current?.screenshotUrl || '',
      problemType: localHandoffRef.current?.problemType || '',
      relatedKnowledge: relatedKnowledgeRef() || [],
      teachingFocus: knowledgeAnalysisRef()?.teachingFocus || '',
      keyFormulaList: keyFormulaListRef() || [],
      zoneAnchors: localHandoffRef.current?.zoneAnchors || null,
      stageRatioSuggestion: ratioData,
      stageRatios: ratioData?.suggestedRatio || null,
    })
    message.success('分镜表 MD 已导出')
  }

  // 渲染期直算值的 lazy getter（serializeCurrentDeliverableState 等命令式流程同源调用）
  function relatedKnowledgeRef() {
    return Array.isArray(localHandoffRef.current?.relatedKnowledge) ? localHandoffRef.current.relatedKnowledge : []
  }
  function knowledgeAnalysisRef() {
    return localHandoffRef.current?.knowledgeAnalysis || null
  }
  function keyFormulaListRef() {
    return Array.isArray(knowledgeAnalysisRef()?.keyFormulaList) ? knowledgeAnalysisRef().keyFormulaList : []
  }

  // 严格从当前应用运行时的响应式状态树实时序列化最新板书与时序数据（绝不读取 HTML 源码，绝不使用旧缓存）
  function serializeCurrentDeliverableState() {
    const code = deliverableResultRef.current?.projectCode || localHandoffRef.current?.projectCode || genProjectCodeTs()
    const hcp = localHandoffRef.current?.canvasParams || buildCanvasParams()
    // ★ v2.1：用户态字体选择（下拉）——交付物里的 fontSource.handwriting 必须与选择一致；
    //   handoff 契约层永远是默认态，此处用真源构造器覆写，保证只有一个构造点
    const boardFontSel = resolveHandwritingFont(boardFontChoiceRef.current)
    // ★ Task 60：默认四区改真源派生（原手押的两组抖动快照值系全部退役）
    const hbp = localHandoffRef.current?.boardPlan || localHandoffRef.current?.zoneAnchors || DEFAULT_BOARD_PLAN
    const ratioData = localHandoffRef.current?.stageRatioSuggestion || localHandoffRef.current?.['环节配比占比'] || null
    // ★ 第八轮关联性归一：配比随题型动态判断（detectStageRatio 五类 a/b/c/d/e），
    // 缺数据时逐字段"未提供"，不臆造固定比例污染导出产物（旧值 35/40/15/10 为臆造）
    const suggestedRatio = ratioData?.suggestedRatio || {}
    const stats = computeTotalEstimatedStats()
    const actionCount = computeTotalActionCount()

    // 逐行深层清洗并计算单手互斥执行计划（动作分档时长 1~2s：画圈 1s、下划线按字数 1~1.5~2s、横线 1s，绝不与板书重叠）
    const cleanRows = (rowsRef.current || []).map((r: any, idx: number) => {
      const parsedBoard = parseBoard(r.board)
      // ★ 用户硬约束: board 字段与 actionSpec 映射必须自带 stage，让 deliverable JSON 自描述
      //  - row.stage 仍然存在（行级 stage）
      //  - board.stage = 行级 stage（板书自描述，下游消费板书时不必反查 row）
      //  - 每个 actionSpec[i].stage = 行级 stage（动作映射自描述，下游消费动作时不必反查 row）
      //  这样即使 row 顺序变化或下游只取局部字段，board 与 actionSpec 仍然知道属于哪个 stage
      const rowStage = r.stage || (idx === 0 ? '题目' : '分析')
      const normalizedRow = {
        // ponytail: duration 统一为秒 (row-player 合同是秒, 不是毫秒)
        duration: Number(r.audioDurationMs) > 0
          ? Math.round(Number(r.audioDurationMs) / 1000 * 10) / 10  // ms → 秒, 保留1位小数
          : (Number(r.duration) || 0),
        durationLabel: Number(r.audioDurationMs) > 0 ? '真实音频时长' : '预估',
        stage: rowStage,
        speech: r.speech != null ? String(r.speech) : '',
        audioUrl: r.audioUrl || '音频暂未生成',
        // ★ mp3 契约字段（决策 #017 契约恢复）：真 URL 才写、未生成写空串。
        // 占位中文串只留在 audioUrl（BoardPreviewApp isRowAudioValid 显式排除该字面量）；
        // row-player normRow pick(['mp3','audio','audioUrl','voice']) mp3 优先命中。
        // （真源 rows 从不写占位串，r.audioUrl 要么空要么真 URL，此处可直接透传）
        mp3: r.audioUrl || '',
        audioDurationMs: Number(r.audioDurationMs) > 0 ? Math.round(Number(r.audioDurationMs)) : null,
        board: {
          // ★ 必须带 stage：板书字段自描述属于哪个 stage (题目/分析/解答/总结)
          stage: rowStage,
          content: parsedBoard.content || '',
          startDelay: typeof parsedBoard.startDelay === 'number' && !isNaN(parsedBoard.startDelay)
            ? parsedBoard.startDelay
            : 0,
        },
        // ★ 必须带 stage：actionSpec 映射里每个 action 自带 stage (与 row.stage 一致)
        //  - 原有 region 字段保留不动（是 B 给的英文 zone 名 question/analysis/solution/summary）
        //  - 新增 stage 字段为中文 stage 名 (题目/分析/解答/总结)，便于下游双重校验
        //  - 如果某条 actionSpec 已自带 stage 就尊重它（罕见，但允许跨 stage 动作）
        //  - safeDeepClone 先克隆, 再加 stage, 避免污染 Vue 响应式 state
        actionSpec: Array.isArray(r.actionSpec)
          ? safeDeepClone(r.actionSpec).map((a: any) => {
              if (!a || typeof a !== 'object') return a
              // 容错: actionSpec 项可能是 { action: {...} } 或直接 {...}
              // 优先给外层加 stage
              if (!a.stage) a.stage = rowStage
              // 若内层 action 子对象也没 stage, 顺便补上 (双保险)
              if (a.action && typeof a.action === 'object' && !a.action.stage) {
                a.action.stage = rowStage
              }
              return a
            })
          : [],
      }
      const computed = computeRowGroupTimeline(normalizedRow)
      return {
        ...normalizedRow,
        estimatedDurationMs: computed.rowTotalDurationMs,
        exclusiveExecutionPlan: computed.exclusiveExecutionPlan,
        timingPolicy: 'speech-full-board-action-mutually-exclusive',
      }
    })

    return {
      apiSpecVersion: '2.0.0',
      specificationSummary: 'Each row contains speech, board, and underline/circle actions; timing is computed by the program.',
      specAnnotation: `画布规格批注：尺寸 ${CANVAS_SIZE.width}x${CANVAS_SIZE.height}、比例、题目/板书字号、stage 四区坐标落座区间、越界与手稿风格。`,
      projectCode: code,
      problemText: localHandoffRef.current?.problemText || '',
      sourceImageUrl: localHandoffRef.current?.sourceImageDataUrl || localHandoffRef.current?.sourceImageUrl || '',
      keepOriginal: Boolean(localHandoffRef.current?.keepOriginal),
      screenshotUrl: localHandoffRef.current?.screenshotUrl || '',
      topicLayout: localHandoffRef.current?.topicLayout || null,
      // ★ 2026-10-13 归一化：删掉手写 canvasParams 副本（fontSize/lineHeight/boardSpeed 等
      // 全被 ...hcp 覆盖 = 死值陷阱，canvasWidth/Height 异名键全仓零消费）
      // 真源唯一 = stepHandoff.buildCanvasParams（hcp 的 fallback 本身就是它）
      canvasParams: {
        source: 'handoff (Agent A 根据题目实时判断，为唯一真相源)',
        ...hcp,
        // ★ v2.1：字体域整体按用户选择重建（fontSource 与 fontSize 三区文案一并双态——半边
        //   覆写会让 shaohua 档的描述标签仍写"乔木 507"）；handoff 契约层保持默认态不被污染
        ...buildCanvasParams(boardFontChoiceRef.current),
      },
      // handoff 四区布局（真相源）+ Label 坐标（row-player 标签贴纸位置真源）
      // ★ Task 60：逐键 fallback 改 DEFAULT_BOARD_PLAN 派生（原手押抖动快照值），哨兵锁死
      boardPlan: {
        canvas: { w: CANVAS_SIZE.width, h: CANVAS_SIZE.height },
        topicLabel: hbp.topicLabel || DEFAULT_BOARD_PLAN.topicLabel,
        question: {
          x: hbp.question?.x ?? DEFAULT_BOARD_PLAN.question.x,
          y: hbp.question?.y ?? DEFAULT_BOARD_PLAN.question.y,
          w: hbp.question?.w ?? DEFAULT_BOARD_PLAN.question.w,
          h: hbp.question?.h ?? '',
        },
        analysisLabel: hbp.analysisLabel || DEFAULT_BOARD_PLAN.analysisLabel,
        analysis: {
          x: hbp.analysis?.x ?? DEFAULT_BOARD_PLAN.analysis.x,
          y: hbp.analysis?.y ?? DEFAULT_BOARD_PLAN.analysis.y,
          w: hbp.analysis?.w ?? DEFAULT_BOARD_PLAN.analysis.w,
          h: hbp.analysis?.h ?? DEFAULT_BOARD_PLAN.analysis.h,
        },
        solutionLabel: hbp.solutionLabel || DEFAULT_BOARD_PLAN.solutionLabel,
        solution: {
          x: hbp.solution?.x ?? DEFAULT_BOARD_PLAN.solution.x,
          y: hbp.solution?.y ?? DEFAULT_BOARD_PLAN.solution.y,
          w: hbp.solution?.w ?? DEFAULT_BOARD_PLAN.solution.w,
          h: hbp.solution?.h ?? DEFAULT_BOARD_PLAN.solution.h,
        },
        summaryLabel: hbp.summaryLabel || DEFAULT_BOARD_PLAN.summaryLabel,
        summary: {
          x: hbp.summary?.x ?? DEFAULT_BOARD_PLAN.summary.x,
          y: hbp.summary?.y ?? DEFAULT_BOARD_PLAN.summary.y,
          w: hbp.summary?.w ?? DEFAULT_BOARD_PLAN.summary.w,
          h: hbp.summary?.h ?? DEFAULT_BOARD_PLAN.summary.h,
        },
        image: hbp.image || null,
      },
      // UI 可调参数（B 页面设置）—— 字体宪法 v2：全部真源派生（stepHandoff.js），不再硬编码
      // ★ v2.1：handwritingFontChoice 是数据键（随档走，下游 row-player/预览据此切字体栈）；
      //   handwritingFont 是人读冗余标签。两者在服务端 deliverableStoreHandler 二次归一。
      uiSettings: {
        coordinateMode: '百分比',
        questionFontSize: `${QUESTION_FONT_SIZE}px`,
        questionFontFamily: QUESTION_FONT_FAMILY,
        lineHeightPolicy: LINE_HEIGHT_POLICY_TEXT,
        audioSpeedPolicy: AUDIO_SPEED_POLICY_TEXT,
        rowGapMs: canvasParamsRef.current?.rowGapMs || AGENT_B_V2_ROW_GAP_MS,
        handwritingFontChoice: boardFontSel.choice,
        handwritingFont: boardFontSel.family,
        // ★ 音色随档走：记录本条交付物合成所用 reference_id，交付包可追溯
        voiceReferenceId: voiceReferenceIdRef.current,
      },
      // 题目信息与环节配比
      problemInfo: {
        screenshotUrl: localHandoffRef.current?.screenshotUrl || '',
        problemType: localHandoffRef.current?.problemType || '未提供',
        relatedKnowledge: relatedKnowledgeRef() || [],
        teachingFocus: knowledgeAnalysisRef()?.teachingFocus || '',
        keyFormulaList: keyFormulaListRef() || [],
        // ★ Task 60：zoneAnchors 兑底改真源重派生（extractZoneAnchors(DEFAULT_BOARD_PLAN)），
        //   原手押四键抖动快照值删除——同一函数与 buildStep1Handoff 同一构造口径
        zoneAnchors: localHandoffRef.current?.zoneAnchors || extractZoneAnchors(DEFAULT_BOARD_PLAN),
        stageRatios: {
          analysis: suggestedRatio.analysis || '未提供',
          solution: suggestedRatio.solution || '未提供',
          summary: suggestedRatio.summary || '未提供',
          introAndClosing: suggestedRatio.introAndClosing || '未提供',
        },
        stageRatioSuggestion: ratioData,
      },
      meta: {
        // ★ Task 14 政策同型补刀：臆造 fallback（'小学数学题'/'图文结合'/'小学阶段'/'核心知识点'）清零，
        // problemType/boardFocus 缺失写"未提供"；gradeLevel 真源=handoff.suggestedGrade；
        // knowledgeTitle 真源=relatedKnowledge[0] 的「知识点」字段
        problemType: localHandoffRef.current?.problemType || '未提供',
        boardFocus: localHandoffRef.current?.boardFocus || '未提供',
        gradeLevel: localHandoffRef.current?.suggestedGrade || '未提供',
        knowledgeTitle: localHandoffRef.current?.relatedKnowledge?.[0]?.['知识点'] || '未提供',
        canvasSize: { width: CANVAS_SIZE.width, height: CANVAS_SIZE.height },
      },
      stats: {
        totalDuration: stats?.seconds || 0,
        totalDurationText: stats?.text || '0秒',
        stepCount: cleanRows.length,
        charCount: stats?.charCount || 0,
        actionCount: actionCount || 0,
      },
      checkInfo: {
        checkApplied: checkStateRef.current === 'ready' || checkChangesRef.current.length > 0,
        changeCount: checkChangesRef.current.length,
      },
      rows: cleanRows,
    }
  }

  // ★ Task 13：useApiSpecDrawer 整套砍除——抽屉指向的 DELIVERABLE_API_SPEC.md / deliverable.schema.json
  // 全仓从未存在（6 处引用全 404 的幽灵契约链），下游规范入口收敛到导出 JSON 本体 + README

  // 固化生成最终交付产物单页：写入 public/deliverable/ 永久文件，刷新不丢失
  async function generateDeliverablePage() {
    if (!rowsRef.current.length) {
      message.warning('当前无生成内容，请先生成五字段后再固化产物单页')
      return
    }
    setDeliverableGenerating(true)
    try {
      // 严格从当前运行时状态树序列化最新数据
      const payload = serializeCurrentDeliverableState()

      const res = await fetch('/api/deliverable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deliverable: payload }),
      })
      const data = await res.json()
      if (data.ok) {
        setDeliverableResult(data)
        // 同步本地预览缓存作为双重保险
        // ★ Task 9 修复: 必须把 canvasParams 与 meta 一起写入 localStorage,
        //  否则 BoardPreviewApp 打开时 RealBoardPreview 拿不到 canvasParams
        //  (字号/字体/行高/画布尺寸全部丢失, 预览画布降级为静态常量)
        saveLiveBoardPreview({
          problemText: payload.problemText,
          topicLayout: payload.topicLayout,
          boardPlan: payload.boardPlan,
          sourceImageUrl: payload.sourceImageUrl,
          keepOriginal: payload.keepOriginal,
          rows: payload.rows,
          projectCode: data.projectCode,
          // ★ 必须带 canvasParams: 真相源 = handoff.canvasParams 或 buildCanvasParams()
          canvasParams: payload.canvasParams || localHandoffRef.current?.canvasParams || null,
          // ★ 必须带 meta: BoardPreviewApp.applyDeliverablePayload 从 payload.meta 读 canvasParams/model 等
          meta: {
            canvasParams: payload.canvasParams || localHandoffRef.current?.canvasParams || null,
            model: generatedModelRef.current || agentBApiConfig.model || '',
            generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
            handoffCanvasParams: localHandoffRef.current?.canvasParams || null,
            handoffBoardPlan: localHandoffRef.current?.boardPlan || null,
            problemType: localHandoffRef.current?.problemType || '',
            stageRatioSuggestion: localHandoffRef.current?.stageRatioSuggestion || localHandoffRef.current?.['环节配比占比'] || null,
          },
          // ★ 同时带 screenshotUrl 与 problemText 等下游消费字段
          screenshotUrl: payload.screenshotUrl || localHandoffRef.current?.screenshotUrl || '',
          problemType: localHandoffRef.current?.problemType || '',
        })
        setDeliverableModalOpen(true)
        message.success('教学视频素材产物单页已成功生成并归档！')
      } else {
        message.error(`生成产物单页失败：${data.error || '未知错误'}`)
      }
    } catch (err: any) {
      message.error(`生成产物单页网络异常：${err.message || String(err)}`)
    } finally {
      setDeliverableGenerating(false)
    }
  }

  // ★ 2026-10-26 商业交付标准化：下载标准交付包 ZIP（播放页 + 行音频 + 题目图 +
  //   工程 JSON + manifest 验收清单 + README，解包双击即可离线播放）。
  //   与弹窗现有两入口同源：优先本次生成结果 projectCode，兑底 handoff 档编码；
  //   缺省两者时走 /export 当前档口径（服务端 404 语义会引导先生成交付单页）。
  function downloadReleasePackage() {
    const code = deliverableResultRef.current?.projectCode || localHandoffRef.current?.projectCode || ''
    const href = code
      ? `/api/deliverable/export?projectCode=${encodeURIComponent(code)}`
      : '/api/deliverable/export'
    const a = document.createElement('a')
    a.href = href
    document.body.appendChild(a)
    a.click()
    a.remove()
    message.success('标准交付包已开始下载（含播放页、音频与验收清单）')
  }

  // ★ Task 40-E（2026-10-16）：打开前必先重新固化当前状态树。旧版直接开
  // deliverableResult.url（上次 generateDeliverablePage 的归档快照），模态框若一直
  // 开着、期间又改了板书/重录了音频，点「立即打开」看到的就是旧内容（「导出的是旧
  // 东西」实感来源）。归一后：每次打开 = 最新状态重新落盘再开（同 projectCode 覆写
  // 同一归档，openHanddrawPlayer 同款 POST 语义）；重新固化失败不阻断（回退上次归
  // 档 URL / row-player 实时序列化兑底）。
  async function openDeliverablePage() {
    if (rowsRef.current.length) {
      try {
        const payload = serializeCurrentDeliverableState()
        const res = await fetch('/api/deliverable', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ deliverable: payload }),
        })
        const data = await res.json()
        if (data.ok && data.url) {
          setDeliverableResult(data)
          window.open(data.url, '_blank')
          return
        }
        console.warn('[openDeliverablePage] 重新固化失败，回退上次归档 URL:', data?.error)
      } catch (e) {
        console.warn('[openDeliverablePage] 重新固化网络异常，回退上次归档 URL:', e)
      }
    }
    if (deliverableResultRef.current?.url) {
      window.open(deliverableResultRef.current.url, '_blank')
      return
    }
    openHanddrawPlayer()
  }

  async function openHanddrawPlayer() {
    const payload = serializeCurrentDeliverableState()
    ;(window as any)._LATEST_AGENT_B_RESULT = payload

    // 1. 同步写入 localStorage，作为离线/无网络/直开双保险
    try {
      localStorage.setItem('agent-b-deliverable', JSON.stringify(payload))
    } catch (e) {
      console.warn('[openHanddrawPlayer] localStorage 写入失败', e)
    }

    // 2. 先归档再打开（★ Task 13 竞态修复）：await POST 落盘完成后再开窗，
    //    避免 row-player 优先 fetch 服务端 current 时播到上一题；归档失败不阻断（走 localStorage 兑底）
    try {
      await fetch('/api/deliverable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
    } catch (e) {
      console.warn('[openHanddrawPlayer] 后端归档失败，将走 localStorage 兑底', e)
    }

    // 3. 打开 row-player.html 页面，传入 ?deliverable=/api/deliverable
    window.open('/row-player.html?deliverable=/api/deliverable', '_blank')
  }

  function downloadDeliverableJson() {
    if (!rowsRef.current.length) {
      message.warning('当前无板书数据，请先生成或添加板书后再导出 JSON')
      return
    }
    // 1. 严格从当前应用运行时的响应式状态树（state tree）实时序列化，绝不从已归档的旧快照中读取，更绝不发起网络请求获取 HTML
    // ★ Task 40-A：客户端 JSON 出口补 #017 归一（与服务端双出口同一实现，共享真源）——
    //   旧版只序列化不归一，mp3/audioUrl 带站点根绝对路径 /audio-cache/...，
    //   file:// 双击 row-player「导入 JSON」必 404 静音（#017 同型缺口第三出口）；
    //   题目图 screenshotUrl（/pic/ → ../pic/）同规，离线双击不再丢图。序列化返回全新对象图，原地归一无副作用。
    const deliverableData = normalizeDeliverableAssetPaths(serializeCurrentDeliverableState())
    const code = deliverableData.projectCode || 'deliverable'

    // 2. 序列化为规范格式化 JSON 字符串
    const jsonContent = JSON.stringify(deliverableData, null, 2)

    // 3. 严格使用客户端原生 Blob 触发下载，指定纯净 application/json;charset=utf-8，确保 100% 纯正实体 JSON
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `deliverable-${code}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    message.success(`已成功从当前状态树导出并下载配套 JSON：deliverable-${code}.json`)
  }

  // 知识点修缮：手动触发，调 POST /api/knowledge/refine，成功后弹结果弹窗，用户点应用才更新
  async function refineKnowledge() {
    if (refineLoadingRef.current) return
    setRefineLoading(true)
    try {
      // ★ 2026-10-14：裸 fetch+resp.json() → safeJsonFetch（非 JSON 响应/超时/连接中断
      // 都给可读报错，不再吐裸 "Unexpected token" 解析错误）；客户端 100s 超时覆盖
      // 服务端单次上游 60s 预算（服务端已改超时不重试，总时长 ≤ 61s）
      const result = await safeJsonFetch('/api/knowledge/refine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpoint: userApiConfig.endpoint,
          model: userApiConfig.model,
          apiKey: userApiConfig.apiKey,
        }),
      }, { label: '知识点优化', timeoutMs: 100000 })
      if (result.ok && result.handoff) {
        // ★ 2026-10-13：降级响应（refineOk=false）时透出 warning，用户能看到"已保留原知识库"的原因
        if (result.warning) message.warning(result.warning)
        // ★ R8-① A 方案：result 仅是修缮提案，服务端活档此刻仍是原文——
        // 点「应用修缮」才会 POST /apply 落盘，点「保留原文」两端都零改动
        setRefineResult(result)
        setRefineResultOpen(true)
      } else {
        message.error(result.error || '优化失败')
      }
    } catch (error: any) {
      message.error(error?.message || '优化异常')
    } finally {
      setRefineLoading(false)
    }
  }

  // 应用修缮结果：★ R8-① A 方案——先 POST /api/knowledge/apply 落盘确认，成功后才更新页面。
  // 服务端以当前活档为基底做白名单重合并（防提案过期卷回别环修缮），返回值即存档真容，无需二次拉档
  async function applyRefine() {
    if (refineApplyingRef.current) return
    if (!refineResultRef.current?.handoff) return
    // refineResult 被 Vue ref 代理，handoff 对象带 ReactiveEffect 循环引用
    // 必须 toRaw + 安全深拷贝脱壳后再发请求，杜绝潜在的不可序列化对象抛错
    const proposal = safeDeepClone(refineResultRef.current.handoff)
    setRefineApplying(true)
    try {
      // ★ 2026-10-14：apply 同换 safeJsonFetch（与 refine 同源的裸 resp.json() 隐患）
      const data = await safeJsonFetch('/api/knowledge/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ handoff: proposal }),
      }, { label: '应用修缮', timeoutMs: 30000 })
      if (!data?.ok) {
        message.error(data?.error || '应用失败')
        return // 弹窗保留，可重试或改选保留原文
      }
      setLocalHandoff(data.handoff ? safeDeepClone(data.handoff) : proposal)
      setRefineAppliedAt(new Date().toISOString())
      setRefineResultOpen(false)
      setRefineResult(null)
      message.success('知识点修缮已确认落盘，活档与页面已同步')
    } catch (error: any) {
      message.error(error?.message || '应用异常，活档未改动')
    } finally {
      setRefineApplying(false)
    }
  }

  // 保留原文：★ R8-① A 方案后名副其实——refine 从未落盘，关弹窗即两端零改动，
  // B（前端态）与 Check（活档）保持同一基准，不再分叉
  function keepOriginalRefine() {
    setRefineResultOpen(false)
    setRefineResult(null)
  }

  // ★ vueShim reactive 单例订阅 → React 渲染同步（版本号驱动重渲染；API 配置弹窗 v-model
  //   直接改写代理属性，语义与 ant-design-vue 一致；Task 4-a Step1Entry 同款）
  //   第三参 getServerSnapshot：SSR 水合必需（缺省会 "Missing getServerSnapshot" 500，见 dev.log 实锤）
  useSyncExternalStore(
    (onStoreChange) => subscribeReactive(agentBApiConfig, onStoreChange),
    () => getReactiveVersion(agentBApiConfig),
    () => getReactiveVersion(agentBApiConfig),
  )

  return (
    <Layout className="qh-page">
      <QhPageHeader
        stepLabel="第 2 步 · Agent B"
        subtitle="题目信息 → 五字段"
        showBack
        onBack={() => onBackToStep1?.()}
        actions={
          <>
            <Popconfirm
              title="清理历史缓存和运行产物？"
              description="当前 handoff、当前交付物和源码不会被删除。"
              okText="清理"
              cancelText="取消"
              onConfirm={cleanupGeneratedFiles}
            >
              <Button title="清理垃圾" loading={cleanupLoading} danger icon={<DeleteOutlined />}>
                清理垃圾
              </Button>
            </Popconfirm>
            <Button
              title="可用工具"
              onClick={() => setToolsOpen(!toolsOpenRef.current)}
              icon={<ToolOutlined />}
            >
              工具
            </Button>
          </>
        }
      />

      <Layout.Content className="qh-page-content">
        <Space
          orientation="vertical"
          size="middle"
          style={{ width: '100%' }}
        >
          {/* ponytail: 交接状态进度条独立放在交接台卡片之外（用户要求） */}
          <div className="handoff-progress-strip">
            <span className="handoff-summary-label">交接状态</span>
            <Steps
              className="qh-handoff-steps"
              size="small"
              items={handoffFlowSteps as any}
            />
          </div>

          <Card
            className="qh-surface-card handoff-workbench-card"
            size="small"
            title={
              <div className="handoff-card-title">
                <span className="handoff-title-text">输入交接台</span>
              </div>
            }
            extra={
              <Space size="small">
                <Button
                  size="small"
                  loading={refineLoading}
                  onClick={refineKnowledge}
                >
                  优化题目分析
                </Button>
                <Button
                  size="small"
                  aria-expanded={handoffDetailsExpanded}
                  aria-controls="agentb-handoff-details"
                  onClick={() => setHandoffDetailsExpanded(!handoffDetailsExpanded)}
                >
                  {handoffDetailsExpanded ? '收起详情' : '输入详情'}
                </Button>
              </Space>
            }
          >
            {uncertainItems.length > 0 && (
              <Button type="link" size="small" className="handoff-pending-notice" title={uncertainItems.map((item: any) => displayValue(item)).join('；')} onClick={() => setHandoffDetailsExpanded(true)}>
                有 {uncertainItems.length} 项待确认，请查看输入详情
              </Button>
            )}

            <div
              id="agentb-handoff-details"
              className="handoff-details-collapsible"
              hidden={!handoffDetailsExpanded}
            >
            <div className="handoff-overview">
              <div className="handoff-stats-chips">
                <span className="handoff-stat-tag">题目 1 道</span>
                <span className="handoff-stat-tag">画布分区 {handoff?.boardPlan ? 4 : 0} 个</span>
                <span className="handoff-stat-tag">知识参考 {relatedKnowledge.length} 条</span>
                <span className="handoff-stat-tag">建议年级 {handoff?.suggestedGrade || '未判断'}</span>
              </div>
              <div className="studio-params-panel">
                <div className="params-panel-header">
                  <span className="params-panel-title">画布规格</span>
                </div>
                <div className="params-panel-controls">
                  <span className="param-coord-pill">
                    {CANVAS_SIZE.width}×{CANVAS_SIZE.height} · 四区布局
                  </span>
                  <span className="param-coord-pill secondary">
                    题目区：微软雅黑 {QUESTION_FONT_SIZE}px / 板书三区：手写体 {handoff?.canvasParams?.fontSize?.analysis?.px || BOARD_FONT_SIZE}px
                  </span>
                </div>
              </div>
              <p className="workbench-context">
                {problemTypeLabel} · {currentSkillName}{generatedModel ? ` · ${generatedModel}` : ''}
              </p>
            </div>

            {/* ponytail: 三大板块改 a-tabs 切换（消除横向滑动条 + 卡片高度不齐的分合感） */}
            <Card className="handoff-block-card" variant="borderless" size="small">
              <Tabs
                type="card"
                size="small"
                className="handoff-tri-tabs"
                aria-label="输入交接信息"
                items={[
                  {
                    key: 'ratio',
                    label: '配比与参数',
                    children: (
                      <>
                        {(handoff?.stageRatioSuggestion || handoff?.['环节配比占比']) && (
                          <div className="stage-ratio-suggestion">
                            <Descriptions
                              bordered
                              size="small"
                              column={2}
                              className="handoff-descriptions"
                            >
                              <Descriptions.Item label="题型分类">
                                <div className="field-val-box">
                                  <div className="field-val-main">
                                    <Tag color="purple">
                                      {(handoff.stageRatioSuggestion || handoff['环节配比占比']).cuCode} · {(handoff.stageRatioSuggestion || handoff['环节配比占比']).type}
                                    </Tag>
                                    {(handoff.stageRatioSuggestion || handoff['环节配比占比']).confidence === 'high' && <Tag color="green">高置信</Tag>}
                                    {(handoff.stageRatioSuggestion || handoff['环节配比占比']).confidence === 'medium' && <Tag color="orange">中置信</Tag>}
                                  </div>
                                  <span className="qh-field-key">cuCode</span>
                                </div>
                              </Descriptions.Item>
                              <Descriptions.Item label="环节配比占比">
                                <div className="ratio-bars-wrap">
                                  <span className="ratio-pill analysis">分析 {(handoff.stageRatioSuggestion || handoff['环节配比占比']).suggestedRatio.analysis}</span>
                                  <span className="ratio-pill solution">解答 {(handoff.stageRatioSuggestion || handoff['环节配比占比']).suggestedRatio.solution}</span>
                                  <span className="ratio-pill summary">总结 {(handoff.stageRatioSuggestion || handoff['环节配比占比']).suggestedRatio.summary}</span>
                                  <span className="ratio-pill intro">开收场 {(handoff.stageRatioSuggestion || handoff['环节配比占比']).suggestedRatio.introAndClosing}</span>
                                </div>
                              </Descriptions.Item>
                            </Descriptions>
                          </div>
                        )}
                        <Descriptions
                          bordered
                          size="small"
                          column={2}
                          className="handoff-descriptions"
                          style={{ marginTop: 10 }}
                        >
                          <Descriptions.Item label="题目类型">
                            <div className="field-val-box">
                              <span className="field-val-main">{problemTypeLabel}</span>
                              <span className="qh-field-key">problemType</span>
                            </div>
                          </Descriptions.Item>
                          <Descriptions.Item label="建议年级">
                            <div className="field-val-box">
                              <span className="field-val-main">{handoff?.suggestedGrade || '未判断'}</span>
                              <span className="qh-field-key">suggestedGrade</span>
                            </div>
                          </Descriptions.Item>
                          <Descriptions.Item label="板书侧重">
                            <div className="field-val-box">
                              <span className="field-val-main">{boardFocusLabel}</span>
                              <span className="qh-field-key">boardFocus</span>
                            </div>
                          </Descriptions.Item>
                          <Descriptions.Item label="建议布局">
                            <div className="field-val-box">
                              <span className="field-val-main">{suggestedLayoutLabel}</span>
                              <span className="qh-field-key">suggestedLayout</span>
                            </div>
                          </Descriptions.Item>
                          <Descriptions.Item label="画布参数" span={2}>
                            {handoff?.canvasParams ? (
                              <div className="canvas-params-desc-box">
                                <div className="canvas-params-chips-wrap">
                                  <span className="canvas-param-chip">
                                    <span className="chip-k">尺寸</span>
                                    <span className="chip-v">{handoff.canvasParams.canvasSize.width}×{handoff.canvasParams.canvasSize.height}px</span>
                                  </span>
                                  <span className="canvas-param-chip">
                                    <span className="chip-k">题目区字体</span>
                                    <span className="chip-v">微软雅黑 {QUESTION_FONT_SIZE}px</span>
                                  </span>
                                  <span className="canvas-param-chip">
                                    <span className="chip-k">板书三区字号</span>
                                    <span className="chip-v">{handoff.canvasParams.fontSize.analysis.px}px</span>
                                  </span>
                                  <span className="canvas-param-chip">
                                    <span className="chip-k">行高</span>
                                    <span className="chip-v">自然（无强制行高规范）</span>
                                  </span>
                                </div>
                                <span className="qh-field-key">canvasParams</span>
                              </div>
                            ) : (
                              <span className="param-empty-text">未携带画布参数</span>
                            )}
                          </Descriptions.Item>
                          <Descriptions.Item label="四区参数" span={2}>
                            <div className="field-val-box wrap-box">
                              <div className="field-val-main">
                                <div className="zone-tags-grid">
                                  {zoneParameterRows.map((zone: any) => (
                                    <div
                                      key={zone.key}
                                      className="zone-param-chip"
                                    >
                                      <span className="zone-chip-label">{zone.label}</span>
                                      <span className="zone-chip-val">{zone.value}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <span className="qh-field-key">zoneAnchors</span>
                            </div>
                          </Descriptions.Item>
                        </Descriptions>
                      </>
                    ),
                  },
                  {
                    key: 'meta',
                    label: '交接信息',
                    children: (
                      <Descriptions
                        bordered
                        size="small"
                        column={2}
                        className="handoff-descriptions"
                      >
                        <Descriptions.Item label="交接来源">
                          <div className="field-val-box">
                            <span className="field-val-main">{handoff?.agentPageName || 'Agent A'} · {handoff?.agentCapability || '未声明能力'} · v{handoff?.handoffVersion || 1}</span>
                            <span className="qh-field-key">agentMeta</span>
                          </div>
                        </Descriptions.Item>
                        <Descriptions.Item label="交接时间">
                          <div className="field-val-box">
                            <span className="field-val-main">{confirmedAtLabel}</span>
                            <span className="qh-field-key">confirmedAt</span>
                          </div>
                        </Descriptions.Item>
                        <Descriptions.Item label="是否纯文本">
                          <div className="field-val-box">
                            <span className="field-val-main">{pureTextLabel}</span>
                            <span className="qh-field-key">imageKind</span>
                          </div>
                        </Descriptions.Item>
                        <Descriptions.Item label="画布截图">
                          <div className="field-val-box">
                            {handoff?.screenshotUrl ? (
                              <span className="meta-path-val">
                                {handoff.screenshotUrl}
                              </span>
                            ) : (
                              <span className="param-empty-text">暂无截图</span>
                            )}
                            <span className="qh-field-key">screenshotUrl</span>
                          </div>
                        </Descriptions.Item>
                        <Descriptions.Item label="知识库地址">
                          <div className="field-val-box">
                            <span className="meta-path-val">
                              {handoff?.knowledgeBasePath || 'doc/knowledge-a.compact.json'}
                            </span>
                            <span className="qh-field-key">knowledgeBasePath</span>
                          </div>
                        </Descriptions.Item>
                        <Descriptions.Item label="四区布局">
                          <div className="field-val-box">
                            <span className="field-val-main">
                              <Badge status={handoff?.boardPlan ? 'success' : 'default'} text={handoff?.boardPlan ? '已确认（标准四区网格）' : '未确认'} />
                            </span>
                            <span className="qh-field-key">boardPlan</span>
                          </div>
                        </Descriptions.Item>
                      </Descriptions>
                    ),
                  },
                  {
                    key: 'kg',
                    label: '题目分析与知识点',
                    children: (
                      <>
                        {refineAppliedAt && (
                          <Alert
                            type="success"
                            showIcon
                            className="refine-applied-alert"
                            title={`本次修缮已写入当前 handoff（${new Date(refineAppliedAt).toLocaleTimeString()}）`}
                          />
                        )}
                        <Descriptions
                          bordered
                          size="small"
                          column={2}
                          className={`handoff-descriptions${refineAppliedAt ? ' refine-applied-fields' : ''}`}
                        >
                          {/* ★ span=2 配平：column=2 下「知识分析」与后项 span=2 不同行，span=1 会被 antd
                              刷成 1≠2 孤行告警（Sum of column `span` not match `column`）；本就独占一行，补满同构 */}
                          <Descriptions.Item label="知识分析" span={2}>
                            <div className="field-val-box">
                              <span className="field-val-main">{coreKnowledge.length} 个核心知识点 · {keyFormulaList.length} 条公式</span>
                              <span className="qh-field-key">knowledgeAnalysis</span>
                            </div>
                          </Descriptions.Item>
                          <Descriptions.Item label="知识关联点" span={2}>
                            <div className="field-val-box wrap-box">
                              <div className="field-val-main">
                                <Space wrap size="small">
                                  {relatedKnowledge.length === 0 && <Tag color="default">未优化</Tag>}
                                  {relatedKnowledge.map((item: any, idx: number) => (
                                    <Tag
                                      key={typeof item === 'string' ? idx : (item['编号'] || item['知识点'])}
                                      color="blue"
                                      className="knowledge-point-tag"
                                    >
                                      {typeof item === 'string' ? item : (item['知识点'] || '未命名知识点')}
                                    </Tag>
                                  ))}
                                </Space>
                              </div>
                              <span className="qh-field-key">relatedKnowledge</span>
                            </div>
                          </Descriptions.Item>
                          {knowledgeAnalysis?.teachingFocus && (
                            <Descriptions.Item label="教学重点" span={2}>
                              <div className="field-val-box">
                                <span className="field-val-main font-medium">{knowledgeAnalysis.teachingFocus}</span>
                                <span className="qh-field-key">teachingFocus</span>
                              </div>
                            </Descriptions.Item>
                          )}
                          {keyFormulaList.length > 0 && (
                            <Descriptions.Item label="关键公式" span={2}>
                              <div className="field-val-box wrap-box">
                                <div className="field-val-main">
                                  <Space wrap size="small">
                                    {keyFormulaList.map((formula: any) => (
                                      <Tag
                                        key={formula}
                                        color="cyan"
                                        className="formula-tag"
                                      >
                                        {formula}
                                      </Tag>
                                    ))}
                                  </Space>
                                </div>
                                <span className="qh-field-key">keyFormulaList</span>
                              </div>
                            </Descriptions.Item>
                          )}
                          {uncertainItems.length > 0 && (
                            <Descriptions.Item label="待确认项" span={2}>
                              <div className="field-val-box wrap-box">
                                <div className="field-val-main">
                                  <Space wrap size="small">
                                    {uncertainItems.map((item: any) => (
                                      <Tag
                                        key={displayValue(item)}
                                        color="orange"
                                      >
                                        {displayValue(item)}
                                      </Tag>
                                    ))}
                                  </Space>
                                </div>
                                <span className="qh-field-key">uncertainItems</span>
                              </div>
                            </Descriptions.Item>
                          )}
                          {handoff?.knowledgeAnalysis?.commonMistakes?.length > 0 && (
                            <Descriptions.Item label="易错点" span={2}>
                              <div className="field-val-box wrap-box">
                                <div className="field-val-main">
                                  <Space wrap size="small">
                                    {handoff.knowledgeAnalysis.commonMistakes.map((mistake: any, mi: number) => (
                                      <Tag
                                        key={mi}
                                        color="red"
                                      >
                                        {typeof mistake === 'string' ? mistake : (mistake.point || mistake.title || JSON.stringify(mistake))}
                                      </Tag>
                                    ))}
                                  </Space>
                                </div>
                                <span className="qh-field-key">commonMistakes</span>
                              </div>
                            </Descriptions.Item>
                          )}
                        </Descriptions>
                        {coreKnowledge.length > 0 && (
                          <div
                            className="knowledge-chips"
                          >
                            {coreKnowledge.map((item: any) => (
                              <Tag
                                key={item.knowledgeId || item.knowledgePoint}
                                color="blue"
                                className="knowledge-chip"
                                onClick={() => setSelectedKnowledge(item)}
                              >
                                {item.knowledgePoint || '未命名知识点'}
                              </Tag>
                            ))}
                          </div>
                        )}
                      </>
                    ),
                  },
                ]}
              />
            </Card>
            </div>
          </Card>

          {errorText && (
            <Alert
              type="error"
              showIcon
              title={errorText}
            />
          )}

          {/* ponytail: 删已确认题目卡片（进入B页后不需重复展示，仅UI删除不动逻辑参数） */}
          <Card
            className="qh-surface-card studio-workbench-card"
            variant="borderless"
            title={
              <div className="workbench-title-left">
                <span className="workbench-main-title">五字段执行表</span>
                {rows.length > 0 && (
                  <span className="workbench-context">
                    {rows.length} 行 · {totalEstimatedStats.charCount} 字 · 预估 {totalEstimatedStats.text}
                  </span>
                )}
              </div>
            }
            extra={
              <div className="studio-actions-container">
                <Tooltip title="先选音色再生成；一条视频只用一种音色，中途换音色需重新生成">
                  <Select
                    aria-label="音色"
                    value={voiceReferenceId}
                    style={{ width: 132 }}
                    options={VOICE_REFERENCE_OPTIONS}
                    onChange={(val: string) => {
                      setVoiceReferenceId(val)
                      try { localStorage.setItem(VOICE_REFERENCE_STORAGE_KEY, val) } catch { /* 隐私模式忽略 */ }
                      if (rowsRef.current.some((r: any) => r && r.audioUrl)) {
                        message.warning('音色已切换，已生成音频仍是旧音色，请重新生成后再交付')
                      }
                    }}
                  />
                </Tooltip>
                {/* 音色使用约定：把规则显式写给用户看（不是藏起来的提示），双向尊重——用户按约定操作，工具才保证不串音 */}
                <Popover
                  trigger="click"
                  placement="bottomRight"
                  content={
                    <div style={{ maxWidth: 240, lineHeight: 1.8, fontSize: 13 }}>
                      <div style={{ fontWeight: 600, marginBottom: 4 }}>音色使用约定</div>
                      <div>1. 先选音色，再生成</div>
                      <div>2. 一条视频只用一种音色</div>
                      <div>3. 中途换音色需重新生成</div>
                      <div>4. 交付前确认音色一致</div>
                    </div>
                  }
                >
                  <Button type="text" size="small" style={{ padding: '0 6px', fontSize: 12 }}>约定</Button>
                </Popover>
                <Select
                  aria-label="讲课风格"
                  value={selectedSkillId}
                  className="skill-style-select"
                  options={skillOptions}
                  onChange={(val: any) => { setSelectedSkillId(val); onSkillChange(val) }}
                />
                <Button
                  className="btn-settings"
                  title="Agent B API 配置"
                  aria-label="Agent B API 配置"
                  onClick={() => setApiConfigOpen(true)}
                  icon={<KeyOutlined />}
                />
                <Button
                  disabled={!rows.length || state === 'generating'}
                  loading={checkState === 'checking'}
                  onClick={() => checkRows('standard')}
                  icon={<CheckCircleOutlined />}
                >
                  Check Agent 内容检查
                </Button>
                {rows.length > 0 && (
                  <>
                    <Button
                      title="直接下载口播文稿 Markdown 文件"
                      onClick={exportSpeech}
                      icon={<DownloadOutlined />}
                    >
                      口播文稿 MD
                    </Button>
                    <Button
                      disabled={state === 'generating'}
                      loading={batchAudioState.running}
                      onClick={handleBatchGenerateAudio}
                      icon={<SoundOutlined />}
                    >
                      {batchAudioState.running ? `语音 ${batchAudioState.done}/${batchAudioState.total}` : '一键语音'}
                    </Button>
                    <Button
                      type="primary"
                      onClick={openHanddrawPlayer}
                      icon={<VideoCameraOutlined />}
                    >
                      演播录制
                    </Button>
                    <Dropdown
                      trigger={['click']}
                      menu={{ items: [
                        { key: 'regenerate', label: '重新生成五字段', icon: <ThunderboltOutlined />, disabled: state === 'generating', onClick: ({ domEvent }) => generateRows(domEvent.shiftKey) },
                        { key: 'asr', label: '数学口播优化', icon: <SafetyCertificateOutlined />, disabled: state === 'generating', onClick: runInstantMathAsrPolish },
                      ] }}
                    >
                      <Button loading={state === 'generating'}>更多操作</Button>
                    </Dropdown>
                    <Dropdown
                      trigger={['click']}
                      menu={{ items: [
                        { key: 'archive', label: deliverableResult ? '更新交付单页' : '生成交付单页', icon: <FileDoneOutlined />, disabled: state === 'generating' || deliverableGenerating, onClick: generateDeliverablePage },
                        { type: 'divider' },
                        { key: 'storyboard', label: '导出画布分镜表 MD', icon: <DownloadOutlined />, onClick: exportStoryboard },
                        { key: 'json', label: '导出完整规格 JSON', icon: <DownloadOutlined />, onClick: downloadDeliverableJson },
                      ] }}
                    >
                      <Button loading={deliverableGenerating}>交付与导出</Button>
                    </Dropdown>
                  </>
                )}

              </div>
            }
          >
            {rows.length === 0 ? (
              <div
                className="workbench-empty-state"
              >
                <div className="empty-icon-box">📐</div>
                <div className="empty-text-title">题目信息与四区排版已就绪</div>
                <div className="empty-text-sub">选择讲课风格，生成后可逐行编辑口播与板书。</div>
                <Button
                  type="primary"
                  size="large"
                  className="btn-empty-generate"
                  loading={state === 'generating'}
                  onClick={(e: any) => generateRows(e.shiftKey)}
                  icon={<ThunderboltOutlined />}
                >
                  开始生成五字段执行表
                </Button>
              </div>
            ) : (
              <div className="studio-table-container">
                {/* 视觉时间轴组件：映射每个 Row 组为独立区块，展示 MP3 时长与板书起手时机（由音频和系统语义自动驱动） */}
                <details className="studio-timeline-details">
                  <summary>查看时间轴</summary>
                <VisualTimeline
                  rows={rows}
                  activeIndex={editingBoardIndex}
                  playingIndex={playingAudioIndex === null ? -1 : playingAudioIndex}
                  onSelectRow={onSelectRowFromTimeline}
                  onPlayAudio={onPlayAudioFromTimeline}
                />
                </details>

                {/* 列空间合理分配与自由折叠工具条 */}
                <div className="studio-col-layout-bar">
                  <div className="col-layout-left">
                    <span className="col-layout-label">表格视图</span>
                    <div className="preset-btn-group">
                      <button
                        type="button"
                        className={`preset-btn${layoutPreset === 'standard' ? ' active' : ''}`}
                        title="标准全景：口播与板书舒适并列，空间均衡分配"
                        onClick={() => setLayoutPresetFn('standard')}
                      >
                        展开全部列
                      </button>
                    </div>
                  </div>

                  <div className="col-layout-right">
                    <span className="col-layout-sublabel">显示列</span>
                    <button
                      type="button"
                      className={`col-toggle-chip${collapsedCols.speech ? ' collapsed' : ''}`}
                      title={collapsedCols.speech ? '点击展开口播列' : '点击折叠收起口播列'}
                      aria-pressed={!collapsedCols.speech}
                      onClick={() => toggleColumn('speech')}
                    >
                      <span className={`chip-dot${collapsedCols.speech ? ' off' : ''}`}></span>
                      口播 {collapsedCols.speech ? '（收起）' : ''}
                    </button>
                    <button
                      type="button"
                      className={`col-toggle-chip${collapsedCols.board ? ' collapsed' : ''}`}
                      title={collapsedCols.board ? '点击展开板书列' : '点击折叠收起板书列'}
                      aria-pressed={!collapsedCols.board}
                      onClick={() => toggleColumn('board')}
                    >
                      <span className={`chip-dot${collapsedCols.board ? ' off' : ''}`}></span>
                      板书 {collapsedCols.board ? '（收起）' : ''}
                    </button>
                    <button
                      type="button"
                      className={`col-toggle-chip${collapsedCols.actionSpec ? ' collapsed' : ''}`}
                      title={collapsedCols.actionSpec ? '点击展开动作列' : '点击折叠收起动作列'}
                      aria-pressed={!collapsedCols.actionSpec}
                      onClick={() => toggleColumn('actionSpec')}
                    >
                      <span className={`chip-dot${collapsedCols.actionSpec ? ' off' : ''}`}></span>
                      动作 {collapsedCols.actionSpec ? '（收起）' : ''}
                    </button>
                  </div>
                </div>

                <Table
                  columns={columns}
                  dataSource={tableRows}
                  rowKey="_rowKey"
                  pagination={false}
                  className="studio-table"
                  tableLayout="auto"
                  scroll={{ x: columns.reduce((total, column) => total + (column.minWidth ?? column.width ?? 0), 0) }}
                  bordered={false}
                  onRow={customRow}
                />
              </div>
            )}
          </Card>

          {toolsOpen && (
            <ToolsCard />
          )}
        </Space>
      </Layout.Content>

      <KnowledgeDetailModal
        selectedKnowledge={selectedKnowledge}
        onClose={() => setSelectedKnowledge(null)}
      />

      <CheckResultModal
        open={checkResultOpen}
        checkSource={checkSource}
        checkFailedFallback={checkFailedFallback}
        checkChanges={checkChanges}
        onDiscard={discardCheckChanges}
        onApply={applyCheckChanges}
      />

      <RefineCompareModal
        open={refineResultOpen}
        refineResult={refineResult}
        handoff={handoff}
        refineApplying={refineApplying}
        onApply={applyRefine}
        onKeep={keepOriginalRefine}
        onClose={() => setRefineResultOpen(false)}
      />

      {/* Agent B API 配置与多密钥轮询弹窗 */}
      <ApiConfigModal
        open={apiConfigOpen}
        onSave={onSaveApiConfig}
        onClose={() => setApiConfigOpen(false)}
      />

      {/* 产物单页生成成功弹窗 */}
      <DeliverableModal
        open={deliverableModalOpen}
        deliverableResult={deliverableResult}
        rowsCount={rows.length}
        onOpenDeliverablePage={openDeliverablePage}
        onDownloadDeliverableJson={downloadDeliverableJson}
        onDownloadReleasePackage={downloadReleasePackage}
        onClose={() => setDeliverableModalOpen(false)}
      />

      {/* 极具科技美感与情感化的高端生成中动画弹窗（全流程多阶段呼吸轮播） */}
      <ProcessLoadingModal
        visible={state === 'generating'}
        title="AI 教学引擎正在分析与编排微课..."
        mode="agent-b"
      />

      {/* 第二双眼睛独立质检 Loading 弹窗 */}
      <ProcessLoadingModal
        visible={checkState === 'checking'}
        title="第二双眼睛 AI 深度质检中..."
        mode="check"
      />
    </Layout>
  )
}
