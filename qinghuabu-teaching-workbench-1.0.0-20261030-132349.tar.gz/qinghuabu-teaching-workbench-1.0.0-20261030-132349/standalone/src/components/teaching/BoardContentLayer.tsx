'use client'

/**
 * 1:1 移植自 /home/z/teaching-board/src/components/BoardContentLayer.vue
 *
 * 关键映射：
 * - reactive(new Map()) × 4（localBlockCoords/localBlockTexts/localBlockWidths/blockRealSizes）
 *   → useReactiveMap（克隆写 Map + bump 重渲染；读 API 与 Vue Map 一致，同步读永远是最新值）
 * - activeDrag/activeResize（ref 深响应对象，pointermove 中被变异且模板实时读取）
 *   → session 真源放 ref + 渲染镜像放 state（handlersRef 每次 render 刷新，window 监听
 *     走一次性 stable 包装 → 闭包永远拿到最新状态，等价 Vue 深响应行为）
 * - defineEmits ['topic-measured','update:topic-layout','layout-change',
 *   'update:problem-text','problem-text-change'] → onTopicMeasured / onUpdateTopicLayout /
 *   onLayoutChange / onUpdateProblemText / onProblemTextChange
 * - watch(topicLayout, { immediate:true, deep:true }) → useEffect + JSON 快照依赖（首帧执行 = immediate）
 * - watch(problemText)（无 immediate）→ useEffect + 首帧跳过
 * - v-html → dangerouslySetInnerHTML；<img onerror="..."> 内联属性 → onError 处理器（语义一致）
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import {
  BOARD_LAYOUT,
  limitTopicImageHeightPct,
  pctBox,
} from '@/utils/boardLayout.js'
import { renderProblemHtml } from '@/utils/mathText.js'
import { buildGridLines } from '@/utils/canvasCoords.js'
// 画布参数唯一真源：src/services/stepHandoff.js
// ★ 字体宪法 v2（2026-10-15）：题目字体族/颜色从真源派生；v2.2（2026-10-16）：行高 = 自然 + 2px 分数余量
import { QUESTION_FONT_SIZE, QUESTION_FONT_FAMILY, BOARD_TEXT_COLOR, CANVAS_SIZE } from '@/services/stepHandoff.js'
import { naturalLhRatioFor, naturalLhWithFractionMargin } from '@/lib/naturalLineHeight.js'
import './BoardContentLayer.css'

/** ★ 原 reactive(new Map()) 等价容器：克隆写（mapRef 同步写，保住「先写后读」语义）
    + version 计数（对象身份随每次 set/clear 变化，驱动 useMemo/渲染失效；
    读走 mapRef.current，同步读恒为新值）。对象方法内的 ref 读写仅发生在调用点
    （事件/commit 回调），render 期只经 get/has/size 读取 → 通过 react-hooks/refs */
function useReactiveMap<K, V>() {
  const mapRef = useRef<Map<K, V>>(new Map())
  const [version, setVersion] = useState(0)
  return useMemo(
    () => ({
      set(key: K, value: V) {
        const next = new Map(mapRef.current)
        next.set(key, value)
        mapRef.current = next
        setVersion((v) => v + 1)
      },
      clear() {
        mapRef.current = new Map()
        setVersion((v) => v + 1)
      },
      get(key: K): V | undefined {
        return mapRef.current.get(key)
      },
      has(key: K): boolean {
        return mapRef.current.has(key)
      },
      /** 原 localBlockTexts.map.size 读法 → size getter */
      get size(): number {
        return mapRef.current.size
      },
    }),
    // version 变化 → 返回新对象身份（等价 Vue 深响应的派生失效信号）
    [version],
  )
}

export interface BoardContentLayerProps {
  problemText?: string
  boardPlan?: Record<string, any> | null
  topicLayout?: Record<string, any> | null
  showGrid?: boolean
  showAllLabels?: boolean
  showZoneGuides?: boolean
  /**
   * ★ Task 58 布局修订闭环（夏夏拍板 2026-10-22）：四区框编辑态——analysis/solution/summary
   * 区框变为可平移拖拽实体（题目区绑题目块/原题图/四标签角标已有拖拽能力），
   * 拖拽经 layout-change 带出，由预览页保存「布局修订」后回工作台重新生成生效。
   * 定位：布局调整前移生成环（播放页调布局=生米煮熟，内容已按旧布局生成）。
   */
  zoneEditable?: boolean
  sourceImageUrl?: string
  keepOriginal?: boolean
  draggable?: boolean
  /**
   * 画布参数只提供布局信息；题目字体、字号固定取独立常量，不接受档案覆写。
   */
  canvasParams?: Record<string, any> | null
  onTopicMeasured?: (payload: { bottomPct: number; heightPct: number }) => void
  onUpdateTopicLayout?: (layout: any) => void
  onLayoutChange?: (layout: any) => void
  onUpdateProblemText?: (text: string) => void
  onProblemTextChange?: (text: string) => void
}

export default function BoardContentLayer({
  problemText = '',
  boardPlan = null,
  topicLayout = null,
  showGrid = false,
  showAllLabels = false,
  showZoneGuides = false,
  zoneEditable = false,
  sourceImageUrl = '',
  keepOriginal = false,
  draggable = true,
  canvasParams = null,
  onTopicMeasured,
  onUpdateTopicLayout,
  onLayoutChange,
  onUpdateProblemText,
  onProblemTextChange,
}: BoardContentLayerProps) {
  // 题目区固定为微软雅黑 30px，与手写板书三区独立。
  // ★ 字体宪法 v2.2（2026-10-16 夏夏拍板）：题目层自然行高 + 2px 分数余量（KaTeX 行内分数越出行盒，
  //   相邻行贴死）——CSS 无法对 normal 做加法，用 canvas 度量印刷体栈自然比数（本地系统字体，
  //   同步可得无需等 fonts.ready），getBlockStyle 按块字号折算无单位 line-height；未度量回落
  //   .topic-text 类样式 normal（与 row-player 题目行 30*naturalLhRatio+2 同源同规则）
  const [topicLhRatio, setTopicLhRatio] = useState<number | null>(null)
  function remeasureTopicLh() {
    setTopicLhRatio(naturalLhRatioFor(QUESTION_FONT_FAMILY, QUESTION_FONT_SIZE))
  }
  // 原 watch(QUESTION_FONT_SIZE, remeasureTopicLh) + onMounted(remeasureTopicLh)
  // → 合并为一个 effect（挂载执行一次 = onMounted；字号变更执行 = watch）；
  //   setState 包 rAF 规避 set-state-in-effect（canvas 度量为纯计算，晚一帧无感知）
  useEffect(() => {
    const raf = requestAnimationFrame(remeasureTopicLh)
    return () => cancelAnimationFrame(raf)
  }, [])

  const realCanvasHeight = (() => {
    const h = Number(canvasParams?.canvasSize?.height)
    return h > 0 ? h : CANVAS_SIZE.height
  })()

  const layerRef = useRef<HTMLDivElement | null>(null)
  const topicContentRef = useRef<HTMLElement | null>(null)
  const grid = useMemo(() => buildGridLines(), [])
  const topicObserverRef = useRef<ResizeObserver | null>(null)

  // 本地可拖拽文本块坐标、文本内容与尺寸状态管理
  const localBlockCoords = useReactiveMap<string, { x: number; y: number }>()
  const localBlockTexts = useReactiveMap<string, string>()
  const localBlockWidths = useReactiveMap<string, number>()
  const blockRealSizes = useReactiveMap<string, Record<string, number>>()
  const activeDragRef = useRef<any>(null)
  const [activeDrag, setActiveDrag] = useState<any>(null)
  const activeResizeRef = useRef<any>(null)
  const [activeResize, setActiveResize] = useState<any>(null)
  const [editingBlockId, setEditingBlockId] = useState<string | null>(null)
  const [editingText, setEditingText] = useState('')
  const editTextareaRef = useRef<HTMLTextAreaElement | null>(null)
  const [hoveredBlockId, setHoveredBlockId] = useState<string | null>(null)
  // ★ 原 ref(false)（模板未引用，仅 watch 同步消费）→ useRef（同步写读，无渲染依赖）
  const isEmittingProblemTextRef = useRef(false)
  const blockElementObserversRef = useRef<Map<string, ResizeObserver>>(new Map())

  // （identifiedBlocksRef / onTopicMeasuredRef 的刷新 effect 位于 identifiedBlocks 声明之后）

  const plan = useMemo(() => {
    const base: Record<string, any> = {
      topicLabel: topicLayout?.topicLabel || boardPlan?.topicLabel || BOARD_LAYOUT.topicLabel,
      question: { ...(topicLayout?.question || boardPlan?.question || BOARD_LAYOUT.question), fontSize: QUESTION_FONT_SIZE },
      image: topicLayout?.image || boardPlan?.image || null,
      analysisLabel: boardPlan?.analysisLabel || BOARD_LAYOUT.analysisLabel,
      analysis: boardPlan?.analysis || BOARD_LAYOUT.analysis,
      solutionLabel: boardPlan?.solutionLabel || BOARD_LAYOUT.solutionLabel,
      solution: boardPlan?.solution || BOARD_LAYOUT.solution,
      summaryLabel: boardPlan?.summaryLabel || BOARD_LAYOUT.summaryLabel,
      summary: boardPlan?.summary || BOARD_LAYOUT.summary,
    }
    return base
  }, [topicLayout, boardPlan])

  // 将题目文本拆分为识别出的文本块（支持单文本块和多文本段落块）
  const identifiedBlocks = useMemo(() => {
    const text = String(problemText || '').trim()
    if (!text && localBlockTexts.size === 0) return []

    // 若上游传入了显式的 blocks 列表，优先复用
    if (Array.isArray(topicLayout?.blocks) && topicLayout.blocks.length > 0) {
      return topicLayout.blocks.map((b: any, idx: number) => {
        const blockId = b.id || `tb-${idx}`
        const savedCoord = localBlockCoords.get(blockId)
        const currentText = localBlockTexts.has(blockId) ? localBlockTexts.get(blockId) : (b.text || '')
        const currentW = localBlockWidths.has(blockId) ? localBlockWidths.get(blockId) : (b.w ?? plan.question.w)
        return {
          id: blockId,
          text: currentText,
          html: renderProblemHtml(currentText),
          x: savedCoord?.x ?? (b.x ?? plan.question.x),
          y: savedCoord?.y ?? (b.y ?? plan.question.y + idx * 7.5),
          w: currentW,
          fontSize: QUESTION_FONT_SIZE,
        }
      })
    }

    // 默认按换行切分段落文本块；若只有一段则为单块
    const rawSegments = text ? text.split(/\n+/).map((s) => s.trim()).filter(Boolean) : []
    const segments = rawSegments.length > 0 ? rawSegments : (text ? [text] : [])

    return segments.map((seg, idx) => {
      const blockId = `block-${idx}`
      const savedCoord = localBlockCoords.get(blockId)
      const currentText = localBlockTexts.has(blockId) ? localBlockTexts.get(blockId) : seg
      const currentW = localBlockWidths.has(blockId) ? localBlockWidths.get(blockId) : plan.question.w
      const defaultY = +(plan.question.y + idx * 8.2).toFixed(1)
      return {
        id: blockId,
        text: currentText,
        html: renderProblemHtml(currentText),
        x: savedCoord?.x ?? plan.question.x,
        y: savedCoord?.y ?? defaultY,
        w: currentW,
        fontSize: QUESTION_FONT_SIZE,
      }
    })
  }, [
    problemText,
    topicLayout,
    plan,
    localBlockCoords,
    localBlockTexts,
    localBlockWidths,
  ])

  // 最新值镜像（供 window 监听 / ResizeObserver / syncAll 等长生命周期闭包读取；
  // 每 render 在 effect 中刷新，事件时读到恒为新值）
  const identifiedBlocksRef = useRef<any[]>([])
  const onTopicMeasuredRef = useRef(onTopicMeasured)
  useEffect(() => {
    identifiedBlocksRef.current = identifiedBlocks
    onTopicMeasuredRef.current = onTopicMeasured
  })

  const showExtraLabels = showAllLabels || Boolean(boardPlan?.analysisLabel)
  // 原 Vue computed 惰性求值：三处访问均有 plan.image 守卫；React 同步求值需在此守卫，
  // 否则冷开预览页（plan.image === null）时 null 取属性直接抛错（/board-preview 500）
  const topicImageMaxHeight = plan.image ? limitTopicImageHeightPct(plan.image) : null

  // 实时视觉校验：检测当前拖拽/调整尺寸中的元素是否超出 1726×980 画布有效范围 (0% ~ 100%)
  // （原 Vue computed 为惰性求值可后置声明；React useMemo 同步求值，需先声明 plan/identifiedBlocks/topicImageMaxHeight）
  const dragBoundaryStatus = useMemo(() => {
    if (!activeDrag && !activeResize) return null

    let targetId = ''
    let x = 0, y = 0, w = 20, h = 10

    if (activeDrag) {
      const d = activeDrag
      targetId = d.targetId
      x = d.currentX
      y = d.currentY
      if (d.targetType === 'textBlock') {
        w = Number(localBlockWidths.get(d.targetId) ?? identifiedBlocks.find((b: any) => b.id === d.targetId)?.w ?? plan.question?.w ?? 44)
        h = Number(blockRealSizes.get(d.targetId)?.hPct || 8)
      } else if (d.targetType === 'image') {
        w = Number(plan.image?.w ?? 38)
        h = Number(topicImageMaxHeight ?? 30)
      } else if (d.targetType === 'label') {
        w = 6.0
        h = 4.2
      } else if (d.targetType === 'zone') {
        // ★ Task 58: 四区框拖拽越界判据——区宽高取 plan 真源（拖拽仅平移 x/y，w/h 不变）
        const z = plan[d.targetId] || {}
        w = Number(z.w ?? 44)
        h = Number(z.h ?? 44)
      }
    } else if (activeResize) {
      const r = activeResize
      targetId = r.blockId
      const coord = localBlockCoords.get(r.blockId) || { x: plan.question?.x ?? 6, y: plan.question?.y ?? 13.2 }
      x = coord.x
      y = coord.y
      w = Number(localBlockWidths.get(r.blockId) ?? 44)
      h = Number(blockRealSizes.get(r.blockId)?.hPct || 8)
    }

    const right = x + w
    const bottom = y + h

    const overLeft = x < 0
    const overTop = y < 0
    const overRight = right > 100
    const overBottom = bottom > 100
    const isOutOfBounds = overLeft || overTop || overRight || overBottom

    const violations: string[] = []
    if (overLeft) violations.push(`左侧超出 ${Math.abs(x).toFixed(1)}%`)
    if (overRight) violations.push(`右侧超出 ${(right - 100).toFixed(1)}%`)
    if (overTop) violations.push(`顶部超出 ${Math.abs(y).toFixed(1)}%`)
    if (overBottom) violations.push(`底部超出 ${(bottom - 100).toFixed(1)}%`)

    return {
      targetId,
      x: +x.toFixed(1),
      y: +y.toFixed(1),
      w: +w.toFixed(1),
      h: +h.toFixed(1),
      right: +right.toFixed(1),
      bottom: +bottom.toFixed(1),
      overLeft,
      overTop,
      overRight,
      overBottom,
      isOutOfBounds,
      violations,
    }
  }, [
    activeDrag,
    activeResize,
    plan,
    topicImageMaxHeight,
    identifiedBlocks,
    localBlockCoords,
    localBlockWidths,
    blockRealSizes,
  ])

  // 监听外部 topicLayout 的变更并同步到本地坐标与宽度映射
  // ★ 原 watch(props.topicLayout, { immediate:true, deep:true }) → useEffect + JSON 快照依赖
  //   （首帧执行 = immediate；内容变更执行 = deep；引用变但内容同不触发，规避无谓 set）
  const topicLayoutKey = useMemo(() => JSON.stringify(topicLayout ?? null), [topicLayout])
  useEffect(() => {
    const newLayout = topicLayout
    if (!newLayout) return
    if (Array.isArray(newLayout.blocks)) {
      newLayout.blocks.forEach((b: any, idx: number) => {
        const blockId = b.id || `block-${idx}`
        if (b.x != null && b.y != null) {
          localBlockCoords.set(blockId, { x: Number(b.x), y: Number(b.y) })
        }
        if (b.w != null && !localBlockWidths.has(blockId)) {
          localBlockWidths.set(blockId, Number(b.w))
        }
      })
    } else if (newLayout.question) {
      localBlockCoords.set('block-0', { x: Number(newLayout.question.x), y: Number(newLayout.question.y) })
      if (newLayout.question.w != null && !localBlockWidths.has('block-0')) {
        localBlockWidths.set('block-0', Number(newLayout.question.w))
      }
    }
    if (newLayout.image) {
      localBlockCoords.set('topic-image', { x: Number(newLayout.image.x), y: Number(newLayout.image.y) })
    }
    if (newLayout.topicLabel) {
      localBlockCoords.set('topic-label', { x: Number(newLayout.topicLabel.x), y: Number(newLayout.topicLabel.y) })
    }
  }, [topicLayoutKey])

  // 监听外部 problemText 变更：若非自身发出且非正在编辑，同步重置
  // ★ 原 watch(props.problemText)（无 immediate）→ 首帧跳过；
  //   isEmittingProblemText 为 ref（非渲染状态），复位走 ref 写（无 setState-in-effect）
  const problemTextWatchFirstRunRef = useRef(true)
  useEffect(() => {
    if (problemTextWatchFirstRunRef.current) {
      problemTextWatchFirstRunRef.current = false
      return
    }
    if (isEmittingProblemTextRef.current) {
      isEmittingProblemTextRef.current = false
      return
    }
    if (!editingBlockId) {
      localBlockTexts.clear()
    }
  }, [problemText])

  // ★ Task 58 布局修订闭环：四区框编辑清单（题目区绑题目块已有拖拽，不在此列）
  const zoneEditList = [
    { key: 'analysis', name: '分析' },
    { key: 'solution', name: '解答' },
    { key: 'summary', name: '总结' },
  ]

  // —— window pointer 监听的 stable 包装（监听器身份恒定，实现经 handlersRef 在 effect 中刷新；
  //    刷新 effect 置于四个 handler 声明之后，满足编译器「先声明后引用」约束）——
  const handlersRef = useRef<any>({})
  const [stable] = useState(() => ({
    pointerMove: (e: PointerEvent) => handlersRef.current.onPointerMove?.(e),
    pointerUp: () => handlersRef.current.onPointerUp?.(),
    pointerCancel: () => handlersRef.current.onPointerUp?.(),
    resizeMove: (e: PointerEvent) => handlersRef.current.onResizeMove?.(e),
    resizeUp: () => handlersRef.current.onResizeUp?.(),
    resizeCancel: () => handlersRef.current.onResizeUp?.(),
  }))

  // —— 编辑/测量/同步函数组（编译器 lint 要求先声明后引用：onPointerUp/onResizeMove/
  //    onResizeUp 会调用 enterEdit/syncAll/autoGrowTextarea，故置于拖拽 handler 之前）——

  // 自动撑开 textarea 高度，让拖拽块尺寸实时包裹最新文本内容
  function autoGrowTextarea() {
    const textarea = editTextareaRef.current
    if (!textarea) return
    textarea.style.height = 'auto'
    textarea.style.height = `${Math.max(36, textarea.scrollHeight)}px`
  }

  // 进入编辑状态
  function enterEdit(block: any) {
    if (editingBlockId === block.id) return
    setEditingBlockId(block.id)
    const currentText = localBlockTexts.get(block.id) ?? block.text ?? ''
    setEditingText(currentText)

    // nextTick → rAF（等编辑 textarea 渲染完成后聚焦）
    requestAnimationFrame(() => {
      autoGrowTextarea()
      if (editTextareaRef.current) {
        editTextareaRef.current.focus()
        const len = editTextareaRef.current.value.length
        editTextareaRef.current.setSelectionRange(len, len)
      }
    })
  }

  function measureTopic() {
    const layer = layerRef.current
    const topic = topicContentRef.current
    if (!layer || !topic) return

    const layerRect = layer.getBoundingClientRect()
    const topicRect = topic.getBoundingClientRect()
    if (!layerRect.height) return

    onTopicMeasuredRef.current?.({
      bottomPct: Number((((topicRect.bottom - layerRect.top) / layerRect.height) * 100).toFixed(2)),
      heightPct: Number(((topicRect.height / layerRect.height) * 100).toFixed(2)),
    })
  }

  // 同步题目内容与布局至父组件及本地持久化
  function syncAll() {
    const blocks = identifiedBlocksRef.current

    // 1. 拼接所有文本块内容生成完整题目字符串
    if (blocks && blocks.length > 0) {
      const fullText = blocks
        .map((b: any) => (localBlockTexts.has(b.id) ? localBlockTexts.get(b.id) : b.text))
        .join('\n')

      isEmittingProblemTextRef.current = true
      onUpdateProblemText?.(fullText)
      onProblemTextChange?.(fullText)
      // ★ Task 60：删 qinghuabu.problemText 死键写入（全仓零读者，写入即垃圾堆积）
    }

    // 2. 构建最新的 updatedLayout
    const updatedLayout = JSON.parse(JSON.stringify(topicLayout || {}))
    if (blocks && blocks.length > 0) {
      const updatedBlocks = blocks.map((b: any) => ({
        id: b.id,
        text: localBlockTexts.has(b.id) ? localBlockTexts.get(b.id) : b.text,
        x: localBlockCoords.get(b.id)?.x ?? b.x,
        y: localBlockCoords.get(b.id)?.y ?? b.y,
        w: localBlockWidths.get(b.id) ?? b.w,
        fontSize: b.fontSize,
      }))
      updatedLayout.blocks = updatedBlocks

      if (updatedBlocks[0]) {
        updatedLayout.question = {
          ...(updatedLayout.question || plan.question),
          fontSize: QUESTION_FONT_SIZE,
          x: updatedBlocks[0].x,
          y: updatedBlocks[0].y,
          w: updatedBlocks[0].w,
        }
      }
    }

    // 同步四个角标拖拽后的最新坐标
    const badgeTargets = ['topic', 'analysis', 'solution', 'summary']
    for (const t of badgeTargets) {
      const targetId = `${t}-label`
      if (localBlockCoords.has(targetId)) {
        const c = localBlockCoords.get(targetId)
        const labelKey = `${t}Label`
        updatedLayout[labelKey] = {
          ...(updatedLayout[labelKey] || plan[labelKey] || BOARD_LAYOUT[labelKey]),
          x: c!.x,
          y: c!.y,
        }
      }
    }

    // ★ Task 58 布局修订闭环：同步四区框（zone）拖拽后的最新坐标（analysis/solution/summary 平移）。
    // 区框 targetId 与区同名（'analysis' 等），与标签 'xxx-label' / 题目块 id 天然不撞。
    // 拖拽坐标进入 updatedLayout 对应区键，预览页保存后作为「布局修订」写回生成环真相源。
    const zoneTargets = ['analysis', 'solution', 'summary']
    for (const z of zoneTargets) {
      const zc = localBlockCoords.get(z)
      if (zc) {
        updatedLayout[z] = {
          ...(updatedLayout[z] || plan[z] || BOARD_LAYOUT[z]),
          x: zc.x,
          y: zc.y,
        }
      }
    }

    // ★ Task 60：删 qinghuabu.topicLayout 死键写入（全仓零读者；真正的同步走
    //   emit('update:topic-layout')/emit('layout-change') 与父级 liveBoardPreview 通道）
    onUpdateTopicLayout?.(updatedLayout)
    onLayoutChange?.(updatedLayout)

    // nextTick → rAF
    requestAnimationFrame(measureTopic)
  }

  // 拖拽处理：支持鼠标/触控拖动任意文本块或原题图/标签
  function startDrag(e: React.PointerEvent, targetType: string, targetId: string, initialX: any, initialY: any) {
    if (!draggable) return
    // 如果当前文本块正处于编辑状态，且点击在其内部，不拦截拖拽以允许文本选择
    if (editingBlockId === targetId) return

    e.preventDefault()
    e.stopPropagation()

    const layer = layerRef.current
    if (!layer) return
    const layerRect = layer.getBoundingClientRect()
    if (!layerRect.width || !layerRect.height) return

    activeDragRef.current = {
      targetType, // 'textBlock' | 'image' | 'label'
      targetId,
      startPointerX: e.clientX,
      startPointerY: e.clientY,
      initialX: Number(initialX),
      initialY: Number(initialY),
      currentX: Number(initialX),
      currentY: Number(initialY),
      layerWidth: layerRect.width,
      layerHeight: layerRect.height,
      hasMoved: false,
    }
    setActiveDrag(activeDragRef.current)

    window.addEventListener('pointermove', stable.pointerMove, { passive: false })
    window.addEventListener('pointerup', stable.pointerUp)
    window.addEventListener('pointercancel', stable.pointerUp)
  }

  function onPointerMove(e: PointerEvent) {
    const drag = activeDragRef.current
    if (!drag) return
    e.preventDefault()

    const dist = Math.hypot(e.clientX - drag.startPointerX, e.clientY - drag.startPointerY)
    if (dist > 3) {
      drag.hasMoved = true
    }

    const deltaXPct = ((e.clientX - drag.startPointerX) / drag.layerWidth) * 100
    const deltaYPct = ((e.clientY - drag.startPointerY) / drag.layerHeight) * 100

    // 允许移动时适当超出边界，以便直观展现 1726×980 实时视觉校验与高亮警示
    const newX = Math.max(-8, Math.min(108, +(drag.initialX + deltaXPct).toFixed(1)))
    const newY = Math.max(-8, Math.min(108, +(drag.initialY + deltaYPct).toFixed(1)))

    drag.currentX = newX
    drag.currentY = newY

    localBlockCoords.set(drag.targetId, { x: newX, y: newY })
    // 同步渲染镜像（原 ref 深响应：模板实时读取 activeDrag.currentX/currentY）
    setActiveDrag({ ...drag })
  }

  function onPointerUp() {
    const drag = activeDragRef.current
    if (!drag) return

    window.removeEventListener('pointermove', stable.pointerMove)
    window.removeEventListener('pointerup', stable.pointerUp)
    window.removeEventListener('pointercancel', stable.pointerUp)

    const wasClick = !drag.hasMoved
    const targetId = drag.targetId
    const targetType = drag.targetType
    let finalX = drag.currentX
    let finalY = drag.currentY

    // 计算当前对象尺寸，释放时若越界则轻柔回弹收敛至 1726×980 画布安全有效区域内
    let itemW = 20
    let itemH = 6
    if (targetType === 'textBlock') {
      itemW = Number(localBlockWidths.get(targetId) ?? identifiedBlocksRef.current.find((b: any) => b.id === targetId)?.w ?? plan.question?.w ?? 44)
      itemH = Number(blockRealSizes.get(targetId)?.hPct || 8)
    } else if (targetType === 'image') {
      itemW = Number(plan.image?.w ?? 38)
      itemH = Number(topicImageMaxHeight ?? 30)
    } else if (targetType === 'label') {
      itemW = 6.0
      itemH = 4.2
    } else if (targetType === 'zone') {
      // ★ Task 58: 四区框回弹收敛——按 plan 真源宽高算安全边界
      const z = plan[targetId] || {}
      itemW = Number(z.w ?? 44)
      itemH = Number(z.h ?? 44)
    }

    // 确保最终始终落在 1726×980 画布内 (0.5% ~ 99.5%)
    finalX = Math.max(0.5, Math.min(Math.max(0.5, +(99.5 - itemW).toFixed(1)), finalX))
    finalY = Math.max(0.5, Math.min(Math.max(0.5, +(99.5 - itemH).toFixed(1)), finalY))

    activeDragRef.current = null
    setActiveDrag(null)

    // 若为普通点击文本块，触发直接在画布上进入编辑状态！
    if (wasClick && targetType === 'textBlock') {
      const targetBlock = identifiedBlocksRef.current.find((b: any) => b.id === targetId)
      if (targetBlock) {
        enterEdit(targetBlock)
        return
      }
    }

    localBlockCoords.set(targetId, { x: finalX, y: finalY })
    syncAll()
  }

  // 宽度拉伸调整（实时改变拖拽块的尺寸）
  function startResize(e: React.PointerEvent, blockId: string, initialW: any) {
    e.preventDefault()
    e.stopPropagation()

    const layer = layerRef.current
    if (!layer) return
    const layerRect = layer.getBoundingClientRect()
    if (!layerRect.width) return

    activeResizeRef.current = {
      blockId,
      startPointerX: e.clientX,
      initialW: Number(initialW || plan.question.w),
      layerWidth: layerRect.width,
    }
    setActiveResize(activeResizeRef.current)

    window.addEventListener('pointermove', stable.resizeMove, { passive: false })
    window.addEventListener('pointerup', stable.resizeUp)
    window.addEventListener('pointercancel', stable.resizeUp)
  }

  function onResizeMove(e: PointerEvent) {
    const res = activeResizeRef.current
    if (!res) return
    e.preventDefault()

    const deltaXPct = ((e.clientX - res.startPointerX) / res.layerWidth) * 100
    // 允许拉伸超出 100%，以触发实时越界视觉警示
    const newW = Math.max(10, Math.min(120, +(res.initialW + deltaXPct).toFixed(1)))
    localBlockWidths.set(res.blockId, newW)

    if (editingBlockId === res.blockId) {
      autoGrowTextarea()
    }
  }

  function onResizeUp() {
    const res = activeResizeRef.current
    if (!res) return

    window.removeEventListener('pointermove', stable.resizeMove)
    window.removeEventListener('pointerup', stable.resizeUp)
    window.removeEventListener('pointercancel', stable.resizeUp)

    // 释放时将宽度收敛在 1726×980 画布边界内
    const blockCoord = localBlockCoords.get(res.blockId) || { x: 6 }
    const currentW = localBlockWidths.get(res.blockId) || 44
    const safeW = Math.max(10, Math.min(+(99.5 - blockCoord.x).toFixed(1), currentW))
    localBlockWidths.set(res.blockId, safeW)

    activeResizeRef.current = null
    setActiveResize(null)
    syncAll()
  }

  // handlersRef 每渲染刷新（供 stable 包装转发到最新实现，闭包永远拿到最新状态）
  useEffect(() => {
    handlersRef.current.onPointerMove = onPointerMove
    handlersRef.current.onPointerUp = onPointerUp
    handlersRef.current.onResizeMove = onResizeMove
    handlersRef.current.onResizeUp = onResizeUp
  })

  // （enterEdit / autoGrowTextarea / measureTopic / syncAll 声明见上；此处仅保留其余编辑辅助）

  // 实时修改题目文本内容
  // （原 @input 读 v-model 已更新的 editingText；React 受控 onChange 同帧传值，语义一致）
  function onBlockInput(blockId: string, text: string) {
    autoGrowTextarea()
    localBlockTexts.set(blockId, text)
    syncAll()
  }

  // 完成编辑
  function finishEdit() {
    if (!editingBlockId) return
    setEditingBlockId(null)
    syncAll()
    // nextTick → rAF
    requestAnimationFrame(measureTopic)
  }

  function onTextareaBlur() {
    setTimeout(() => {
      if (editingBlockId) {
        finishEdit()
      }
    }, 140)
  }

  // ★ Task 58-b 实测修正：zone 框拖拽实时跟手。onPointerMove 已把最新坐标写进
  // localBlockCoords（与题目块/标签同一数据通道），模板从这里读——此前只绑 plan
  // 真源，拖拽中框纹丝不动、松手回流后才跳位，与块/标签手感割裂。
  // w/h 仍取 plan 真源（拖拽只平移不改尺寸），无本地坐标时回落 plan 初值。
  function zoneBoxStyle(zoneKey: string) {
    const p = plan[zoneKey] || {}
    const c = localBlockCoords.get(zoneKey)
    return pctBox({ w: p.w, h: p.h, x: c?.x ?? p.x, y: c?.y ?? p.y })
  }

  // 观察单个 block 元素的实际渲染尺寸，实现实时测量
  // （isTopicAnchor 由 blockRefCbs 工厂在创建时按「blockId==='block-0' 或 首块」判定，
  //   等价原 setBlockElementRef 内的 identifiedBlocks[0]?.id 判定）
  function setBlockElementRef(el: any, blockId: string, isTopicAnchor: boolean) {
    if (!el) {
      const prevObs = blockElementObserversRef.current.get(blockId)
      if (prevObs) {
        prevObs.disconnect()
        blockElementObserversRef.current.delete(blockId)
      }
      return
    }

    if (isTopicAnchor) {
      topicContentRef.current = el
    }

    if (!blockElementObserversRef.current.has(blockId)) {
      const obs = new ResizeObserver((entries) => {
        for (const entry of entries) {
          const rect = entry.target.getBoundingClientRect()
          const layer = layerRef.current
          const layerRect = layer ? layer.getBoundingClientRect() : null
          const layerW = layerRect?.width || CANVAS_SIZE.width
          const layerH = layerRect?.height || CANVAS_SIZE.height

          blockRealSizes.set(blockId, {
            wPx: Math.round(rect.width),
            hPx: Math.round(rect.height),
            wPct: Number(((rect.width / layerW) * 100).toFixed(1)),
            hPct: Number(((rect.height / layerH) * 100).toFixed(1)),
          })
        }
        measureTopic()
      })
      obs.observe(el)
      blockElementObserversRef.current.set(blockId, obs)
    }
  }

  /** 稳定 ref 回调工厂：useEffect 内按 identifiedBlocks 的 id 序列生成（render 期不创建
      触达 ref 的闭包，满足 react-hooks/refs；ref 回调在 commit 阶段由 React 调用 →
      经 blockRefImplRef.current.setBlockElementRef 动态转发到每渲染刷新的最新实现）。
      依赖取 id 序列快照：拖拽期坐标/宽度变化不改 id 序列 → map 身份稳定 → ref 回调
      不重挂，ResizeObserver 不抖动（等价 Vue 模板函数 ref 的语义，且消解每 patch 重挂） */
  const blockRefImplRef = useRef<any>({})
  useEffect(() => {
    blockRefImplRef.current.setBlockElementRef = setBlockElementRef
  })

  const [blockRefCbs, setBlockRefCbs] = useState<Map<string, (el: any) => void>>(() => new Map())
  const blockIdsKey = identifiedBlocks.map((b: any) => b.id).join('|')
  useEffect(() => {
    const m = new Map<string, (el: any) => void>()
    identifiedBlocks.forEach((b: any, i: number) => {
      const isTopicAnchor = b.id === 'block-0' || i === 0
      m.set(b.id, (el: any) => blockRefImplRef.current.setBlockElementRef?.(el, b.id, isTopicAnchor))
    })
    // setState 包 rAF 规避 set-state-in-effect（ref 回调晚一帧挂载，度量由 ResizeObserver 自动补齐）
    const raf = requestAnimationFrame(() => setBlockRefCbs(m))
    return () => cancelAnimationFrame(raf)
    // identifiedBlocks 由 blockIdsKey 代表（坐标/宽度变更不改 id 序列，无需重建 ref 回调）
  }, [blockIdsKey])

  function getBlockSizeText(blockId: string) {
    const size = blockRealSizes.get(blockId)
    const widthVal = localBlockWidths.get(blockId) ?? identifiedBlocks.find((b: any) => b.id === blockId)?.w ?? plan.question.w
    if (size) {
      return `宽 ${widthVal}% (${size.wPx}px) × 高 ${size.hPx}px`
    }
    return `宽 ${widthVal}%`
  }

  function onMouseLeaveBlock(id: string) {
    if (hoveredBlockId === id) {
      setHoveredBlockId(null)
    }
  }

  function getBlockStyle(block: any) {
    const coord = localBlockCoords.get(block.id) || { x: block.x, y: block.y }
    const widthVal = localBlockWidths.get(block.id) ?? block.w
    const fs = QUESTION_FONT_SIZE
    return {
      left: `${coord.x}%`,
      top: `${coord.y}%`,
      width: `${widthVal}%`,
      // 固定设计画布上的 30px，仅随整画布同比缩放。
      fontSize: `calc(${fs} * 1cqw / ${CANVAS_SIZE.width / 100})`,
      // ★ 字体宪法 v2: 题目印刷体 = 微软雅黑（真源 stepHandoff.QUESTION_FONT_FAMILY），颜色黑色真源派生
      fontFamily: QUESTION_FONT_FAMILY,
      color: BOARD_TEXT_COLOR,
      // ★ 字体宪法 v2.2: 自然行高 + 2px 分数余量——无单位比数随 cqw 字号同步缩放；
      //   未度量（旧浏览器/SSR）回落 .topic-text 类样式 line-height: normal
      lineHeight: naturalLhWithFractionMargin(topicLhRatio, fs) ?? undefined,
    }
  }

  function getImageStyle() {
    const coord = localBlockCoords.get('topic-image') || { x: plan.image?.x ?? 6, y: plan.image?.y ?? 13.2 }
    return {
      left: `${coord.x}%`,
      top: `${coord.y}%`,
      width: `${plan.image?.w ?? 38}%`,
      maxHeight: topicImageMaxHeight + '%',
    }
  }

  function getBadgeStyle(target: string) {
    const labelKey = `${target}Label`
    const defaultBox = plan[labelKey] || BOARD_LAYOUT[labelKey] || { x: 5, y: 5, w: 7.1 }
    const targetId = `${target}-label`
    const coord = localBlockCoords.get(targetId) || { x: defaultBox.x, y: defaultBox.y }
    return {
      left: `${coord.x}%`,
      top: `${coord.y}%`,
      width: `${defaultBox.w ?? 7.1}%`,
    }
  }

  function getLabelStyle() {
    return getBadgeStyle('topic')
  }
  void getLabelStyle

  function observeTopic() {
    topicObserverRef.current?.disconnect()
    topicObserverRef.current = null
    if (!topicContentRef.current) return

    topicObserverRef.current = new ResizeObserver(measureTopic)
    topicObserverRef.current.observe(topicContentRef.current)
    measureTopic()
  }

  // 原 onMounted(() => nextTick(observeTopic))
  //   + watch([problemText, sourceImageUrl, keepOriginal, topicLayout, boardPlan], deep, nextTick(observeTopic))
  // → 合并为一个 effect：首帧执行 = onMounted；依赖变更执行 = watch
  //   （deep → topicLayout/boardPlan 以 JSON 快照为依赖）
  const boardPlanKey = useMemo(() => JSON.stringify(boardPlan ?? null), [boardPlan])
  useEffect(() => {
    // nextTick → rAF（等块元素 ref 挂载完成后再观察）
    const raf = requestAnimationFrame(observeTopic)
    return () => cancelAnimationFrame(raf)
  }, [problemText, sourceImageUrl, keepOriginal, topicLayoutKey, boardPlanKey])

  // 原 onBeforeUnmount：断开观察器 + 移除 window pointer 监听
  useEffect(() => {
    return () => {
      topicObserverRef.current?.disconnect()
      blockElementObserversRef.current.forEach((obs) => obs.disconnect())
      blockElementObserversRef.current.clear()
      window.removeEventListener('pointermove', stable.pointerMove)
      window.removeEventListener('pointerup', stable.pointerUp)
      window.removeEventListener('pointercancel', stable.pointerUp)
      window.removeEventListener('pointermove', stable.resizeMove)
      window.removeEventListener('pointerup', stable.resizeUp)
      window.removeEventListener('pointercancel', stable.resizeUp)
    }
  }, [])

  return (
    <div ref={layerRef} className="board-content-layer" data-board-layer="L2">
      {/* 四个角标 (支持鼠标直接拖拽排版) */}
      {(problemText.trim() || showExtraLabels) && (
        <div
          id="badge-topic"
          className={[
            'badge board-item label draggable-item',
            activeDrag?.targetId === 'topic-label' ? 'is-dragging' : '',
            dragBoundaryStatus?.targetId === 'topic-label' && dragBoundaryStatus?.isOutOfBounds ? 'is-out-of-bounds' : '',
          ]
            .filter(Boolean)
            .join(' ')}
          data-target="topic"
          style={getBadgeStyle('topic')}
          title="拖动调整「题目」角标位置"
          onPointerDown={(e) =>
            startDrag(
              e,
              'label',
              'topic-label',
              localBlockCoords.get('topic-label')?.x ?? plan.topicLabel.x,
              localBlockCoords.get('topic-label')?.y ?? plan.topicLabel.y,
            )
          }
        >
          {/* 原 onerror 内联属性 → onError 处理器（回退外链图，语义一致） */}
          <img
            src="/topic.png"
            onError={(e) => {
              e.currentTarget.src = 'https://i.ibb.co/bMwPqBpN/topic.png'
            }}
            alt="题目"
            draggable={false}
          />
          {activeDrag?.targetId === 'topic-label' && (
            <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
              {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}
              {activeDrag.currentX.toFixed(1)}%, {activeDrag.currentY.toFixed(1)}%
            </div>
          )}
        </div>
      )}

      {/* 原题图片：支持拖拽 */}
      {keepOriginal && sourceImageUrl && plan.image && (
        <div
          ref={topicContentRef as any}
          className={[
            'board-item topic-image draggable-item',
            activeDrag?.targetId === 'topic-image' ? 'is-dragging' : '',
            dragBoundaryStatus?.targetId === 'topic-image' && dragBoundaryStatus?.isOutOfBounds ? 'is-out-of-bounds' : '',
          ]
            .filter(Boolean)
            .join(' ')}
          style={getImageStyle()}
          title="按住鼠标可自由拖拽原题图"
          onPointerDown={(e) =>
            startDrag(
              e,
              'image',
              'topic-image',
              localBlockCoords.get('topic-image')?.x ?? plan.image.x,
              localBlockCoords.get('topic-image')?.y ?? plan.image.y,
            )
          }
        >
          <img
            src={sourceImageUrl}
            alt="原题"
            draggable={false}
            onLoad={() => measureTopic()}
          />
          {activeDrag?.targetId === 'topic-image' && (
            <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
              {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}
              {activeDrag.currentX.toFixed(1)}%, {activeDrag.currentY.toFixed(1)}%
            </div>
          )}
        </div>
      )}

      {/* 每一个识别出的文本块：点击进入编辑、自由拖拽与实时尺寸更新 */}
      {problemText.trim() && !(keepOriginal && sourceImageUrl) && (
        <>
          {identifiedBlocks.map((block: any) => (
            <div
              key={block.id}
              ref={blockRefCbs.get(block.id)}
              className={[
                'board-item topic-text draggable-item',
                activeDrag?.targetId === block.id ? 'is-dragging' : '',
                editingBlockId === block.id ? 'is-editing' : '',
                activeResize?.blockId === block.id ? 'is-resizing' : '',
                (dragBoundaryStatus?.targetId === block.id || activeResize?.blockId === block.id) && dragBoundaryStatus?.isOutOfBounds
                  ? 'is-out-of-bounds'
                  : '',
              ]
                .filter(Boolean)
                .join(' ')}
              style={getBlockStyle(block)}
              data-board-region="question"
              data-typography="approved-printed-question"
              title={editingBlockId === block.id ? '正在编辑题目文字' : '按住拖动布局 / 单击进入画布编辑'}
              onMouseEnter={() => setHoveredBlockId(block.id)}
              onMouseLeave={() => onMouseLeaveBlock(block.id)}
              onDoubleClick={() => enterEdit(block)}
              onPointerDown={(e) =>
                startDrag(
                  e,
                  'textBlock',
                  block.id,
                  localBlockCoords.get(block.id)?.x ?? block.x,
                  localBlockCoords.get(block.id)?.y ?? block.y,
                )
              }
            >
              {/* 拖拽与点击编辑把手提示 */}
              <div className="drag-handle-hint" title="可按住拖拽排版 / 单击进入编辑">
                <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor">
                  <path d="M10 9h4V6h3l-5-5-5 5h3v3zm-1 1H6V7l-5 5 5 5v-3h3v-4zm14 2l-5-5v3h-3v4h3v3l5-5zm-9 3h-4v3H7l5 5 5-5h-3v-3z" />
                </svg>
                <span className="hint-text">拖动 / 单击编辑</span>
              </div>

              {/* 悬停时快捷操作栏与尺寸实时反馈 */}
              {editingBlockId !== block.id && hoveredBlockId === block.id && (
                <div className="block-hover-toolbar" onPointerDown={(e) => e.stopPropagation()}>
                  <button
                    className="action-pill-btn edit-btn"
                    title="点击直接在画布上修改题目文字"
                    onPointerDown={(e) => {
                      e.stopPropagation()
                      e.preventDefault()
                      enterEdit(block)
                    }}
                  >
                    ✏️ 编辑文字
                  </button>
                  <span className="size-tag" title="拖拽块实时尺寸">
                    {getBlockSizeText(block.id)}
                  </span>
                </div>
              )}

              {/* 编辑模式：内嵌多行文本框（高度根据输入内容实时撑开，边框实时包裹） */}
              {editingBlockId === block.id ? (
                <div className="block-editor-container" onPointerDown={(e) => e.stopPropagation()}>
                  <div className="editor-header">
                    <span className="editor-status-badge">✏️ 正在编辑题目内容</span>
                    <span className="editor-size-badge" title="拖拽块实时尺寸">
                      {getBlockSizeText(block.id)}
                    </span>
                    <button
                      className="save-btn"
                      title="完成并保存修改 (或按 Esc)"
                      onPointerDown={(e) => {
                        e.stopPropagation()
                        e.preventDefault()
                        finishEdit()
                      }}
                    >
                      ✓ 完成
                    </button>
                  </div>
                  <textarea
                    ref={editTextareaRef}
                    value={editingText}
                    onChange={(e) => {
                      setEditingText(e.target.value)
                      onBlockInput(block.id, e.target.value)
                    }}
                    className="inline-block-textarea"
                    placeholder="直接在画布上修改题目文字..."
                    rows={1}
                    onKeyDown={(e) => {
                      if (e.key === 'Escape') finishEdit()
                    }}
                    onBlur={onTextareaBlur}
                  />
                </div>
              ) : (
                /* 浏览展示模式：排版并渲染数学公式与符号（原 v-html → dangerouslySetInnerHTML） */
                <div className="block-content-body" dangerouslySetInnerHTML={{ __html: block.html }} />
              )}

              {/* 拖动坐标指示 */}
              {activeDrag?.targetId === block.id && (
                <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
                  {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}X: {activeDrag.currentX.toFixed(1)}% | Y: {activeDrag.currentY.toFixed(1)}%
                  <span className="coord-size-sub">({getBlockSizeText(block.id)})</span>
                </div>
              )}

              {/* 右侧宽度调整手柄：拉伸改变拖拽块尺寸，并实时重排文字 */}
              <div
                className="block-resize-handle"
                title="左右拖动调节拖拽块宽度"
                onPointerDown={(e) => {
                  e.stopPropagation()
                  startResize(e, block.id, localBlockWidths.get(block.id) ?? block.w)
                }}
              >
                <div className="resize-handle-bar" />
              </div>
            </div>
          ))}
        </>
      )}

      {showExtraLabels && (
        <>
          <div
            id="badge-analysis"
            className={[
              'badge board-item label draggable-item',
              activeDrag?.targetId === 'analysis-label' ? 'is-dragging' : '',
              dragBoundaryStatus?.targetId === 'analysis-label' && dragBoundaryStatus?.isOutOfBounds ? 'is-out-of-bounds' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            data-target="analysis"
            style={getBadgeStyle('analysis')}
            title="拖动调整「分析」角标位置"
            onPointerDown={(e) =>
              startDrag(
                e,
                'label',
                'analysis-label',
                localBlockCoords.get('analysis-label')?.x ?? plan.analysisLabel.x,
                localBlockCoords.get('analysis-label')?.y ?? plan.analysisLabel.y,
              )
            }
          >
            <img
              src="/analysis.png"
              onError={(e) => {
                e.currentTarget.src = 'https://i.ibb.co/9mHsQPSx/analysis.png'
              }}
              alt="分析"
              draggable={false}
            />
            {activeDrag?.targetId === 'analysis-label' && (
              <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
                {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}
                {activeDrag.currentX.toFixed(1)}%, {activeDrag.currentY.toFixed(1)}%
              </div>
            )}
          </div>
          <div
            id="badge-solution"
            className={[
              'badge board-item label draggable-item',
              activeDrag?.targetId === 'solution-label' ? 'is-dragging' : '',
              dragBoundaryStatus?.targetId === 'solution-label' && dragBoundaryStatus?.isOutOfBounds ? 'is-out-of-bounds' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            data-target="solution"
            style={getBadgeStyle('solution')}
            title="拖动调整「解答」角标位置"
            onPointerDown={(e) =>
              startDrag(
                e,
                'label',
                'solution-label',
                localBlockCoords.get('solution-label')?.x ?? plan.solutionLabel.x,
                localBlockCoords.get('solution-label')?.y ?? plan.solutionLabel.y,
              )
            }
          >
            <img
              src="/solution.png"
              onError={(e) => {
                e.currentTarget.src = 'https://i.ibb.co/MxXq10wz/solution.png'
              }}
              alt="解答"
              draggable={false}
            />
            {activeDrag?.targetId === 'solution-label' && (
              <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
                {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}
                {activeDrag.currentX.toFixed(1)}%, {activeDrag.currentY.toFixed(1)}%
              </div>
            )}
          </div>
          <div
            id="badge-summary"
            className={[
              'badge board-item label draggable-item',
              activeDrag?.targetId === 'summary-label' ? 'is-dragging' : '',
              dragBoundaryStatus?.targetId === 'summary-label' && dragBoundaryStatus?.isOutOfBounds ? 'is-out-of-bounds' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            data-target="summary"
            style={getBadgeStyle('summary')}
            title="拖动调整「总结」角标位置"
            onPointerDown={(e) =>
              startDrag(
                e,
                'label',
                'summary-label',
                localBlockCoords.get('summary-label')?.x ?? plan.summaryLabel.x,
                localBlockCoords.get('summary-label')?.y ?? plan.summaryLabel.y,
              )
            }
          >
            <img
              src="/summary.png"
              onError={(e) => {
                e.currentTarget.src = 'https://i.ibb.co/Ld4qjwW9/summary.png'
              }}
              alt="总结"
              draggable={false}
            />
            {activeDrag?.targetId === 'summary-label' && (
              <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
                {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}
                {activeDrag.currentX.toFixed(1)}%, {activeDrag.currentY.toFixed(1)}%
              </div>
            )}
          </div>
        </>
      )}

      {showZoneGuides && showExtraLabels && (
        <>
          <div className="guide analysis" style={pctBox(plan.analysis)} />
          <div className="guide solution" style={pctBox(plan.solution)} />
          <div className="guide summary" style={pctBox(plan.summary)} />
        </>
      )}

      {/* ★ Task 58 布局修订闭环：四区框编辑态——可拖拽平移 analysis/solution/summary 区框。
           越界红警/回弹收敛/coord-badge 全部复用现有拖拽体系；拖完经 syncAll → layout-change 带出。 */}
      {zoneEditable && showExtraLabels && (
        <>
          {zoneEditList.map((z) => (
            <div
              key={'zone-edit-' + z.key}
              className={[
                'zone-edit-box',
                activeDrag?.targetType === 'zone' && activeDrag?.targetId === z.key ? 'is-dragging' : '',
                dragBoundaryStatus?.targetId === z.key && dragBoundaryStatus?.isOutOfBounds ? 'is-out-of-bounds' : '',
              ]
                .filter(Boolean)
                .join(' ')}
              style={zoneBoxStyle(z.key)}
              title={`拖动调整「${z.name}」区域位置`}
              onPointerDown={(e) =>
                startDrag(
                  e,
                  'zone',
                  z.key,
                  localBlockCoords.get(z.key)?.x ?? plan[z.key].x,
                  localBlockCoords.get(z.key)?.y ?? plan[z.key].y,
                )
              }
            >
              {activeDrag?.targetType === 'zone' && activeDrag?.targetId === z.key && (
                <div className={`coord-badge${dragBoundaryStatus?.isOutOfBounds ? ' badge-danger' : ''}`}>
                  {dragBoundaryStatus?.isOutOfBounds ? '⚠️ 越界 ' : ''}
                  {activeDrag.currentX.toFixed(1)}%, {activeDrag.currentY.toFixed(1)}%
                </div>
              )}
            </div>
          ))}
        </>
      )}

      {showGrid && (
        <div className="grid-layer">
          {grid.minor.map((g: any) => (
            <div key={'vm' + g.p} className="grid-line v minor" style={{ left: g.p + '%' }} />
          ))}
          {grid.major.map((g: any) => (
            <div key={'vM' + g.p} className="grid-line v major" style={{ left: g.p + '%' }}>
              <span className="tick">{g.p}</span>
            </div>
          ))}
          {grid.minor.map((g: any) => (
            <div key={'hm' + g.p} className="grid-line h minor" style={{ top: g.p + '%' }} />
          ))}
          {grid.major.map((g: any) => (
            <div key={'hM' + g.p} className="grid-line h major" style={{ top: g.p + '%' }}>
              <span className="tick y">{g.p}</span>
            </div>
          ))}
        </div>
      )}

      {/* 实时视觉校验层：1726×980 边界检测与越界高亮 */}
      {dragBoundaryStatus && (
        <div
          className={`boundary-verifier-overlay${dragBoundaryStatus.isOutOfBounds ? ' has-overflow' : ''}`}
        >
          {/* 四周边界警示高亮带 */}
          <div
            className={`boundary-guide boundary-guide-top${dragBoundaryStatus.overTop ? ' is-breached' : ''}`}
          >
            {dragBoundaryStatus.overTop && (
              <span className="boundary-guide-tag">
                ⚠️ 顶部越界：超出 {Math.abs(dragBoundaryStatus.y).toFixed(1)}%
              </span>
            )}
          </div>
          <div
            className={`boundary-guide boundary-guide-bottom${dragBoundaryStatus.overBottom ? ' is-breached' : ''}`}
          >
            {dragBoundaryStatus.overBottom && (
              <span className="boundary-guide-tag">
                ⚠️ 底部越界：超出 {(dragBoundaryStatus.bottom - 100).toFixed(1)}%
              </span>
            )}
          </div>
          <div
            className={`boundary-guide boundary-guide-left${dragBoundaryStatus.overLeft ? ' is-breached' : ''}`}
          >
            {dragBoundaryStatus.overLeft && (
              <span className="boundary-guide-tag">
                ⚠️ 左侧越界：超出 {Math.abs(dragBoundaryStatus.x).toFixed(1)}%
              </span>
            )}
          </div>
          <div
            className={`boundary-guide boundary-guide-right${dragBoundaryStatus.overRight ? ' is-breached' : ''}`}
          >
            {dragBoundaryStatus.overRight && (
              <span className="boundary-guide-tag">
                ⚠️ 右侧越界：超出 {(dragBoundaryStatus.right - 100).toFixed(1)}%
              </span>
            )}
          </div>

          {/* 实时视觉校验胶囊 HUD */}
          <div
            className={`boundary-hud-capsule ${dragBoundaryStatus.isOutOfBounds ? 'hud-danger' : 'hud-safe'}`}
          >
            {dragBoundaryStatus.isOutOfBounds ? (
              <>
                <span className="hud-icon">⚠️</span>
                <span className="hud-text">
                  <b>越界警告：</b>内容已超出 1726×980 画布范围（{dragBoundaryStatus.violations.join('，')}）
                </span>
                <span className="hud-sub">松开前请移至画布有效范围内</span>
              </>
            ) : (
              <>
                <span className="hud-icon">✓</span>
                <span className="hud-text">
                  <b>1726×980 画布有效范围内</b>
                </span>
                <span className="hud-coords">
                  X: {dragBoundaryStatus.x}% | Y: {dragBoundaryStatus.y}% | W: {dragBoundaryStatus.w}%
                </span>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
