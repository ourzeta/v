'use client'

/**
 * 1:1 移植自 /home/z/teaching-board/src/components/ProcessLoadingModal.vue
 *
 * - defineProps → interface props（保留源码全部 4 个 prop：visible/title/mode/customStages，
 *   mode 取值 'agent-b' | 'check' | 'step1' | 'speech'，默认 'agent-b'）
 * - elapsedSec/tipIndex ref → useState；watch(visible, immediate:true) → useEffect（首帧执行一次）
 * - computed（stages/currentStageIndex/currentStageText/progressPct/currentTip）→ 直接计算
 */
import { useEffect, useRef, useState } from 'react'
import './ProcessLoadingModal.css'

export interface ProcessStage {
  label: string
  durationSec?: number
}

export interface ProcessLoadingModalProps {
  visible?: boolean
  title?: string
  mode?: 'agent-b' | 'check' | 'step1' | 'speech'
  customStages?: ProcessStage[]
}

const DEFAULT_STAGES_MAP: Record<string, ProcessStage[]> = {
  'agent-b': [
    { label: '研读题目条件与知识支架', durationSec: 3 },
    { label: '解构数量关系与思维引导路径', durationSec: 6 },
    { label: '推导启发式分步教学口播脚本', durationSec: 7 },
    { label: '规划黑板四区与单手动作互斥时序', durationSec: 8 },
    { label: '组装五字段标准音画交付模型', durationSec: 15 }
  ],
  'check': [
    { label: '第二双眼睛开启双盲审阅', durationSec: 2 },
    { label: '逐行润色口播断句与标点节奏', durationSec: 5 },
    { label: '校验 ASR 中文数字及专有名词', durationSec: 6 },
    { label: '严格校验板书与动作互斥时间线', durationSec: 6 },
    { label: '整合双向差分与质检修复建议', durationSec: 10 }
  ],
  'step1': [
    { label: '载入题板快照与原始板书', durationSec: 2 },
    { label: 'OCR 解析题干文本与约束条件', durationSec: 4 },
    { label: '智能测算黑板四区黄金排版比例', durationSec: 5 },
    { label: '构建教学底图与落位元数据', durationSec: 8 }
  ],
  'speech': [
    { label: '预处理口播文本与中文发音规则', durationSec: 2 },
    { label: '调用高品质拟真 TTS 语音合成', durationSec: 6 },
    { label: '音频本地持久化与媒体时序对其', durationSec: 6 }
  ]
}

const TIPS = [
  '动作时间定量 1~2 秒，作为口播中的标点停顿，绝不与板书重叠并发。',
  '每个 row 为一组独立单元，语音贯穿全程，板书与动作二者绝对互斥。',
  '四区黑板架构：题目区、分析区、解答区、总结区，彼此物理隔离不挤压。',
  '板书按教学内容自然换行，保留老师现场书写的留白层次。',
  '交付数据已深度解耦，附带标准 API 协议，供下游课件与画布 Agent 直接消费。'
]

export default function ProcessLoadingModal({
  visible = false,
  title = '数据分析与教学编排中',
  mode = 'agent-b',
  customStages = [],
}: ProcessLoadingModalProps) {
  const [elapsedSec, setElapsedSec] = useState(0)
  const [tipIndex, setTipIndex] = useState(() =>
    // 挂载且 visible=true 时原 startTiming 会随机初始化 tipIndex
    visible ? Math.floor(Math.random() * TIPS.length) : 0,
  )
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const tipTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // ★ 原 watch(() => props.visible, immediate:true) 的 startTiming 复位段：
  //   渲染期调整（visible 变化当帧生效，等价 Vue 同步 watch）
  const prevVisibleRef = useRef(visible)
  if (visible !== prevVisibleRef.current) {
    prevVisibleRef.current = visible
    if (visible) {
      setElapsedSec(0)
      setTipIndex(Math.floor(Math.random() * TIPS.length))
    }
  }

  // startTiming 的双 interval 段 / stopTiming（visible=false 或卸载时清理）
  useEffect(() => {
    if (!visible) return
    timerRef.current = setInterval(() => {
      setElapsedSec((s) => s + 1)
    }, 1000)
    tipTimerRef.current = setInterval(() => {
      setTipIndex((t) => (t + 1) % TIPS.length)
    }, 5000)
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
      if (tipTimerRef.current) {
        clearInterval(tipTimerRef.current)
        tipTimerRef.current = null
      }
    }
  }, [visible])

  const stages =
    customStages && customStages.length > 0
      ? customStages
      : DEFAULT_STAGES_MAP[mode] || DEFAULT_STAGES_MAP['agent-b']

  const totalStages = stages.length

  // 根据耗时动态计算当前进行到的阶段
  let currentStageIndex = stages.length - 1
  {
    let accum = 0
    for (let i = 0; i < stages.length; i++) {
      accum += stages[i].durationSec || 5
      if (elapsedSec < accum) {
        currentStageIndex = i
        break
      }
    }
  }

  const currentStage = stages[currentStageIndex]
  const currentStageText = currentStage ? currentStage.label : '正在处理核心运算...'

  const totalPlanned = stages.reduce((sum, s) => sum + (s.durationSec || 5), 0)
  const progressPct =
    totalPlanned <= 0
      ? 30
      : // 渐进缓慢逼近 96%，在完成前不卡满 100%
        Math.min(96, Math.round((elapsedSec / totalPlanned) * 90) + 6)

  const currentTip = TIPS[tipIndex % TIPS.length]

  if (!visible) return null

  return (
    <div className="process-loading-overlay">
      <div className="process-loading-card">
        {/* 动态呼吸光晕外环 */}
        <div className="glow-orb-wrapper">
          <div className="glow-pulse-ring ring-outer" />
          <div className="glow-pulse-ring ring-inner" />
          <div className="ai-core-orb">
            <div className="core-sparkle">
              <svg className="sparkle-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
          </div>
        </div>

        {/* 动态主标题与跳动动效 */}
        <div className="process-header">
          <h3 className="process-title">
            {title || 'AI 教学引擎正在运算中'}
            <span className="animated-dots">
              <span>.</span>
              <span>.</span>
              <span>.</span>
            </span>
          </h3>
          <p className="process-subtitle">{currentStageText}</p>
        </div>

        {/* 阶段步骤流转进度条 */}
        <div className="stage-track-wrapper">
          <div className="stage-progress-bar">
            <div className="stage-progress-fill" style={{ width: `${progressPct}%` }} />
            <div className="progress-light-gleam" style={{ left: `${progressPct}%` }} />
          </div>
          <div className="stage-meta-row">
            <span className="stage-step-tag">步骤 {currentStageIndex + 1} / {totalStages}</span>
            <span className="elapsed-timer">已耗时 {elapsedSec} 秒</span>
          </div>
        </div>

        {/* 阶段列表流转指示 */}
        <div className="stages-indicator-list">
          {stages.map((st, idx) => (
            <div
              key={idx}
              className={[
                'stage-indicator-item',
                idx === currentStageIndex ? 'is-active' : '',
                idx < currentStageIndex ? 'is-done' : '',
                idx > currentStageIndex ? 'is-pending' : '',
              ]
                .filter(Boolean)
                .join(' ')}
            >
              <div className="stage-dot">
                {idx < currentStageIndex ? (
                  <span className="check-icon">✓</span>
                ) : idx === currentStageIndex ? (
                  <span className="active-pulse" />
                ) : (
                  <span className="pending-num">{idx + 1}</span>
                )}
              </div>
              <span className="stage-name">{st.label}</span>
            </div>
          ))}
        </div>

        {/* 底部教学贴士 / 解耦规范小提醒 */}
        <div className="loading-footer-tip">
          <div className="tip-icon">💡</div>
          <div className="tip-text">{currentTip}</div>
        </div>
      </div>
    </div>
  )
}
