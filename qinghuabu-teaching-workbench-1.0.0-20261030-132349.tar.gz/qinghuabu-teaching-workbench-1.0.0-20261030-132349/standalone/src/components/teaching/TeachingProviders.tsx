"use client";

/**
 * TeachingProviders — 1:1 复刻原 main.js + App.vue 的全局装配：
 *   ① message.config（top 72px / duration 2.5 / maxCount 3）
 *   ② initBiuBubbleListener（治愈系 biu 小气泡）
 *   ③ ConfigProvider zh_CN（商品化 P4：全中文产品里弹窗按钮不再出现 Cancel/OK）
 *   ④ @ant-design/v5-patch-for-react-19（antd v5 兼容 React 19）
 *   ⑤ GlobalPulseLoading 挂载（原 App.vue 根组件装载）
 */

import { useEffect } from "react";
import { ConfigProvider } from "antd";
import zhCN from "antd/locale/zh_CN";
import { message } from "antd";
import GlobalPulseLoading from "./GlobalPulseLoading";

let messageConfigured = false;
let biuInited = false;

export default function TeachingProviders({
  children,
}: {
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!messageConfigured) {
      message.config({
        top: 72,
        duration: 2.5,
        maxCount: 3,
      });
      messageConfigured = true;
    }
    if (!biuInited) {
      import("@/utils/biuBubble.js").then((mod) => {
        mod.initBiuBubbleListener();
        biuInited = true;
      });
    }
  }, []);

  return (
    <ConfigProvider locale={zhCN}>
      {children}
      <GlobalPulseLoading />
    </ConfigProvider>
  );
}
