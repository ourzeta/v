'use client'

/* @qh-core LANE=STEP1 POINT=UI_CONFIRM recognize+type+boardPlan+save handoff */
// Step1Entry.vue → React 1:1 移植（Task 4-a）
// 原文件：/home/z/teaching-board/src/components/Step1Entry.vue（2172 行）
// Vue→React 对应关系：ref→useState+ref 镜像（异步流程内"先写后读"语义与 Vue .value 一致）、
// computed→渲染期直算/lazy 函数、watch(deep,immediate)→useEffect、emit→props 回调
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import {
  Alert,
  Button,
  Card,
  Col,
  Descriptions,
  Divider,
  Drawer,
  Form,
  Input,
  Layout,
  message,
  Modal,
  Row,
  Select,
  Space,
  Switch,
  Tag,
  Tooltip,
  Typography,
  Upload,
} from 'antd'
import {
  CloudUploadOutlined,
  CheckCircleOutlined,
  ReloadOutlined,
  SearchOutlined,
  SettingOutlined,
  FullscreenOutlined,
} from '@ant-design/icons'
import { recognizeProblem, fileToDataUrl, compressImageToDataUrl } from '@/services/recognitionClient'
import { renderProblemHtml } from '@/utils/mathText'
// ★ 2026-10-14 分支2移植：识别回填清洗传输损伤（rac{→\frac、实体、字面\n、HTML标签）
import { normalizeCanvasText } from '@/utils/canvasText.js'
import { buildStep1Handoff, hasUsableAgentAKnowledge, QUESTION_FONT_SIZE } from '@/services/stepHandoff'
import { saveLiveBoardPreview } from '@/board-preview/liveBoardPreview.js'
import { selectAgentARelatedKnowledge } from '@/services/agentAKnowledge.js'
import {
  userApiConfig,
  saveUserApiConfig,
  isUserApiReady,
  subscribeUserApiConfig,
  parseApiKeys,
  isUsingPresetApiConfig,
} from '@/lib/userApiConfig.js'
import {
  checkAgentApiConfig,
  saveCheckAgentApiConfig,
  isCheckAgentApiReady,
  isUsingPresetCheckAgentApiConfig,
} from '@/lib/checkAgentApiConfig.js'
import {
  agentBApiConfig,
  saveAgentBApiConfig,
  isAgentBApiReady,
  isUsingPresetAgentBApiConfig,
} from '@/lib/agentBApiConfig.js'
import RealBoardPreview from '@/components/teaching/RealBoardPreview'
import QhPageHeader from '@/components/teaching/QhPageHeader'
import { planLabelsFromTopic, BOARD_LAYOUT, TOPIC_TEXT_W_PCT, TOPIC_IMAGE_W_PCT } from '@/utils/boardLayout'
import { detectContentLandscape } from '@/utils/imageContentRegion.js'
// ★ 2026-10-14：safeFetchJson 升格共享真源 src/lib/safeJsonFetch.js（agentB refine/apply
// 同源接入），本组件保留同名薄委托——行为契约不变，调用点零改动
import { safeJsonFetch } from '@/lib/safeJsonFetch.js'
import { getReactiveVersion, subscribeReactive } from '@/lib/vueShim.js'
import './Step1Entry.css'

// 生产车间第1步：真画布上贴题，不是假预览壳

/** Vue ref → React 等价桥：state 管渲染，ref 镜像同步可读（同一异步流程内先 set 后读，读到的永远是新值，等价 Vue ref.value） */
function useSyncedRef<T>(initial: T) {
  const [state, setState] = useState<T>(initial)
  const ref = useRef<T>(initial)
  const set = (next: T | ((prev: T) => T)) => {
    const resolved = typeof next === 'function' ? (next as (prev: T) => T)(ref.current) : next
    ref.current = resolved
    setState(resolved)
  }
  return [state, set, ref] as const
}

/**
 * ★ 2026-10-14 blocks 陈旧防御：只有当保存的文本块拼起来与当前题目文本一致时才复用。
 * syncAll 的正常回路里 blocks 文本永远与 problemText 同步（用户拖拽/编辑后二者相等）；
 * 只有"新识别回填了新题"或"用户直接改了输入框"时二者才会分叉——分叉即陈旧，弃用旧块
 * 改按新文本重新切块。坐标/宽度等纯排版信息不受影响，只判文本。
 */
function savedBlocksMatchCurrentText(blocks: any, currentText: any) {
  if (!Array.isArray(blocks) || blocks.length === 0) return null
  const joined = blocks
    .map((b: any) => String(b?.text || '').trim())
    .filter(Boolean)
    .join('\n')
  if (!joined) return null
  return joined === String(currentText || '').trim()
    ? blocks.map((block: any) => ({ ...block, fontSize: QUESTION_FONT_SIZE }))
    : null
}

function suggestFromText(text: string) {
  const raw = text || ''
  // 题型特征模式识别与侧重匹配：几何题核心特征（面积/周长/角度/边长等）
  const geometryHit =
    /梯形|平行四边形|矩形|正方形|菱形|三角|圆|扇形|几何|图形|如图|作图|证明|∠|°|底边|高|对角线|相似|全等|平行|垂直|面积|周长|体积|边长|长|宽|角度|求角|夹角|圆心角|半径|直径|弦|弧|面积是多少|边长是多少/.test(
      raw,
    )
  if (geometryHit) {
    return { type: 'geometry', focus: 'geometry_diagram' }
  }
  if (/方程|计算|求值|化简|运算|简便|竖式/.test(raw)) {
    return { type: 'calculation', focus: 'calculation_process' }
  }
  // 应用题：一般有场景（小船、鸡兔同笼、行程工程买卖等），暂粗判
  if (
    /应用题|场景|小船|顺水|逆水|鸡兔同笼|鸡|兔|行程|工程|速度|工作效率|买|卖|原价|折扣|余下|还剩|一共|多少人|多少钱|果园|工厂|水池/.test(
      raw,
    )
  ) {
    return { type: 'word', focus: 'relation_understanding' }
  }
  return { type: undefined, focus: undefined }
}

/* ★ 2026-10-14 夏夏定的贴图规则（取代旧 detectLandscape 整图宽高比>1.4 的肤浅判断）：
 *   判定依据 = 图片里「黑色文本内容区域」的长宽比，不是整张图的——
 *   照片白边、纸张留白、取景框都会污染整图判断。
 *   内容区域长(横向)>宽(纵向) → 横向贴入（isLandscape=true：图贴顶、三区横排在下）；
 *   长<宽 → 左侧贴图、左右开布局（isLandscape=false：图占左列、三区右侧纵排）。
 *   实现：utils/imageContentRegion.js（黑字阈值→Otsu 自适应→整图回退三层） */
async function detectLandscape(dataUrl: string) {
  const info = await detectContentLandscape(dataUrl)
  console.log(
    `[贴图规则] 内容区域判定 method=${info.method} aspect=${info.aspect}` +
      (info.region ? ` region=${info.region.w}x${info.region.h}` : '') +
      ` 整图=${info.imageWidth}x${info.imageHeight} → ${info.landscape ? '横向贴入' : '左侧贴图·左右开'}`,
  )
  return info.landscape
}

const problemTypeOptions = [
  { value: 'geometry', label: '几何题' },
  { value: 'calculation', label: '计算运算题' },
  { value: 'word', label: '应用题' },
  { value: 'other', label: '其他' },
]

const boardFocusOptions = [
  { value: 'geometry_diagram', label: '几何图解', forTypes: ['geometry'] },
  { value: 'calculation_process', label: '演算过程', forTypes: ['calculation'] },
  { value: 'relation_understanding', label: '关系理解（可画图）', forTypes: ['word'] },
  { value: 'mixed', label: '综合分析', forTypes: ['geometry', 'calculation', 'word', 'other'] },
]

/** 测试题库：仅用于快捷复制题目（用户自己粘贴到题目框），不参与任何业务逻辑 */
const TEST_PROBLEM_GROUPS = [
  {
    group: '应用题',
    items: [
      '一缸水，用去1/2和5桶，还剩30%，这缸水有多少桶？',
      '一根钢管长10米，第一次截去它的7/10，第二次又截去余下的1/3，还剩多少米？',
      '修筑一条公路，完成了全长的2/3后，离中点16.5千米，这条公路全长多少千米？',
      '师徒两人合做一批零件，徒弟做了总数的2/7，比师傅少做21个，这批零件有多少个？',
      '仓库里有一批化肥，第一次取出总数的2/5，第二次取出总数的1/3少12袋，这时仓库里还剩24袋，两次共取出多少袋？',
      '甲乙两地相距1152千米，一列客车和一列货车同时从两地对开，货车每小时行72千米，比客车快2/7，两车经过多少小时相遇？',
      '一件上衣比一条裤子贵160元，其中裤子的价格是上衣的3/5，一条裤子多少元？',
    ],
  },
  {
    group: '百分数的应用题',
    items: [
      '某化肥厂今年产值比去年增加了20%，比去年增加了500万元，今年产值是多少万元？',
      '果品公司储存一批苹果，售出这批苹果的30%后，又运来160箱，这时比原来储存的苹果多1/10，这时有苹果多少箱？',
      '一件商品，原价比现价少20%，现价是1028元，原价是多少元？',
      '教育储蓄所得的利息不用纳税。爸爸为笑笑存了三年期的教育储蓄基金，年利率为5.40%，到期后共领到了本金和利息22646元。爸爸为笑笑存的教育储蓄基金的本金是多少？',
      '服装店同时卖出了两件衣服，每件衣服各得120元，但其中一件赚20%，另一件赔了20%，问服装店卖出的两件衣服是赚钱了还是亏本了？',
      '爸爸今年43岁，女儿今年11岁，几年前女儿年龄是爸爸的20%？',
      '比5分之2吨少20%是（ ）吨，（ ）吨的30%是60吨。',
      '一本200页的书，读了20%，还剩下（ ）页没读。甲数的40%与乙数的50%相等，甲数是120，乙数是（ ）。',
      '某工厂四月份下半月用水5400吨，比上半月节约20%，上半月用水多少吨？',
      '张平有500元钱，打算存入银行两年可以有两种储蓄办法，一种是存两年期的，年利率是2.43%；一种是先存一年期的，年利率是2.25%，第一年到期时再把本金和税后利息取出来合在一起，再存入一年。选择哪种办法得到的税后利息多一些？',
    ],
  },
  {
    group: '圆的应用题',
    items: [
      '画一个周长12.56厘米的圆，并用字母标出圆心和一条半径，再求出这个圆的面积。',
      '学校有一块圆形草坪，它的直径是30米，这块草坪的面积是多少平方米？如果沿着草坪的周围每隔1.57米摆一盆菊花，要准备多少盆菊花？',
      '一个圆和一个扇形的半径相等，圆面积是30平方厘米，扇形的圆心角是36度。求扇形的面积。',
      '前轮在720米的距离里比后轮多转40周，如果后轮的周长是2米，求前轮的周长。',
    ],
  },
]

interface Step1EntryProps {
  /** 对应原 emit('enter-board-draft', payload) */
  onEnterBoardDraft?: (payload?: any) => void
}

export default function Step1Entry({ onEnterBoardDraft }: Step1EntryProps) {
  const [problemText, setProblemText, problemTextRef] = useSyncedRef<string>('')
  const [sourceImageUrl, setSourceImageUrl, sourceImageUrlRef] = useSyncedRef<string>('')
  const [sourceImageName, setSourceImageName, sourceImageNameRef] = useSyncedRef<string>('')
  const [sourceImageDataUrl, setSourceImageDataUrl, sourceImageDataUrlRef] = useSyncedRef<string>('')
  const [sourceImagePreviewOpen, setSourceImagePreviewOpen] = useState(false)
  const [keepOriginal, setKeepOriginal, keepOriginalRef] = useSyncedRef<boolean>(false)
  const [recognizeStatus, setRecognizeStatus, recognizeStatusRef] = useSyncedRef<string>('idle')
  const [layoutStatus, setLayoutStatus, layoutStatusRef] = useSyncedRef<string>('idle') // idle | ready | regenerating
  const [layoutSeed, setLayoutSeed, layoutSeedRef] = useSyncedRef<number>(0)
  const [isLandscape, setIsLandscape, isLandscapeRef] = useSyncedRef<boolean>(false)
  const [step1Confirmed, setStep1Confirmed, step1ConfirmedRef] = useSyncedRef<boolean>(false)
  const [boardPlan, setBoardPlan, boardPlanRef] = useSyncedRef<any>(null)
  const [showGrid, setShowGrid, showGridRef] = useSyncedRef<boolean>(false)
  const [labelsPlanned, setLabelsPlanned, labelsPlannedRef] = useSyncedRef<boolean>(false)
  const [topicMeasurement, setTopicMeasurement, topicMeasurementRef] = useSyncedRef<any>({ bottomPct: null, heightPct: null })
  // 截图存档：planBoardLabels 后截 .board-viewport，存 public/pic/，handoff 存 screenshotUrl
  const previewCaptureRef = useRef<HTMLDivElement | null>(null)
  const [screenshotUrl, setScreenshotUrl, screenshotUrlRef] = useSyncedRef<string>('')
  const [screenshotPreviewOpen, setScreenshotPreviewOpen] = useState(false)
  const [screenshotting, setScreenshotting] = useState(false)
  const SNAPSHOT_TIMEOUT_MS = 6000

  const [problemType, setProblemType, problemTypeRef] = useSyncedRef<any>(undefined)
  const [boardFocus, setBoardFocus, boardFocusRef] = useSyncedRef<any>(undefined)
  const [knowledgeStatus, setKnowledgeStatus, knowledgeStatusRef] = useSyncedRef<string>('idle')
  const [relatedKnowledge, setRelatedKnowledge, relatedKnowledgeRef] = useSyncedRef<any[]>([])
  const [selectedKnowledge, setSelectedKnowledge] = useState<any>(null)
  const [knowledgeError, setKnowledgeError, knowledgeErrorRef] = useSyncedRef<string>('')
  // Agent A 深度知识点分析结果（识别时由 LLM 直接产出，不再依赖本地 n-gram 浅匹配）
  const [knowledgeAnalysis, setKnowledgeAnalysis, knowledgeAnalysisRef] = useSyncedRef<any>(null)
  const [suggestedGrade, setSuggestedGrade, suggestedGradeRef] = useSyncedRef<string>('')
  const [uncertainItems, setUncertainItems, uncertainItemsRef] = useSyncedRef<any[]>([])
  const [suggestedLayout, setSuggestedLayout, suggestedLayoutRef] = useSyncedRef<any>(null)

  const AGENT_STORAGE_KEY = 'qinghuabu.step1.agentConfig'

  const [agentConfig, setAgentConfig] = useState<any>({
    pageName: '第1步 · 贴题识别',
    capability: 'multimodal',
    autoRecognize: true,
  })

  const [agentDrawerOpen, setAgentDrawerOpen] = useState(false)
  const [testBankOpen, setTestBankOpen] = useState(false)
  const [copiedProblemKey, setCopiedProblemKey] = useState('')

  // 点击题目 → 复制到剪贴板（用户自己粘贴到题目框，不自动回填）
  // clipboard API 在部分环境会永久 pending（既不 resolve 也不 reject）→ 加 800ms 超时兜底
  const handleCopyTestProblem = async (text: string, key: string) => {
    let ok = false
    try {
      if (navigator.clipboard) {
        await Promise.race([
          navigator.clipboard.writeText(text),
          new Promise((_, reject) => setTimeout(() => reject(new Error('clipboard timeout')), 800)),
        ])
        ok = true
      }
    } catch {
      ok = false
    }
    if (!ok) {
      try {
        const ta = document.createElement('textarea')
        ta.value = text
        ta.setAttribute('readonly', '')
        ta.style.position = 'fixed'
        ta.style.top = '0'
        ta.style.left = '-9999px'
        ta.style.opacity = '0'
        document.body.appendChild(ta)
        ta.focus()
        ta.select()
        ta.setSelectionRange(0, ta.value.length)
        ok = document.execCommand('copy')
        document.body.removeChild(ta)
      } catch {
        ok = false
      }
    }
    if (ok) {
      setCopiedProblemKey(key)
      message.success('已复制')
      setTimeout(() => setCopiedProblemKey(''), 1500)
    } else {
      message.warning('复制失败，请手动选中题目文本复制')
    }
  }

  function loadAgentConfig() {
    try {
      const raw = localStorage.getItem(AGENT_STORAGE_KEY)
      if (!raw) return
      const saved = JSON.parse(raw)
      setAgentConfig((prev: any) => ({
        ...prev,
        capability: saved.capability || prev.capability,
        autoRecognize: saved.autoRecognize !== false,
      }))
    } catch (error) {
      // ignore bad local cache
    }
  }

  // setup 同步调用 → 挂载后执行一次（localStorage 仅在 client 生命周期访问）
  useEffect(() => {
    loadAgentConfig()
    subscribeUserApiConfig(() => {})
  }, [])

  const [customTopicLayout, setCustomTopicLayout, customTopicLayoutRef] = useSyncedRef<any>(null)

  // setup 内 customTopicLayout 的 localStorage 恢复 → 挂载后执行一次（SSR 安全）
  useEffect(() => {
    try {
      const saved = localStorage.getItem('qinghuabu.customTopicLayout')
      if (saved) {
        setCustomTopicLayout(JSON.parse(saved))
      }
    } catch (_) {}
  }, [])

  // ★ vueShim reactive 单例订阅 → React 渲染同步（版本号驱动重渲染；抽屉表单 v-model 直接改写代理属性，语义与 ant-design-vue 一致）
  // 第三参 getServerSnapshot：SSR 期同样返回版本号（服务端恒 0），缺省会导致 SSR 500
  useSyncExternalStore(
    (onStoreChange) => subscribeReactive(userApiConfig, onStoreChange),
    () => getReactiveVersion(userApiConfig),
    () => getReactiveVersion(userApiConfig),
  )
  useSyncExternalStore(
    (onStoreChange) => subscribeReactive(agentBApiConfig, onStoreChange),
    () => getReactiveVersion(agentBApiConfig),
    () => getReactiveVersion(agentBApiConfig),
  )
  useSyncExternalStore(
    (onStoreChange) => subscribeReactive(checkAgentApiConfig, onStoreChange),
    () => getReactiveVersion(checkAgentApiConfig),
    () => getReactiveVersion(checkAgentApiConfig),
  )

  // computed agentReady：本地过交互可不配 endpoint；要真识别再要求 apiKey+endpoint+model 齐备
  const agentReady = Boolean(agentConfig.capability) && isUserApiReady()

  // computed agentSummary —— 系统预设时不暴露模型型号
  const agentSummary = (() => {
    if (isUsingPresetApiConfig()) return `${agentConfig.capability} · 当前使用的是系统预设`
    const model = userApiConfig.model || '未填模型'
    const ep = userApiConfig.endpoint ? '已填服务' : '服务未填'
    const key = userApiConfig.apiKey ? '· Key 已填' : '· Key 未填'
    return `${agentConfig.capability} · ${model} · ${ep} ${key}`
  })()

  // computed problemTextHtml（与原版一致：定义于脚本、模板未引用，1:1 保留）
  const problemTextHtml = renderProblemHtml(problemText)

  // 题目层落位（相对 1726×980 百分比，来自已验证 demo 落点）
  // 布局规则：图片题目区 = 左半(w≤44%) + 上半(y从标签下13.2%到50%) = maxH≈36%
  // 文字题目：只填左侧文字，不走图片分支
  // ★ Task 60 坐标归一：标签/题目 x,y 改 BOARD_LAYOUT 真源 import（原手押 5.7/6.6/6.0/13.2），
  //   题目文字宽 40.4/竖图宽 38 显式常量入真源（boardLayout.js），消灭与 BOARD_LAYOUT.question.w=44 心照不宣的双值
  const baseLayout = {
    topicLabel: { ...BOARD_LAYOUT.topicLabel },
    question: { x: BOARD_LAYOUT.question.x, y: BOARD_LAYOUT.question.y, w: TOPIC_TEXT_W_PCT },
    image: { x: BOARD_LAYOUT.question.x, y: BOARD_LAYOUT.question.y, w: TOPIC_IMAGE_W_PCT },   // 高度由 limitTopicImageHeightPct 自适应到画布底，不写死 maxH
  }

  // computed topicLayout（lazy 函数化：读 ref 镜像，事件流内任意时机取值都新鲜 = Vue computed .value 语义）
  function computeTopicLayout() {
    // 重新生成：只微调题目块，不乱动甲方底板
    const jitter = (layoutSeedRef.current % 3) * 0.4
    const hasImage = Boolean(sourceImageUrlRef.current && keepOriginalRef.current)
    const auto: any = {
      topicLabel: { ...baseLayout.topicLabel },
      image: hasImage
        ? {
            x: baseLayout.image.x,
            y: baseLayout.image.y,
            // 横图(宽>高)上下布局：图片宽占满安全区（6%~94%）
            // 竖图(高>宽)左右布局：图片占左列，宽约44%
            // 高度均由 limitTopicImageHeightPct 自适应到画布底，不在这里限制
            w: isLandscapeRef.current ? 88 : baseLayout.image.w - jitter * 0.3,
          }
        : null,
      question: {
        x: baseLayout.question.x,
        y: hasImage ? 42 + jitter : baseLayout.question.y + jitter * 0.3,
        w: baseLayout.question.w - jitter * 0.2,
        fontSize: QUESTION_FONT_SIZE,
      },
    }

    if (customTopicLayoutRef.current) {
      return {
        ...auto,
        ...customTopicLayoutRef.current,
        question: {
          ...auto.question,
          ...(customTopicLayoutRef.current.question || {}),
          fontSize: QUESTION_FONT_SIZE,
        },
        image: auto.image
          ? { ...auto.image, ...(customTopicLayoutRef.current.image || {}) }
          : null,
        topicLabel: {
          ...auto.topicLabel,
          ...(customTopicLayoutRef.current.topicLabel || {}),
        },
        // ★ 2026-10-14 blocks 陈旧防御：旧题的文本块（localStorage 恢复）与当前题目文本
        //   不一致 = 上一题的排版残留，不得压过新识别回填的题目（画布显示旧题=回填"完全不一样"的真凶之一）
        blocks: savedBlocksMatchCurrentText(customTopicLayoutRef.current.blocks, problemTextRef.current) || auto.blocks,
      }
    }

    return auto
  }

  const topicLayout = computeTopicLayout()

  // computed hasBoardContent（函数化：读 ref 镜像，markLayoutReady 等异步链路内取值新鲜）
  function hasBoardContent() {
    return Boolean(problemTextRef.current.trim() || sourceImageUrlRef.current)
  }

  // computed suggestedLayoutLabel
  const suggestedLayoutLabel =
    (({ left_right: '左右布局', top_bottom: '上下布局' } as any)[suggestedLayoutRef.current?.layout] ||
      suggestedLayoutRef.current?.layout ||
      '自动落座')

  // computed canQueryKnowledge
  const canQueryKnowledge =
    problemText.trim().length > 0 &&
    layoutStatus === 'ready' &&
    Boolean(problemType) &&
    Boolean(boardFocus) &&
    !step1Confirmed

  const [confirming, setConfirming] = useState(false)

  // computed canConfirm
  const canConfirm = hasBoardContent() && recognizeStatus !== 'loading' && !step1Confirmed

  // 薄委托共享真源：非 JSON 响应守卫/重试退避/网络异常兜底逻辑全部在 lib 层
  async function safeFetchJson(url: string, options: any = {}, retries = 1) {
    return safeJsonFetch(url, options, { retries, label: '第1步' })
  }

  // computed statusText
  function getStatusText() {
    if (step1ConfirmedRef.current) return '第1步已确认：题目已落在甲方画布题目层。'
    if (recognizeStatusRef.current === 'loading') return '识别中，识别完直接贴上画布…'
    if (layoutStatusRef.current === 'regenerating') return '按画布重新落位…'
    if (!hasBoardContent()) return '初始是空白甲方画布。贴题后，题目直接放上去。'
    if (sourceImageUrlRef.current && !keepOriginalRef.current && problemTextRef.current.trim()) {
      return '纯文字题图已按文本处理：画布只放题文，不贴原图。核对题型后可确认。'
    }
    if (!problemTypeRef.current || !boardFocusRef.current) return '确认题型与板书侧重。'
    if (knowledgeStatusRef.current !== 'success') return '题型已确认，可查询知识关联点，也可直接进入下一步。'
    return '看缩略画布：识别对不对、放位对不对。不好就重新生成。'
  }
  const statusText = getStatusText()

  function liveBoardPreviewState() {
    return {
      problemText: problemTextRef.current,
      topicLayout: computeTopicLayout(),
      boardPlan: boardPlanRef.current,
      showGrid: showGridRef.current,
      showLabels: labelsPlannedRef.current,
      showZones: labelsPlannedRef.current,
      sourceImageUrl: sourceImageUrlRef.current,
      keepOriginal: keepOriginalRef.current,
    }
  }

  function syncLiveBoardPreview() {
    saveLiveBoardPreview(liveBoardPreviewState())
  }

  // watch([...], syncLiveBoardPreview, { deep: true, immediate: true })
  // → topicLayout 为渲染期计算值，依赖展开为真源依赖（problemText / boardPlan / showGrid /
  //   labelsPlanned / sourceImageUrl / keepOriginal / customTopicLayout / layoutSeed / isLandscape）；
  //   immediate: true = 挂载后先跑一次（useEffect 默认行为）
  useEffect(() => {
    syncLiveBoardPreview()
  }, [problemText, boardPlan, showGrid, labelsPlanned, sourceImageUrl, keepOriginal, customTopicLayout, layoutSeed, isLandscape])

  function openFullscreenBoardPreview() {
    syncLiveBoardPreview()
    window.open('/board-preview.html', 'qinghuabu-board-preview', 'noopener,noreferrer')
  }

  function onTopicLayoutUpdated(newLayout: any) {
    setCustomTopicLayout({ ...(customTopicLayoutRef.current || {}), ...newLayout })
    try {
      localStorage.setItem('qinghuabu.customTopicLayout', JSON.stringify(customTopicLayoutRef.current))
    } catch (_) {}
    syncLiveBoardPreview()
  }

  function onProblemTextUpdated(newText: string) {
    setProblemText(newText)
    // ★ Task 60：删 qinghuabu.problemText 死键写入（全仓零读者，写入即垃圾堆积）
    syncLiveBoardPreview()
  }

  function resetKnowledgeQuery() {
    setKnowledgeStatus('idle')
    setRelatedKnowledge([])
    setKnowledgeError('')
    setKnowledgeAnalysis(null)
  }

  function applySuggestion(text: string) {
    const suggestion = suggestFromText(text)
    if (suggestion.type && !problemTypeRef.current) setProblemType(suggestion.type)
    if (suggestion.focus && !boardFocusRef.current) setBoardFocus(suggestion.focus)
  }

  function onProblemTypeChange(value: any) {
    resetKnowledgeQuery()
    setProblemType(value)
    const preferred = boardFocusOptions.find(
      (item) => item.forTypes.includes(value) && item.value !== 'mixed',
    )
    if (preferred) setBoardFocus(preferred.value)
  }

  function markLayoutReady() {
    setLayoutStatus(hasBoardContent() ? 'ready' : 'idle')
  }

  async function placeOnCanvas({ fromUpload = false }: { fromUpload?: boolean } = {}) {
    const textInput = problemTextRef.current.trim()
    const imageInput = sourceImageDataUrlRef.current
    if (!imageInput && !textInput) {
      message.warning('请先上传图片或输入题目')
      return
    }

    setRecognizeStatus('loading')
    setLayoutStatus('regenerating')
    resetKnowledgeQuery()
    setStep1Confirmed(false)
    setBoardPlan(null)
    setLabelsPlanned(false)
    setShowGrid(false)

    try {
      // 真车间：本页多模态识别完，直接往甲方画布题目层放
      const result = await recognizeProblem({
        problemText: textInput,
        imageDataUrl: imageInput,
        model: userApiConfig.model,
        endpoint: userApiConfig.endpoint,
        apiKey: userApiConfig.apiKey,
      })

      // ★ 2026-10-14 回填边界修复：识别结果先过 canvasText 清洗再回填——LLM/JSON 传输损伤（rac{、&times;、字面 \n、HTML 标签）不进题目框
      if (result.problemText) {
        setProblemText(normalizeCanvasText(result.problemText).trim() || result.problemText)
      }
      setUncertainItems(result.uncertainItems || [])
      setSuggestedLayout(result.suggestedLayout || null)
      setSuggestedGrade(result.knowledgeAnalysis?.suggestedGrade || '')

      // 题型以题目内容为准：本地几何信号可纠正模型误判
      const localGuess = suggestFromText(result.problemText || problemTextRef.current)
      const nextType = result.problemType || localGuess.type
      const nextFocus = result.boardFocus || localGuess.focus
      if (nextType) setProblemType(nextType)
      if (nextFocus) setBoardFocus(nextFocus)

      // Agent A 深度知识点分析结果：识别时 LLM 已直接产出，保存备用
      if (hasUsableAgentAKnowledge(result.knowledgeAnalysis)) {
        setKnowledgeAnalysis(result.knowledgeAnalysis)
        // 同步填充 relatedKnowledge 兼容现有 UI 展示（用 coreKnowledge 数组）
        setRelatedKnowledge((result.knowledgeAnalysis.coreKnowledge || []).map((k: any) => ({
          ...(k.rawKnowledgeRecord || {}),
          编号: k.knowledgeId,
          知识点: k.knowledgePoint,
          考点: k.examinationPoint,
          策略方法: k.strategy,
          易错点: k.commonMistakes.join('；'),
          总结归纳: k.summary,
          _formula: k.formula,
        })))
        setKnowledgeStatus('success')
      }

      // 图像贴图边界：纯文字题图归文本，不贴原图；只有识别为 has_diagram 才贴原图
      const imageKind = String(result.imageKind || '').toLowerCase()
      if (imageKind === 'text_only' || imageKind === 'text') {
        setKeepOriginal(false)
      } else if (imageKind === 'has_diagram' || imageKind === 'diagram' || imageKind === 'figure') {
        setKeepOriginal(true)
      } else if (typeof result.keepOriginal === 'boolean') {
        // 模型没给 imageKind 时：有图输入也默认不贴，除非明确 keepOriginal=true 且题干像“如图”
        const textNow = result.problemText || problemTextRef.current || ''
        const diagramHint = /如图|见图|下图|右图|左图|图中|示意图|图形如下|看图/.test(textNow)
        setKeepOriginal(Boolean(result.keepOriginal) && diagramHint)
      } else {
        setKeepOriginal(false)
      }

      // 若仍缺题型/侧重，本地再补
      applySuggestion(problemTextRef.current)

      setLayoutSeed((n) => n + 1)
      setRecognizeStatus('done')
      markLayoutReady()
      const pureTextImage = Boolean(sourceImageUrlRef.current) && !keepOriginalRef.current
      message.success(
        pureTextImage
          ? '纯文字题图：已按文本处理，不贴原图'
          : fromUpload
            ? '图片已识别并贴上画布'
            : '题目已识别并贴上画布',
      )
    } catch (error: any) {
      setRecognizeStatus('error')
      setLayoutStatus('idle')
      message.error(error?.message || '识别/落位未完成')
    }
  }

  async function regenerateLayout() {
    if (!hasBoardContent()) {
      message.warning('画布上还没有题目')
      return
    }
    if (step1ConfirmedRef.current) {
      message.info('已确认。要重排先撤销')
      return
    }
    setLayoutStatus('regenerating')
    setCustomTopicLayout(null)
    try { localStorage.removeItem('qinghuabu.customTopicLayout') } catch (_) {}
    await new Promise((resolve) => setTimeout(resolve, 280))
    setLayoutSeed((n) => n + 1)
    setLayoutStatus('ready')
    message.success('已恢复自动落位并重新排列')
  }

  async function beforeUpload(file: any) {
    if (!String(file.type || '').startsWith('image/')) {
      message.error('请上传图片')
      return false
    }

    try {
      if (sourceImageUrlRef.current) URL.revokeObjectURL(sourceImageUrlRef.current)
      setSourceImageUrl(URL.createObjectURL(file))
      setSourceImageName(file.name)
      // ★ 上传前压缩（2026-10-13）：手机原图 base64 常到 4~10MB（上传慢 + 超 Vercel 4.5MB 函数体上限），压到长边≤1600px/JPEG 0.85；失败自动回退原图
      setSourceImageDataUrl(await compressImageToDataUrl(file))
      // 贴图布局定向：黑色文本内容区域长宽比判定（横向贴入 vs 左侧贴图），见函数头注释
      setIsLandscape(await detectLandscape(sourceImageDataUrlRef.current))
      setStep1Confirmed(false)
      // 上传只是入口；是否贴原图由识别判定（纯文字图=文本，不贴原图）
      setKeepOriginal(false)

      if (agentConfig.autoRecognize) await placeOnCanvas({ fromUpload: true })
      else markLayoutReady()
    } catch (error: any) {
      message.error(error?.message || '读取图片失败')
    }
    return false
  }

  function onTextInput() {
    resetKnowledgeQuery()
    setStep1Confirmed(false)
    if (problemTextRef.current.trim()) {
      applySuggestion(problemTextRef.current)
      markLayoutReady()
    } else if (!sourceImageUrlRef.current) {
      setLayoutStatus('idle')
    }
  }

  async function queryRelatedKnowledge() {
    if (!canQueryKnowledge) {
      message.warning('请先确认题目识别结果和题型')
      return
    }

    setKnowledgeStatus('loading')
    setKnowledgeError('')
    try {
      await Promise.resolve()
      setRelatedKnowledge(selectAgentARelatedKnowledge({
        problemText: problemTextRef.current,
        problemType: problemTypeRef.current,
      } as any))
      setKnowledgeStatus('success')
      message.success(
        relatedKnowledgeRef.current.length
          ? `已找到 ${relatedKnowledgeRef.current.length} 条知识关联点`
          : '本题暂无精确匹配，已记录为未匹配',
      )
    } catch (error: any) {
      setKnowledgeError(error?.message || '关联知识查询失败')
      message.error(knowledgeErrorRef.current)
    }
  }

  function onTopicMeasured(measurement: any) {
    if (!Number.isFinite(Number(measurement?.bottomPct))) return
    setTopicMeasurement({
      bottomPct: Number(measurement.bottomPct),
      heightPct: Number(measurement.heightPct || 0),
    })
  }

  /*
  async function cacheGridPreview(dataUrl) {
    if (!dataUrl || !('caches' in window)) return
    const cache = await caches.open(GRID_PREVIEW_CACHE_NAME)
    await cache.put(GRID_PREVIEW_CACHE_KEY, await fetch(dataUrl))
  }

  async function readCachedGridPreview() {
    if (!('caches' in window)) return ''
    const response = await (await caches.open(GRID_PREVIEW_CACHE_NAME)).match(GRID_PREVIEW_CACHE_KEY)
    if (!response) return ''
    const blob = await response.blob()
    return await new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '')
      reader.onerror = () => reject(reader.error)
      reader.readAsDataURL(blob)
    })
  }
  */

  async function planBoardLabels() {
    if (!hasBoardContent()) {
      message.warning('请先识别并贴上题目')
      return
    }
    // 题目锚已定：一次规划四标签 + 打开网格比例尺（复用甲方落点，按题块高度弹性下移分析区）
    setBoardPlan(planLabelsFromTopic(
      {
        topicLabel: topicLayout.topicLabel,
        question: topicLayout.question,
        image: topicLayout.image,
      },
      {
        isLandscape: isLandscapeRef.current && Boolean(sourceImageUrlRef.current) && keepOriginalRef.current,
        topicBottomPct: topicMeasurementRef.current.bottomPct,
      },
    ))
    setLabelsPlanned(true)
    setShowGrid(true)
    message.success('已在真画布上规划：分析 / 解答 / 总结，并打开网格')
    // 截图存档：画布出现网格线+四角标+刻度后，截 .board-viewport 存 public/pic/
    await captureAndSaveScreenshot()
  }

  async function captureAndSaveScreenshot() {
    setScreenshotting(true)
    try {
      // nextTick → rAF：等 React 提交本次状态更新
      await new Promise((resolve) => requestAnimationFrame(() => resolve(null)))
      // 等两帧渲染：确保状态更新 + RealBoardPreview 内部四标签定位计算完成
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)))
      // 渲染缓冲
      await new Promise((resolve) => window.setTimeout(resolve, 800))
      // 再等一帧确保所有元素渲染完成
      await new Promise((resolve) => requestAnimationFrame(resolve))
      const target = previewCaptureRef.current
      const snapdom = (window as any).snapdom
      if (!target || !snapdom?.toCanvas) {
        console.warn('截图跳过：snapdom 未加载或目标元素不存在')
        return
      }
      // snapdom toCanvas → canvas.toDataURL JPG quality 0.8，embedFonts: false 避免外部字体 fetch 跨域/阻断
      const canvas = await Promise.race([
        snapdom.toCanvas(target, { scale: 1, dpr: 1, backgroundColor: '#ffffff', embedFonts: false }),
        new Promise((_, reject) => window.setTimeout(() => reject(new Error('snapdom 截图超时')), SNAPSHOT_TIMEOUT_MS)),
      ])
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8)
      const result = await safeFetchJson('/api/screenshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: dataUrl }),
      }, 1)
      if (result.ok) {
        setScreenshotUrl(result.urlPath)
        console.log('截图已存档：', result.urlPath)
        message.success('画布截图已保存至本地')
      } else {
        console.warn('截图存档提示：', result.error)
        message.warning('截图存档提示：' + (result.error || '无法写入'))
      }
    } catch (error: any) {
      console.warn('截图异常：', error?.message || error)
      message.warning('截图提示：' + (error?.message || String(error)))
    } finally {
      setScreenshotting(false)
    }
  }

  async function confirmStep1() {
    if (!canConfirm || confirming) {
      message.warning('请先让题目正确落在画布上，并确认题型侧重')
      return
    }

    setConfirming(true)
    try {
      // handoff 实体文件存档：写 public/handoff/ + current.json 指针，B 从 GET /api/handoff 读
      // screenshotUrl 来自画布截图存档，写入 handoff 实体文件，并提供给 Agent B 作为视觉感知与排版留白依据
      if (!screenshotUrlRef.current && previewCaptureRef.current) {
        try {
          await captureAndSaveScreenshot()
        } catch { /* 容错 */ }
      }

      // 进入下一步信号：确定进入生成表 → 把参数交给板书参数书稿页 / 页面B agent
      // 注意：apiKey/endpoint/model 由全局 userApiConfig 维护，不再放进 handoff
      const payload = buildStep1Handoff({
        screenshotUrl: screenshotUrlRef.current,
        problemText: problemTextRef.current,
        problemType: problemTypeRef.current,
        boardFocus: boardFocusRef.current,
        keepOriginal: keepOriginalRef.current,
        imageKind: keepOriginalRef.current ? 'has_diagram' : 'text_only',
        hasSourceImage: Boolean(sourceImageUrlRef.current),
        sourceImageName: sourceImageNameRef.current,
        // B 图片传输冻结：原图只用于 Agent A 识图，不进入 A -> B handoff。
        topicLayout: {
          topicLabel: topicLayout.topicLabel,
          question: topicLayout.question,
          image: topicLayout.image || null,
          keepOriginal: keepOriginalRef.current,
          blocks: topicLayout.blocks || null,
        },
        boardPlan: boardPlanRef.current,
        showGrid: showGridRef.current,
        // B 图片传输冻结：快照仍由第 1 步缓存，但不进入 A -> B handoff。
        suggestedGrade: suggestedGradeRef.current,
        uncertainItems: uncertainItemsRef.current,
        suggestedLayout: suggestedLayoutRef.current,
        agentPageName: agentConfig.pageName,
        agentCapability: agentConfig.capability,
        // Agent A 深度知识点分析结果（识别时 LLM 已直接产出，传给 Agent B 作为参考素材）
        knowledgeAnalysis: knowledgeAnalysisRef.current,
        relatedKnowledge: knowledgeStatusRef.current === 'success' ? relatedKnowledgeRef.current : null,
      })

      // 写 handoff 实体文件（失败必须阻断：文件即真相源，写失败不能继续）
      const result = await safeFetchJson('/api/handoff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ handoff: payload }),
      }, 1)

      if (result.ok) {
        setStep1Confirmed(true)
        message.success('已进入板书参数书稿：题目 / 题型 / 侧重已交接')
        onEnterBoardDraft?.(payload)
      } else {
        console.error('handoff 写文件失败：', result.error)
        message.error(`题目信息保存失败：${result.error || '服务响应异常'}，请重试`)
      }
    } catch (error: any) {
      console.error('handoff 写文件异常：', error?.message || error)
      message.error(`题目信息保存失败：${error?.message || '网络异常'}，请重试或刷新页面`)
    } finally {
      setConfirming(false)
    }
  }

  function resetConfirm() {
    setStep1Confirmed(false)
  }

  function clearImage() {
    if (sourceImageUrlRef.current) URL.revokeObjectURL(sourceImageUrlRef.current)
    setSourceImageUrl('')
    setSourceImageName('')
    setSourceImageDataUrl('')
    setStep1Confirmed(false)
    setIsLandscape(false)
    markLayoutReady()
  }

  function saveAgentConfig() {
    saveUserApiConfig()
    saveAgentBApiConfig()
    saveCheckAgentApiConfig()
    localStorage.setItem(
      AGENT_STORAGE_KEY,
      JSON.stringify({
        capability: agentConfig.capability,
        autoRecognize: agentConfig.autoRecognize,
      }),
    )
    setAgentDrawerOpen(false)
    message.success('Agent A、B、C 配置已分别保存')
  }
  /* ★ Task 60：pct() 死代码已删——模板零引用（rg 实证），与 boardLayout.js pctBox 重复实现 */

  return (
    <Layout className="qh-page">
      <QhPageHeader
        stepLabel="第 1 步 · 生产车间"
        subtitle="识别 → 真画布落位"
        actions={
          <>
            <Tag color={userApiConfig.endpoint ? 'purple' : 'default'}>{agentSummary}</Tag>
            <Tooltip title="全屏画布预览">
              <Button
                type="text"
                shape="circle"
                aria-label="全屏画布预览"
                onClick={openFullscreenBoardPreview}
                icon={<FullscreenOutlined />}
              />
            </Tooltip>
            <Tooltip title="本页 Agent 配置">
              <Button
                type="text"
                shape="circle"
                aria-label="本页 Agent 配置"
                onClick={() => setAgentDrawerOpen(true)}
                icon={<SettingOutlined />}
              />
            </Tooltip>
          </>
        }
      />
      <Layout.Content className="qh-page-content">
        <Row gutter={[16, 16]}>
          <Col xs={24} lg={10}>
            <Card
              title="创建一道题"
              className="main-card qh-surface-card"
              variant="borderless"
              extra={<Button size="small" onClick={() => setTestBankOpen(true)}>测试应用题集</Button>}
            >
              {/* 测试题库弹窗：只负责复制题目，不自动填框 */}
              <Modal
                open={testBankOpen}
                onCancel={() => setTestBankOpen(false)}
                footer={null}
                width={760}
                title="测试应用题集（点击题目即可复制）"
              >
                <div style={{ maxHeight: '62vh', overflowY: 'auto' }}>
                  {TEST_PROBLEM_GROUPS.map((group) => (
                    <div key={group.group} style={{ marginBottom: 12 }}>
                      <div style={{ fontWeight: 600, margin: '4px 0 6px' }}>{group.group}</div>
                      {group.items.map((text, i) => (
                        <Button
                          key={i}
                          type="text"
                          block
                          onClick={() => handleCopyTestProblem(text, `${group.group}-${i}`)}
                          style={{
                            textAlign: 'left',
                            justifyContent: 'flex-start',
                            whiteSpace: 'normal',
                            height: 'auto',
                            padding: '6px 8px',
                            lineHeight: 1.7,
                            fontSize: 13,
                          }}
                        >
                          <span style={{ display: 'flex', width: '100%', textAlign: 'left', gap: 6 }}>
                            <span style={{ color: '#999' }}>{i + 1}.</span>
                            <span style={{ flex: 1, minWidth: 0, wordBreak: 'break-word' }}>{text}</span>
                            {copiedProblemKey === `${group.group}-${i}` && (
                              <span style={{ color: '#52c41a', whiteSpace: 'nowrap' }}>已复制</span>
                            )}
                          </span>
                        </Button>
                      ))}
                    </div>
                  ))}
                </div>
              </Modal>
              <div className="agent-a-params">
                <div className="param-head">
                  <div>
                    <div className="param-title">Agent A 识别参数</div>
                    <div className="param-subtitle">确认后作为情报交给 Agent B</div>
                  </div>
                  <Space size="small" wrap>
                    <Tag>{suggestedLayoutLabel}</Tag>
                    <Tag color={knowledgeAnalysis?.coreKnowledge?.length ? 'blue' : 'default'}>
                      知识 {knowledgeAnalysis?.coreKnowledge?.length || 0} 条
                    </Tag>
                  </Space>
                </div>

                <div className="param-field param-field-wide">
                  <div className="field-label">题目文本</div>
                  {/* v-model:value + @input：onChange 内先同步 v-model 再走 onTextInput，等价 Vue 事件顺序 */}
                  <Input.TextArea
                    value={problemText}
                    rows={6}
                    disabled={step1Confirmed}
                    placeholder="支持文本输入；也可上传图片识别后落到这里"
                    onChange={(e) => { setProblemText(e.target.value); onTextInput() }}
                  />
                </div>

                <div className="param-grid">
                  <div className="param-field">
                    <div className="field-label">题目类型</div>
                    <Select
                      value={problemType}
                      allowClear
                      placeholder="参考类型"
                      style={{ width: '100%' }}
                      disabled={step1Confirmed}
                      options={problemTypeOptions}
                      onChange={onProblemTypeChange}
                    />
                  </div>
                  <div className="param-field">
                    <div className="field-label">板书侧重</div>
                    <Select
                      value={boardFocus}
                      allowClear
                      placeholder="参考侧重"
                      style={{ width: '100%' }}
                      disabled={step1Confirmed}
                      options={boardFocusOptions.map((i) => ({ value: i.value, label: i.label }))}
                      onChange={(value) => setBoardFocus(value)}
                    />
                  </div>
                  <div className="param-field">
                    <div className="field-label">参考年级</div>
                    <Input
                      value={suggestedGrade}
                      disabled={step1Confirmed}
                      placeholder="如 5-6年级"
                      onChange={(e) => setSuggestedGrade(e.target.value)}
                    />
                  </div>
                </div>

                {uncertainItems.length ? (
                  <div className="uncertain-row">
                    <span className="uncertain-label">识别备注</span>
                    {uncertainItems.map((item: any) => (
                      <Tag key={item} color="gold" style={{ width: '100%' }}>{item}</Tag>
                    ))}
                  </div>
                ) : null}
              </div>

              {/* 可爱的手账题目操作区：成组布局，告别孤零零单行 */}
              <div className="topic-actions-dock">
                <div className="dock-buttons-group">
                  <div className="upload-actions">
                    {/* beforeUpload 恒返 false = 不自动上传，行为与 ant-design-vue 一致 */}
                    <Upload
                      disabled={step1Confirmed}
                      showUploadList={false}
                      beforeUpload={beforeUpload}
                      accept="image/*"
                    >
                      <Button className="btn-cute-action btn-upload-cute" disabled={step1Confirmed} icon={<CloudUploadOutlined />}>
                        <span>上传题目图片</span>
                      </Button>
                    </Upload>
                  </div>

                  <div className="actions">
                    <Button
                      className="btn-cute-action btn-recognize-cute"
                      type="primary"
                      loading={recognizeStatus === 'loading'}
                      disabled={step1Confirmed || (!sourceImageUrl && !problemText.trim())}
                      onClick={() => placeOnCanvas({ fromUpload: Boolean(sourceImageDataUrlRef.current) })}
                      icon={step1Confirmed ? undefined : <CheckCircleOutlined />}
                    >
                      <span>识别并贴上画布</span>
                    </Button>
                    {step1Confirmed ? (
                      <Button className="btn-cute-action btn-reset-cute" onClick={resetConfirm}>
                        撤销确认
                      </Button>
                    ) : null}
                  </div>
                </div>

                {/* 若已载入图片：拍立得手账相纸风格 */}
                {sourceImageUrl ? (
                  <div className="image-mini">
                    <div className="image-polaroid-wrap">
                      <span className="polaroid-pin">📌</span>
                      <img
                        src={sourceImageUrl}
                        alt={sourceImageName || '题目图片'}
                        className="image-mini-thumb"
                        title="点击查看题目原图"
                        onClick={() => setSourceImagePreviewOpen(true)}
                      />
                    </div>
                    <div className="image-mini-meta">
                      <div className="image-mini-title-bar">
                        <span className="cute-tag-pill">📷 题目原图</span>
                        <Typography.Text
                          content={sourceImageName}
                          ellipsis={{ tooltip: sourceImageName }}
                          className="image-name-text"
                        />
                      </div>
                      <Space size="small" className="image-switches-bar">
                        <Switch
                          checked={keepOriginal}
                          size="small"
                          disabled={step1Confirmed}
                          onChange={(checked) => setKeepOriginal(checked)}
                        />
                        <span className="switch-hint-text">原图入题（仅含图才开）</span>
                        {sourceImageUrl && !keepOriginal ? (
                          <Typography.Text type="warning" className="text-mode-tip">
                            纯文字图：归文本，不贴原图
                          </Typography.Text>
                        ) : null}
                        <Button type="link" size="small" disabled={step1Confirmed} className="btn-remove-photo" onClick={clearImage}>
                          移除图片
                        </Button>
                      </Space>
                    </div>
                  </div>
                ) : null}

                {statusText ? (
                  <div className="status-indicator">
                    <span className="status-indicator-dot"></span>
                    <span className="status-indicator-text">{statusText}</span>
                  </div>
                ) : null}
              </div>
            </Card>
          </Col>

          <Col xs={24} lg={14}>
            <Card
              className="preview-card qh-surface-card"
              variant="borderless"
              title={
                <>
                  <span>预览</span>
                  <Typography.Text type="secondary" className="preview-sub">
                    缩小的真画布 · 初始空白 · 现做现产
                  </Typography.Text>
                </>
              }
              extra={
                <Space>
                  <Button
                    size="small"
                    loading={layoutStatus === 'regenerating'}
                    disabled={!hasBoardContent() || step1Confirmed}
                    onClick={regenerateLayout}
                    icon={<ReloadOutlined />}
                  >
                    重新生成落位
                  </Button>
                  <Button size="small" disabled={!hasBoardContent()} onClick={openFullscreenBoardPreview}>
                    全屏画布
                  </Button>
                </Space>
              }
            >
              <div className="board-viewport" ref={previewCaptureRef}>
                <RealBoardPreview
                  problemText={problemText}
                  topicLayout={topicLayout}
                  boardPlan={boardPlan}
                  showAllLabels={labelsPlanned}
                  showGrid={showGrid}
                  showZoneGuides={labelsPlanned}
                  sourceImageUrl={sourceImageUrl}
                  keepOriginal={keepOriginal}
                  interactive={labelsPlanned}
                  onTopicMeasured={onTopicMeasured}
                  onUpdateTopicLayout={onTopicLayoutUpdated}
                  onLayoutChange={onTopicLayoutUpdated}
                  onUpdateProblemText={onProblemTextUpdated}
                />
                {layoutStatus === 'regenerating' ? <div className="board-mask-outer">落位中…</div> : null}
              </div>

              {hasBoardContent() ? (
                <div className="preview-tools">
                  <Space wrap align="center">
                    <Button
                      size="small"
                      type="primary"
                      ghost
                      disabled={step1Confirmed}
                      onClick={planBoardLabels}
                    >
                      {labelsPlanned ? '重新规划四标签+网格' : '规划四标签 + 网格'}
                    </Button>
                    <Button
                      size="small"
                      disabled={!labelsPlanned || step1Confirmed}
                      onClick={() => setShowGrid(!showGrid)}
                    >
                      {showGrid ? '关闭网格' : '打开网格'}
                    </Button>
                    <Button
                      size="small"
                      disabled={!hasBoardContent()}
                      onClick={openFullscreenBoardPreview}
                    >
                      全屏预览
                    </Button>
                    <Button
                      id="btn-shot-canvas"
                      size="small"
                      disabled={!hasBoardContent()}
                      loading={screenshotting}
                      onClick={captureAndSaveScreenshot}
                    >
                      截取快照
                    </Button>
                    {screenshotUrl ? (
                      <span className="screenshot-status">
                        <CheckCircleOutlined style={{ color: '#52c41a' }} />
                        <span className="screenshot-url" onClick={() => setScreenshotPreviewOpen(true)}>{screenshotUrl}</span>
                      </span>
                    ) : null}
                  </Space>
                </div>
              ) : null}

              <Typography.Paragraph type="secondary" className="thumb-tip">
                客户看这里：字识对了没有、有没有放对地方。第1步没有技巧，纯粹识别 + 落画布。
              </Typography.Paragraph>
            </Card>
          </Col>
        </Row>

        <Row gutter={[16, 16]} style={{ marginTop: 0 }}>
          <Col xs={24}>
            <Card
              className="knowledge-card qh-surface-card"
              variant="borderless"
              title={
                <div className="knowledge-card-title-bar">
                  <div className="title-left">
                    <span className="title-tape-icon">🏷️</span>
                    <span className="title-main-text">知识关联便签盒</span>
                    <span className="title-sub-text">为当前题目匹配的解题灵感与知识小纸条</span>
                  </div>
                  {relatedKnowledge.length ? (
                    <span className="title-note-count">
                      已收录 {relatedKnowledge.length} 张小纸条
                    </span>
                  ) : null}
                </div>
              }
            >
              {/* 顶部引导与查询栏：并排整合，告别各自孤零零占一行 */}
              <div className="knowledge-toolbar-pod">
                <div className="knowledge-notice-pill">
                  <span className="notice-icon">💡</span>
                  <span className="notice-text">关联建议 · 启迪思路，不作为进入下一步的门槛</span>
                </div>

                <div className="knowledge-actions">
                  <Button
                    className="btn-cute-query-knowledge"
                    loading={knowledgeStatus === 'loading'}
                    disabled={!canQueryKnowledge}
                    onClick={queryRelatedKnowledge}
                    icon={<SearchOutlined />}
                  >
                    <span>抽取知识小便签</span>
                  </Button>
                </div>
              </div>

              {/* 状态信息 */}
              {knowledgeStatus === 'error' ? (
                <Alert
                  className="knowledge-state"
                  type="error"
                  showIcon
                  title={knowledgeError}
                />
              ) : knowledgeStatus === 'success' && relatedKnowledge.length === 0 ? (
                /* 暂未匹配提示 */
                <div className="knowledge-empty-paper">
                  <span className="empty-icon">🍃</span>
                  <span className="empty-text">本题暂未匹配到特定知识标签，Agent B 仍会根据题目语义生成最温柔循序渐进的板书引导~</span>
                </div>
              ) : knowledgeStatus === 'idle' && !relatedKnowledge.length ? (
                /* 未查询时的空状态可爱便签提示 */
                <div className="knowledge-paper-invitation">
                  <div className="invitation-tape"></div>
                  <div className="invitation-content">
                    <span className="invitation-emoji">✨</span>
                    <div className="invitation-texts">
                      <div className="invitation-heading">知识小纸条待揭晓</div>
                      <div className="invitation-desc">点击右上角「抽取知识小便签」，为本题生成 3~6 张可爱的解题秘籍小纸条（可选步骤）</div>
                    </div>
                  </div>
                </div>
              ) : relatedKnowledge.length ? (
                /* 核心：可爱的手账便签小纸条墙 (Paper Notes Wall) */
                <div className="knowledge-paper-notes-wall">
                  {relatedKnowledge.map((item: any, idx: number) => (
                    <div
                      key={item['编号'] || item['知识点'] || idx}
                      className={'knowledge-paper-slip slip-theme-' + (idx % 5)}
                      onClick={() => setSelectedKnowledge(item)}
                    >
                      {/* 顶部彩色和纸胶带 */}
                      <div className={'slip-washi-tape tape-theme-' + (idx % 5)}></div>

                      {/* 纸条顶部信息 */}
                      <div className="slip-meta-row">
                        <span className="slip-pin-icon">📌</span>
                        <span className="slip-code">{item['编号'] || '#0' + (idx + 1)}</span>
                        {item['类型'] || item['系列'] || item['学段'] ? (
                          <span className="slip-category-badge">
                            {item['类型'] || item['系列'] || item['学段']}
                          </span>
                        ) : null}
                      </div>

                      {/* 核心知识点大字 */}
                      <div className="slip-title-text">
                        {item['知识点'] || '未命名知识点'}
                      </div>

                      {/* 秘籍策略简讯 */}
                      {item['策略方法'] || item['考点'] || item['讲解要点举例'] ? (
                        <div className="slip-brief-snippet">
                          <span className="snippet-prefix">💡</span>
                          <span className="snippet-content">{item['策略方法'] || item['考点'] || item['讲解要点举例']}</span>
                        </div>
                      ) : null}

                      {/* 纸条底部操作提示 */}
                      <div className="slip-bottom-bar">
                        <span className="slip-peek-hint">翻看便签秘籍</span>
                        <span className="slip-peek-icon">🔍</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}

              {/* 底部下一步推进栏：不再是单一孤零零按钮 */}
              <div className="knowledge-footer-deck">
                <div className="footer-handoff-status">
                  <span className="handoff-status-icon">🎒</span>
                  <span className="handoff-status-text">
                    {relatedKnowledge.length ? `将携带 ${relatedKnowledge.length} 张解题小纸条交给 Agent B` : '准备就绪 · 可直接进入下一步生成表'}
                  </span>
                </div>
                <Button
                  className="btn-cute-confirm-next"
                  type="primary"
                  size="large"
                  loading={confirming}
                  disabled={!canConfirm || confirming}
                  onClick={confirmStep1}
                  icon={<CheckCircleOutlined />}
                >
                  <span>确定进入生成表</span>
                </Button>
              </div>
            </Card>

            {/* 知识点手账详情弹窗 */}
            <Modal
              open={Boolean(selectedKnowledge)}
              title={null}
              width="680px"
              footer={null}
              wrapClassName="cute-paper-modal-wrap"
              onCancel={() => setSelectedKnowledge(null)}
            >
              {selectedKnowledge ? (
                <div className="notebook-modal-sheet">
                  <div className="notebook-tape"></div>
                  <div className="notebook-title-row">
                    <span className="notebook-pin">📌</span>
                    <span className="notebook-main-title">{selectedKnowledge['知识点'] || '知识点便签详情'}</span>
                    <span className="notebook-id-badge">{selectedKnowledge['编号'] || '秘籍便签'}</span>
                  </div>

                  <div className="notebook-tags-row">
                    {selectedKnowledge['学段'] ? <span className="notebook-tag">🎓 {selectedKnowledge['学段']}</span> : null}
                    {selectedKnowledge['系列'] ? <span className="notebook-tag">📚 {selectedKnowledge['系列']}</span> : null}
                    {selectedKnowledge['类型'] ? <span className="notebook-tag">🔖 {selectedKnowledge['类型']}</span> : null}
                  </div>

                  <Descriptions bordered size="small" column={1} className="knowledge-detail-table">
                    <Descriptions.Item label="经典样题">{selectedKnowledge['经典样题'] || '未提供'}</Descriptions.Item>
                    <Descriptions.Item label="考点">{selectedKnowledge['考点'] || '未提供'}</Descriptions.Item>
                    <Descriptions.Item label="策略方法">{selectedKnowledge['策略方法'] || '未提供'}</Descriptions.Item>
                    <Descriptions.Item label="讲解要点">{selectedKnowledge['讲解要点举例'] || '未提供'}</Descriptions.Item>
                    <Descriptions.Item label="易错点">{selectedKnowledge['易错点'] || '未提供'}</Descriptions.Item>
                    <Descriptions.Item label="公式">{selectedKnowledge._formula || '按本题判断'}</Descriptions.Item>
                    <Descriptions.Item label="总结归纳">{selectedKnowledge['总结归纳'] || '未提供'}</Descriptions.Item>
                  </Descriptions>
                </div>
              ) : null}
            </Modal>
          </Col>
        </Row>
      </Layout.Content>

      <Drawer
        open={agentDrawerOpen}
        title="本页 Agent 配置"
        placement="right"
        size="min(480px, 100vw)"
        onClose={() => setAgentDrawerOpen(false)}
        footer={
          <Button type="primary" block onClick={saveAgentConfig}>保存配置</Button>
        }
      >
        <Form layout="vertical" className="agent-form">
          <div className="param-title">Agent A · 题目识别</div>
          <div className="param-subtitle">自定义 OpenAI 兼容模型；接口地址必须是完整 Chat Completions URL。</div>
          <Form.Item label="能力">
            <Select
              value={agentConfig.capability}
              options={[
                { value: 'multimodal', label: '多模态（图+文）' },
                { value: 'text', label: '纯文本' },
                { value: 'vision', label: '偏视觉' },
              ]}
              onChange={(value) => setAgentConfig((prev: any) => ({ ...prev, capability: value }))}
            />
          </Form.Item>
          <Form.Item label="接口地址（仅支持 OpenAI 兼容协议 API）">
            <Input.Password
              value={userApiConfig.endpoint}
              placeholder="https://api.example.com/v1/chat/completions"
              visibilityToggle={false}
              onChange={(e) => { userApiConfig.endpoint = e.target.value }}
            />
            <Typography.Text type="secondary" style={{ fontSize: 11 }}>
              填完整请求地址，服务端不会自动拼接 /chat/completions
            </Typography.Text>
          </Form.Item>
          <Form.Item label="模型名称">
            <Input
              value={isUsingPresetApiConfig() ? '' : userApiConfig.model}
              placeholder={isUsingPresetApiConfig() ? '系统预设模型（无需填写）' : '输入支持多模态的模型名称'}
              onChange={(e) => { userApiConfig.model = e.target.value }}
            />
            <Typography.Text type="secondary" style={{ fontSize: 11 }}>
              ⚠ 不能用 gpt-5.4 等纯文本模型；要支持 image_url 输入
            </Typography.Text>
          </Form.Item>
          <Form.Item label="API Key">
            <Input.Password
              value={userApiConfig.apiKey}
              placeholder="输入 API Key（多个用逗号,或，隔开轮询）"
              autoComplete="off"
              visibilityToggle={false}
              onChange={(e) => { userApiConfig.apiKey = e.target.value }}
            />
            <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block', marginTop: 3 }}>
              {parseApiKeys(userApiConfig.apiKey).length > 1 ? (
                <span style={{ color: '#10b981', fontWeight: 600 }}>
                  ✓ 已检测到 {parseApiKeys(userApiConfig.apiKey).length} 个密钥，自动轮询并支持故障转移
                </span>
              ) : (
                <span>
                  💡 支持多个密钥（用英文小写逗号 <code>,</code> 隔开），请求时自动轮询
                </span>
              )}
            </Typography.Text>
          </Form.Item>
          <Form.Item label="选图后自动识别并贴画布">
            <Switch
              checked={agentConfig.autoRecognize}
              onChange={(checked) => setAgentConfig((prev: any) => ({ ...prev, autoRecognize: checked }))}
            />
          </Form.Item>
          <Space wrap>
            <Tag color={isUserApiReady() ? 'success' : 'default'}>
              {isUserApiReady() ? `Agent A 可调用 (${parseApiKeys(userApiConfig.apiKey).length} Key)` : '请填完整接口地址、API Key、模型名称'}
            </Tag>
          </Space>

          <Divider />
          <div className="param-title">Agent B · 添加自定义模型</div>
          <div className="param-subtitle">只接 OpenAI 兼容协议 API；接口地址必须是完整 Chat Completions URL。</div>
          <Form.Item label="模型厂商">
            <Select
              value={'custom'}
              options={[
                { value: 'custom', label: '自定义' },
              ]}
              disabled
            />
          </Form.Item>
          <Form.Item label="接口地址（仅支持 OpenAI 兼容协议 API）">
            <Input.Password
              value={agentBApiConfig.endpoint}
              placeholder="https://api.example.com/v1/chat/completions"
              visibilityToggle={false}
              onChange={(e) => { agentBApiConfig.endpoint = e.target.value }}
            />
          </Form.Item>
          <Form.Item label="API Key">
            <Input.Password
              value={agentBApiConfig.apiKey}
              placeholder="输入 API Key（多个用逗号,或，隔开轮询）"
              autoComplete="off"
              visibilityToggle={false}
              onChange={(e) => { agentBApiConfig.apiKey = e.target.value }}
            />
            <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block', marginTop: 3 }}>
              {parseApiKeys(agentBApiConfig.apiKey).length > 1 ? (
                <span style={{ color: '#10b981', fontWeight: 600 }}>
                  ✓ 已检测到 {parseApiKeys(agentBApiConfig.apiKey).length} 个密钥，自动轮询并支持故障转移
                </span>
              ) : (
                <span>
                  💡 支持多个密钥（用英文小写逗号 <code>,</code> 隔开），请求时自动轮询
                </span>
              )}
            </Typography.Text>
          </Form.Item>
          <Form.Item label="模型名称">
            <Input
              value={isUsingPresetAgentBApiConfig() ? '' : agentBApiConfig.model}
              placeholder={isUsingPresetAgentBApiConfig() ? '系统预设模型（无需填写）' : '输入模型名称'}
              onChange={(e) => { agentBApiConfig.model = e.target.value }}
            />
          </Form.Item>
          <Tag color={isAgentBApiReady() ? 'success' : 'default'}>
            {isAgentBApiReady() ? `Agent B 可调用 (${parseApiKeys(agentBApiConfig.apiKey).length} Key)` : '请填完整接口地址、API Key、模型名称'}
          </Tag>

          <Divider />
          <div className="param-title">Agent C · 内容检查</div>
          <div className="param-subtitle">自定义 OpenAI 兼容模型；接口地址必须是完整 Chat Completions URL。</div>
          <Form.Item label="接口地址（仅支持 OpenAI 兼容协议 API）">
            <Input.Password
              value={checkAgentApiConfig.endpoint}
              placeholder="https://api.example.com/v1/chat/completions"
              visibilityToggle={false}
              onChange={(e) => { checkAgentApiConfig.endpoint = e.target.value }}
            />
          </Form.Item>
          <Form.Item label="模型名称">
            <Input
              value={isUsingPresetCheckAgentApiConfig() ? '' : checkAgentApiConfig.model}
              placeholder={isUsingPresetCheckAgentApiConfig() ? '系统预设模型（无需填写）' : '输入模型名称'}
              onChange={(e) => { checkAgentApiConfig.model = e.target.value }}
            />
          </Form.Item>
          <Form.Item label="API Key">
            <Input.Password
              value={checkAgentApiConfig.apiKey}
              placeholder="输入 API Key（多个用逗号,或，隔开轮询）"
              autoComplete="off"
              visibilityToggle={false}
              onChange={(e) => { checkAgentApiConfig.apiKey = e.target.value }}
            />
            <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block', marginTop: 3 }}>
              {parseApiKeys(checkAgentApiConfig.apiKey).length > 1 ? (
                <span style={{ color: '#10b981', fontWeight: 600 }}>
                  ✓ 已检测到 {parseApiKeys(checkAgentApiConfig.apiKey).length} 个密钥，自动轮询并支持故障转移
                </span>
              ) : (
                <span>
                  💡 支持多个密钥（用英文小写逗号 <code>,</code> 隔开），请求时自动轮询
                </span>
              )}
            </Typography.Text>
          </Form.Item>
          <Tag color={isCheckAgentApiReady() ? 'success' : 'default'}>
            {isCheckAgentApiReady() ? `Check Agent 可调用 (${parseApiKeys(checkAgentApiConfig.apiKey).length} Key)` : '请填完整接口地址、API Key、模型名称'}
          </Tag>
        </Form>
      </Drawer>

      <Modal
        open={screenshotPreviewOpen}
        title="画布截图预览"
        footer={null}
        width="80%"
        destroyOnHidden
        onCancel={() => setScreenshotPreviewOpen(false)}
      >
        <img src={screenshotUrl} alt="画布截图" style={{ width: '100%', display: 'block' }} />
      </Modal>

      <Modal
        open={sourceImagePreviewOpen}
        title={sourceImageName || '题目原图预览'}
        footer={null}
        width={640}
        destroyOnHidden
        centered
        onCancel={() => setSourceImagePreviewOpen(false)}
      >
        <div style={{ textAlign: 'center', maxHeight: '70vh', overflow: 'auto', padding: '8px 0' }}>
          <img
            src={sourceImageUrl}
            alt={sourceImageName || '题目原图'}
            style={{ maxWidth: '100%', height: 'auto', borderRadius: 6, boxShadow: '0 4px 16px rgba(0, 0, 0, 0.08)' }}
          />
        </div>
      </Modal>
    </Layout>
  )
}
