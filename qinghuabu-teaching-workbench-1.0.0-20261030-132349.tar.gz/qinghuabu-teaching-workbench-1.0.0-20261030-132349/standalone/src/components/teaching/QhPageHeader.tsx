'use client'

/**
 * 1:1 移植自 /home/z/teaching-board/src/components/QhPageHeader.vue
 *
 * - a-layout-header → antd Layout.Header（渲染 ant-layout-header class，
 *   全局 style-origin.css 的 .qh-page-header.ant-layout-header 选择器继续命中）
 * - 原 SFC 无 <style> 块（.qh-page-header 系列样式在全局 style.css，属全局层，非本组件职责）
 * - <slot name="actions" /> → props.actions?: ReactNode
 * - emit('back') → props.onBack?.()
 */
import { ArrowLeftOutlined } from '@ant-design/icons'
import { Button, Layout, Space } from 'antd'
import type { ReactNode } from 'react'

export interface QhPageHeaderProps {
  stepLabel: string
  subtitle: string
  showBack?: boolean
  onBack?: () => void
  /** 原 actions 插槽 */
  actions?: ReactNode
}

export default function QhPageHeader({
  stepLabel,
  subtitle,
  showBack = false,
  onBack,
  actions,
}: QhPageHeaderProps) {
  return (
    <Layout.Header className="qh-page-header">
      <div className="qh-brand">
        {showBack && (
          <Button
            type="text"
            title="返回上一步"
            className="qh-back-btn"
            icon={<ArrowLeftOutlined />}
            onClick={() => onBack?.()}
          />
        )}
        <div className="qh-brand-mark">
          <span className="qh-brand-icon">✏️</span>
          <span>教学板书</span>
        </div>
        <span className="qh-step-badge">{stepLabel}</span>
        <span className="qh-header-subtitle">{subtitle}</span>
      </div>
      <Space size={8}>{actions}</Space>
    </Layout.Header>
  )
}
