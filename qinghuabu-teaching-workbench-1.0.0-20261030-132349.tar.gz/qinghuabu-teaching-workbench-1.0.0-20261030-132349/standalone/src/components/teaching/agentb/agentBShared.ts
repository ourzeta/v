/* @qh-core LANE=B-V2 POINT=UI_WORKBENCH five-field table primary */
// AgentBDirect.vue（Task 4-b）拆出的纯常量/纯函数模块——源 SFC setup 顶层与模块级定义，
// 与组件实例状态无关者归拢于此；逐行 1:1 保留注释与数值。
import { message } from 'antd'
import { getAgentBoardToolCatalog } from '@/board-tools/boardToolCatalog.js'
import {
  HANDWRITING_FONT_CHOICES,
  HANDWRITING_FONT_CHOICE_DEFAULT,
  resolveHandwritingFont,
} from '@/services/stepHandoff.js'

// 安全深拷贝：规避 Vue reactive proxy 循环引用与不可序列化对象抛错导致的白屏
// （React 侧无 reactive proxy 需脱壳，toRaw 以恒等 shim 保留调用点语义）
function toRawShim(val: any) {
  return val
}

export function safeDeepClone(val: any, fallback: any = {}): any {
  try {
    if (val === undefined || val === null) return fallback
    return JSON.parse(JSON.stringify(toRawShim(val)))
  } catch (err) {
    console.warn('[safeDeepClone] 数据深拷贝异常，已启用安全浅拷贝降级:', err)
    return (val && typeof val === 'object') ? { ...val } : fallback
  }
}

// 智能教研优雅思考步骤（分散等待时长，直观感知深度创作进程）
export const GENERATING_STEPS = [
  { icon: '🔍', title: '研读题意与条件', desc: '正在解析关键已知条件、未知量与四区板书空间规划...' },
  { icon: '💡', title: '搭建儿童思维支架', desc: '正在唤醒核心知识点，梳理温柔循序的提问链与易错点...' },
  { icon: '✍️', title: '规划板书内容与节拍', desc: '正在推导板书核心算式，按教学内容安排自然留白...' },
  { icon: '🎙️', title: '润色专属口播文案', desc: '正在推敲由浅入深、温润自然的口播发音节奏与标点停顿...' },
  { icon: '✨', title: '对齐讲学时序分镜', desc: '正在校验口播时序口径（有音频跟音频/无音频兑底估算）与画布动作执行轴，五字段讲义即将呈现...' },
]

/* ★ 商品化 P1（70-d 巡逻实锤 16/16 双前缀）：导出编号兜底必须与服务端 genProjectCode 同款时间戳且不带前缀
   ——旧兜底 `deliverable-<epoch>` 与下载名 `deliverable-${code}` 叠加 = 客户到手 deliverable-deliverable-1761….json */
export const genProjectCodeTs = () => {
  const d = new Date(), p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}-${String(d.getMilliseconds()).padStart(3, '0')}`
}

export const checkFieldLabels: Record<string, string> = {
  stage: '环节',
  speech: '口播稿',
  board: '板书内容',
  board_timing: '板书落笔时机',
  actionSpec: '板书动作',
  answer_error: '数学核验',
  structure: '结构精简',
}

export const toolLabels: Record<string, string> = {
  underline: '下划线',
  circle: '画圈', // 2026-10-13 第七轮：circle 接入白名单后的弹层中文标签
  // Action whitelist: underline and circle only.
}

export function formatToolFields(schema: any) {
  return Object.entries(schema).map(([name, value]) => ({
    name,
    value: typeof value === 'string' ? value : JSON.stringify(value),
  }))
}

export function formatToolExample(example: any) {
  return JSON.stringify({ action: example }, null, 2)
}

const toolCatalog = getAgentBoardToolCatalog()

export const toolReferenceRows = toolCatalog.tools.flatMap((tool: any) => {
  if (tool.actions) {
    return tool.actions.map((item: any) => ({
      key: item.action,
      tool: tool.id,
      label: toolLabels[item.action] || item.action,
      summary: item.description,
      fields: formatToolFields({ ...tool.actionSchema, action: item.action }),
      example: formatToolExample(item.example),
    }))
  }
  return [{
    key: tool.id,
    tool: tool.id,
    label: toolLabels[tool.id] || tool.id,
    summary: tool.purpose,
    fields: formatToolFields(tool.actionSchema),
    example: formatToolExample(tool.example),
  }]
})

// ★ v2.1 板书字体下拉切换器：选择随 uiSettings.handwritingFontChoice 写入交付物（数据随档走）；跨会话 localStorage 记忆
// ★ v2.4（2026-10-25 夏夏令默认换栗壳坚坚体）：旧键值一次性迁移——v2.1~v2.3 时代存进
//   localStorage 的 'qiaomu' 是「时代默认值」不是显式选择（下拉默认即写），换默认后不复活；
//   显式备选 'shaohua' 保留。迁移后打标落盘，此后键里的值一律是显式选择，照常白名单归一。
export const BOARD_FONT_CHOICE_LS_KEY = 'agent-b-font-choice'
export const BOARD_FONT_CHOICE_MIGRATED_KEY = 'agent-b-font-choice-v24-migrated'
export function readStoredFontChoice() {
  try {
    const saved = localStorage.getItem(BOARD_FONT_CHOICE_LS_KEY)
    if (saved === 'qiaomu' && !localStorage.getItem(BOARD_FONT_CHOICE_MIGRATED_KEY)) {
      const migrated = HANDWRITING_FONT_CHOICE_DEFAULT   // 旧默认时代残留 → 新默认（想用乔木下拉随时选回）
      localStorage.setItem(BOARD_FONT_CHOICE_MIGRATED_KEY, '1')
      try { localStorage.setItem(BOARD_FONT_CHOICE_LS_KEY, migrated) } catch { /* 私密模式静默 */ }
      return migrated
    }
    // 真源解析器兑底（白名单归一不再另写一套，注册表扩项时这里自动跟上）
    return resolveHandwritingFont(saved).choice
  } catch { return HANDWRITING_FONT_CHOICE_DEFAULT }
}

/* Action whitelist: underline/circle; triggerKeyword stays entry-level.
 * 数据结构 actionSpec 全链路本就存在（LLM 产出 → contract 归一 → timing/row-player 消费），
 * 此处只补 UI 写入口。铁律（同 setRowAudioUrl / updateBoardStartDelay 先例）：
 * 写真源 rows.value + applyAgentBV2Timeline 重算 + bCacheSet 同步刷（防刷新蒸发）。
 * 白名单两动作（下划线/画圈，颜色统一红）；triggerKeyword entry 级（与 action 平级）。 */
export const ACTION_TYPE_OPTIONS = toolReferenceRows.map(({ key, label }) => ({ value: key, label }))

// ponytail: 4 分支 if/else 改表驱动（shrink -5 行）
export const LAYOUT_PRESETS: Record<string, any> = {
  standard:     { speech: false, board: false, actionSpec: false },
}

export function actionLabel(entry: any) {
  const action = entry?.action
  if (!action) return '能力缺口'
  return [action.tool, action.action].filter(Boolean).join(' · ')
}

export function actionContent(entry: any) {
  if (entry?.capabilityGap) return entry.capabilityGap.need
  const action = entry?.action || {}
  return action.content || action.target?.exactText || ''
}

export function formatDisplayTime(value: any) {
  const date = value ? new Date(value) : new Date()
  return Number.isNaN(date.valueOf()) ? String(value || '') : date.toLocaleString('zh-CN', { hour12: false })
}

export function displayValue(value: any) {
  return typeof value === 'string' ? value : JSON.stringify(value)
}

export function formatRegion(region: any) {
  if (!region) return '未规划'
  const pct = (value: any) => Number(Number(value).toFixed(2))
  const size = region.w == null ? '' : `，宽 ${pct(region.w)}%${region.h == null ? '' : `，高 ${pct(region.h)}%`}`
  return `起点 (${pct(region.x)}%, ${pct(region.y)}%)${size}`
}

export function formatRefineField(value: any) {
  if (value == null) return '（无）'
  if (Array.isArray(value)) return value.map((item: any, i: number) => `${i + 1}. ${typeof item === 'string' ? item : JSON.stringify(item)}`).join('\n')
  if (typeof value === 'object') return JSON.stringify(value, null, 2)
  return String(value)
}

// 比较修缮前后字段是否有变化
export function isRefineFieldEqual(original: any, refined: any) {
  if (original == null && refined == null) return true
  if (original == null || refined == null) return false
  return JSON.stringify(original) === JSON.stringify(refined)
}

export function getAudioFilename(url: any) {
  if (!url) return 'speech-audio.mp3'
  const segs = String(url).split('/')
  return segs[segs.length - 1] || 'speech-audio.mp3'
}

export function copyAudioUrl(url: any) {
  if (!url) return
  const fullUrl = typeof window !== 'undefined' ? (window.location.origin + url) : url
  if (typeof window !== 'undefined' && window.navigator?.clipboard?.writeText) {
    window.navigator.clipboard.writeText(fullUrl).then(() => {
      message.success(`已复制下载URL: ${fullUrl}`)
    }).catch(() => {
      message.info(`下载URL: ${fullUrl}`)
    })
  } else {
    message.info(`下载URL: ${fullUrl}`)
  }
}
