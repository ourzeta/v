'use client'

// AgentBDirect.vue（Task 4-b）知识点修缮对比弹窗子模块——源模板 <a-modal v-model:open="refineResultOpen"> 整块搬出。
import { Alert, Button, Descriptions, Modal, Space, Tag, Typography } from 'antd'
import { formatRefineField, isRefineFieldEqual } from './agentBShared'

export interface RefineCompareModalProps {
  open: boolean
  refineResult: any
  /** 原模板直读的 handoff（computed → localHandoff） */
  handoff: any
  refineApplying: boolean
  /** 原 footer @click="applyRefine" */
  onApply: () => void
  /** 原 footer @click="keepOriginalRefine" */
  onKeep: () => void
  /** 原 v-model:open 关闭（X / mask） */
  onClose: () => void
}

export default function RefineCompareModal({
  open,
  refineResult,
  handoff,
  refineApplying,
  onApply,
  onKeep,
  onClose,
}: RefineCompareModalProps) {
  return (
    <Modal
      open={open}
      title="知识点修缮对比"
      footer={null}
      width="900px"
      destroyOnHidden={true}
      onCancel={onClose}
    >
      {refineResult?.refineOk === false ? (
        <Alert
          type="warning"
          title={refineResult?.warning || 'AI 这次没返回标准格式，已保留原内容，可重试'}
          showIcon
          style={{ marginBottom: 16 }}
        />
      ) : (
        <div>
          <div style={{ marginBottom: 12 }}>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              左侧为 Agent A 自动匹配结果，右侧为教研 Agent 提炼优化。对比后选择是否应用。
            </Typography.Text>
          </div>
          <Descriptions bordered size="small" column={1}>
            <Descriptions.Item label="关联知识点">
              <div className="refine-compare-row">
                <div className="refine-compare-col refine-col-original">
                  <div className="refine-compare-label">
                    机筛原文
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(handoff?.relatedKnowledge)}</pre>
                </div>
                <div className="refine-compare-col refine-col-refined">
                  <div className="refine-compare-label">
                    教研修缮
                    {/* 原 a-tag 的 size="small"：ant-design-vue Tag 本就不消费该 prop（渲染无差异），React 侧省略 */}
{!isRefineFieldEqual(handoff?.relatedKnowledge, refineResult?.handoff?.relatedKnowledge) && <Tag color="green" style={{ marginLeft: 6 }}>已优化</Tag>}
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(refineResult?.handoff?.relatedKnowledge)}</pre>
                </div>
              </div>
            </Descriptions.Item>
            <Descriptions.Item label="教学重点">
              <div className="refine-compare-row">
                <div className="refine-compare-col refine-col-original">
                  <div className="refine-compare-label">
                    机筛原文
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(handoff?.knowledgeAnalysis?.teachingFocus)}</pre>
                </div>
                <div className="refine-compare-col refine-col-refined">
                  <div className="refine-compare-label">
                    教研修缮
                    {!isRefineFieldEqual(handoff?.knowledgeAnalysis?.teachingFocus, refineResult?.handoff?.knowledgeAnalysis?.teachingFocus) && <Tag color="green" style={{ marginLeft: 6 }}>已优化</Tag>}
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.teachingFocus)}</pre>
                </div>
              </div>
            </Descriptions.Item>
            <Descriptions.Item label="关键公式">
              <div className="refine-compare-row">
                <div className="refine-compare-col refine-col-original">
                  <div className="refine-compare-label">
                    机筛原文
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(handoff?.knowledgeAnalysis?.keyFormulaList)}</pre>
                </div>
                <div className="refine-compare-col refine-col-refined">
                  <div className="refine-compare-label">
                    教研修缮
                    {!isRefineFieldEqual(handoff?.knowledgeAnalysis?.keyFormulaList, refineResult?.handoff?.knowledgeAnalysis?.keyFormulaList) && <Tag color="green" style={{ marginLeft: 6 }}>已优化</Tag>}
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.keyFormulaList)}</pre>
                </div>
              </div>
            </Descriptions.Item>
            <Descriptions.Item label="公式提示">
              <div className="refine-compare-row">
                <div className="refine-compare-col refine-col-original">
                  <div className="refine-compare-label">
                    机筛原文
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(handoff?.knowledgeAnalysis?.formulaHints)}</pre>
                </div>
                <div className="refine-compare-col refine-col-refined">
                  <div className="refine-compare-label">
                    教研修缮
                    {!isRefineFieldEqual(handoff?.knowledgeAnalysis?.formulaHints, refineResult?.handoff?.knowledgeAnalysis?.formulaHints) && <Tag color="green" style={{ marginLeft: 6 }}>已优化</Tag>}
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.formulaHints)}</pre>
                </div>
              </div>
            </Descriptions.Item>
            <Descriptions.Item label="常见错误">
              <div className="refine-compare-row">
                <div className="refine-compare-col refine-col-original">
                  <div className="refine-compare-label">
                    机筛原文
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(handoff?.knowledgeAnalysis?.commonMistakes)}</pre>
                </div>
                <div className="refine-compare-col refine-col-refined">
                  <div className="refine-compare-label">
                    教研修缮
                    {!isRefineFieldEqual(handoff?.knowledgeAnalysis?.commonMistakes, refineResult?.handoff?.knowledgeAnalysis?.commonMistakes) && <Tag color="green" style={{ marginLeft: 6 }}>已优化</Tag>}
                  </div>
                  <pre className="refine-compare-content">{formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.commonMistakes)}</pre>
                </div>
              </div>
            </Descriptions.Item>
          </Descriptions>
        </div>
      )}
      <div className="refine-modal-footer">
        <Space>
          <Button onClick={onKeep}>
            保留原文
          </Button>
          <Button type="primary" loading={refineApplying} onClick={onApply}>
            应用修缮
          </Button>
        </Space>
      </div>
    </Modal>
  )
}
