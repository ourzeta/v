'use client'

// AgentBDirect.vue（Task 4-b）Check/ASR 对比弹窗子模块——源模板 <a-modal v-model:open="checkResultOpen"> 整块搬出。
import { Button, Listy, Modal, Space, Tag, Typography } from 'antd'
import { CheckCircleOutlined, WarningOutlined } from '@ant-design/icons'
import { checkFieldLabels } from './agentBShared'

export interface CheckResultModalProps {
  open: boolean
  checkSource: string
  checkFailedFallback: boolean
  checkChanges: any[]
  /** 原 @cancel="discardCheckChanges" */
  onDiscard: () => void
  /** 原 footer 应用按钮 @click="applyCheckChanges" */
  onApply: () => void
}

export default function CheckResultModal({
  open,
  checkSource,
  checkFailedFallback,
  checkChanges,
  onDiscard,
  onApply,
}: CheckResultModalProps) {
  return (
    <Modal
      open={open}
      title={checkSource === 'math_asr' ? 'ASR 纯前端数学算式语音转换建议' : 'Check Agent 独立督导润色结果'}
      width={760}
      onCancel={onDiscard}
      footer={
        <>
          <Button onClick={onDiscard}>
            保留原文
          </Button>
          {checkChanges.length > 0 && (
            <Button type="primary" onClick={onApply}>
              应用 {checkChanges.length} 处修改
            </Button>
          )}
        </>
      }
    >
      {checkFailedFallback ? (
        <div className="qh-check-empty">
          <WarningOutlined style={{ color: '#faad14' }} />
          <div>
            <strong>Check Agent 返回格式异常，已回退原表</strong>
            <p>当前五字段执行表保持原样，未做任何修改。</p>
          </div>
        </div>
      ) : checkChanges.length === 0 ? (
        <div className="qh-check-empty">
          <CheckCircleOutlined />
          <div>
            <strong>未发现需要润色的内容</strong>
            <p>当前五字段执行表保持原样。</p>
          </div>
        </div>
      ) : (
        <Listy
          items={checkChanges.map((item: any, index: number) => ({ ...item, __key: index }))}
          rowKey={(item: any) => item.__key}
          virtual={false}
          className="qh-check-list"
          itemRender={(item: any) => (
            <div className="qh-check-change">
              <Space wrap size="small">
                <Tag color="blue">
                  第 {item.row || '?'} 行
                </Tag>
                <Tag>{checkFieldLabels[item.field] || item.field}</Tag>
                <Typography.Text type="secondary">
                  {item.reason}
                </Typography.Text>
              </Space>
              <div className="qh-check-diff">
                <div>
                  <span>原文</span>
                  <p>{item.before || '（空）'}</p>
                </div>
                <div>
                  <span>修正后</span>
                  <p>{item.after || '（空）'}</p>
                </div>
              </div>
            </div>
          )}
        />
      )}
    </Modal>
  )
}
