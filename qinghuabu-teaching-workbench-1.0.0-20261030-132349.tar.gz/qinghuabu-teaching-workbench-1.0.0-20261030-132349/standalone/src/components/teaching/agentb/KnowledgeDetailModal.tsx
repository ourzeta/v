'use client'

// AgentBDirect.vue（Task 4-b）知识点详情弹窗子模块——源模板 <a-modal :open="Boolean(selectedKnowledge)"> 整块搬出。
import { Descriptions, Modal } from 'antd'
import type { ReactNode } from 'react'

export interface KnowledgeDetailModalProps {
  selectedKnowledge: any
  /** 原 @cancel="selectedKnowledge = null" */
  onClose: () => void
}

export default function KnowledgeDetailModal({ selectedKnowledge, onClose }: KnowledgeDetailModalProps): ReactNode {
  return (
    <Modal
      open={Boolean(selectedKnowledge)}
      title={selectedKnowledge?.knowledgePoint || '知识点详情'}
      width="720px"
      footer={null}
      onCancel={onClose}
    >
      {selectedKnowledge && (
        <Descriptions bordered size="small" column={1} className="knowledge-detail-table">
          <Descriptions.Item label="编号">
            {selectedKnowledge.knowledgeId || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="学段 / 系列 / 类型">
            {[selectedKnowledge.rawKnowledgeRecord?.['学段'], selectedKnowledge.rawKnowledgeRecord?.['系列'], selectedKnowledge.rawKnowledgeRecord?.['类型']].filter(Boolean).join(' / ') || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="经典样题">
            {selectedKnowledge.rawKnowledgeRecord?.['经典样题'] || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="考点">
            {selectedKnowledge.examinationPoint || selectedKnowledge.rawKnowledgeRecord?.['考点'] || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="策略方法">
            {selectedKnowledge.strategy || selectedKnowledge.rawKnowledgeRecord?.['策略方法'] || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="讲解要点">
            {selectedKnowledge.rawKnowledgeRecord?.['讲解要点举例'] || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="易错点">
            {selectedKnowledge.commonMistakes?.join('；') || selectedKnowledge.rawKnowledgeRecord?.['易错点'] || '未提供'}
          </Descriptions.Item>
          <Descriptions.Item label="公式">
            {selectedKnowledge.formula || '按本题判断'}
          </Descriptions.Item>
          <Descriptions.Item label="总结归纳">
            {selectedKnowledge.summary || selectedKnowledge.rawKnowledgeRecord?.['总结归纳'] || '未提供'}
          </Descriptions.Item>
        </Descriptions>
      )}
    </Modal>
  )
}
