'use client'

// AgentBDirect.vue（Task 4-b）产物单页生成成功弹窗子模块——源模板 <a-modal v-model:open="deliverableModalOpen"> 整块搬出。
// 2026-10-26 商业交付标准化：新增「下载标准交付包 (ZIP)」入口（onDownloadReleasePackage），
// 顺手修正迁移期过期文案（实体存档在 var/deliverable/，经 /deliverable/ 路由访问，非 public/deliverable/）。
import { Button, Modal, Result, Space } from 'antd'
import { DownloadOutlined, EyeOutlined, FileZipOutlined } from '@ant-design/icons'
import { CANVAS_SIZE } from '@/services/stepHandoff.js'

export interface DeliverableModalProps {
  open: boolean
  deliverableResult: any
  rowsCount: number
  /** 原 @click="openDeliverablePage" */
  onOpenDeliverablePage: () => void
  /** 原 @click="downloadDeliverableJson" */
  onDownloadDeliverableJson: () => void
  /** 下载标准交付包 ZIP（播放页+音频+题目图+manifest 验收清单） */
  onDownloadReleasePackage: () => void
  /** 原 @click="deliverableModalOpen = false" */
  onClose: () => void
}

export default function DeliverableModal({
  open,
  deliverableResult,
  rowsCount,
  onOpenDeliverablePage,
  onDownloadDeliverableJson,
  onDownloadReleasePackage,
  onClose,
}: DeliverableModalProps) {
  return (
    <Modal
      open={open}
      title="🎉 教学视频素材参数产物单页已生成"
      width={620}
      footer={null}
      onCancel={onClose}
    >
      <div className="deliverable-modal-body">
        <Result
          status="success"
          title="参数已固化为最终交付单页"
          subTitle={`已归档至交付物档案（var/deliverable/）· HTML 落地实体页面与 JSON 规格成对生成`}
          extra={
            <Space size="middle" wrap>
              <Button type="primary" size="large" className="btn-modal-open-deliverable" onClick={onOpenDeliverablePage} icon={<EyeOutlined />}>
                立即打开 HTML 产物单页
              </Button>
              <Button size="large" onClick={onDownloadReleasePackage} icon={<FileZipOutlined />}>
                下载标准交付包 (ZIP)
              </Button>
              <Button size="large" onClick={onDownloadDeliverableJson} icon={<DownloadOutlined />}>
                下载配套 JSON 文件
              </Button>
              <Button size="large" onClick={onClose}>
                留在当前页面
              </Button>
            </Space>
          }
        />
        <div className="deliverable-modal-meta">
          <div className="meta-item">
            <span className="meta-label">交付项目编号:</span>
            <span className="meta-value code-font">{deliverableResult?.projectCode}</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">实体 HTML 页面:</span>
            <span className="meta-value text-emerald font-mono">deliverable-{deliverableResult?.projectCode}.html（经 /deliverable/ 路由访问）</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">配套 JSON 文件:</span>
            <span className="meta-value text-slate font-mono">deliverable-{deliverableResult?.projectCode}.json（工程规格，随 ZIP data/ 同源）</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">真画布规格:</span>
            <span className="meta-value">{CANVAS_SIZE.width} × {CANVAS_SIZE.height} (16:9 标准比例锁定)</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">已固化时序:</span>
            <span className="meta-value">{rowsCount} 步 (含五字段完整时序、纯净口播与动作规范)</span>
          </div>
        </div>
      </div>
    </Modal>
  )
}
