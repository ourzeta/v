'use client'

// AgentBDirect.vue（Task 4-b）Agent B API 配置弹窗子模块——源模板 <a-modal v-model:open="apiConfigOpen" @ok="onSaveApiConfig"> 整块搬出。
// ★ vueShim reactive 单例：本组件自带 useSyncExternalStore 订阅，表单 v-model 直接改写代理属性，
//   语义与 ant-design-vue v-model 完全一致。
import { useSyncExternalStore } from 'react'
import { Form, Input, Modal, Tag, Typography } from 'antd'
import {
  agentBApiConfig,
  isAgentBApiReady,
  isUsingPresetAgentBApiConfig,
  parseApiKeys as parseAgentBApiKeys,
} from '@/lib/agentBApiConfig.js'
import { getReactiveVersion, subscribeReactive } from '@/lib/vueShim.js'

export interface ApiConfigModalProps {
  open: boolean
  /** 原 @ok="onSaveApiConfig" */
  onSave: () => void
  /** 原 v-model:open 关闭（X / mask / Cancel） */
  onClose: () => void
}

export default function ApiConfigModal({ open, onSave, onClose }: ApiConfigModalProps) {
  useSyncExternalStore(
    (onStoreChange) => subscribeReactive(agentBApiConfig, onStoreChange),
    () => getReactiveVersion(agentBApiConfig),
    // 第三参 getServerSnapshot：SSR 水合必需（缺省 SSR 渲染会抛 Missing getServerSnapshot）
    () => getReactiveVersion(agentBApiConfig),
  )

  return (
    <Modal
      open={open}
      title="Agent B · API 服务与多密钥配置"
      width={600}
      onOk={onSave}
      onCancel={onClose}
    >
      <div style={{ marginBottom: 12 }}>
        <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 8 }}>
          在此配置生成板书五字段所调用的上游大模型 API。支持多密钥自动轮询与故障重试。
        </Typography.Paragraph>
      </div>

      <Form layout="vertical">
        <Form.Item label="接口地址（Chat Completions URL）">
          <Input.Password
            value={agentBApiConfig.endpoint}
            placeholder="https://api.example.com/v1/chat/completions"
            visibilityToggle={false}
            onChange={(e) => { agentBApiConfig.endpoint = e.target.value }}
          />
        </Form.Item>

        <Form.Item label="API Key（支持多个密钥用逗号,或，隔开）">
          <Input.Password
            value={agentBApiConfig.apiKey}
            placeholder="输入 API Key，多填用英文小写逗号,隔开"
            autoComplete="off"
            visibilityToggle={false}
            onChange={(e) => { agentBApiConfig.apiKey = e.target.value }}
          />
          <div style={{ marginTop: 6, fontSize: 12 }}>
            {parseAgentBApiKeys(agentBApiConfig.apiKey).length > 1 ? (
              <span style={{ color: '#10b981', fontWeight: 600 }}>
                ✓ 已识别到 {parseAgentBApiKeys(agentBApiConfig.apiKey).length} 个密钥：请求时自动轮询负载均衡，遇限流/失效无缝故障转移！
              </span>
            ) : (
              <span style={{ color: '#64748b' }}>
                💡 填入多个密钥（用英文小写逗号 <code>,</code> 隔开），系统发起请求时将自动轮询并处理限流重试。
              </span>
            )}
          </div>
        </Form.Item>

        <Form.Item label="模型名称（Model）">
          <Input
            value={isUsingPresetAgentBApiConfig() ? '' : agentBApiConfig.model}
            placeholder={isUsingPresetAgentBApiConfig() ? '系统预设模型（无需填写）' : '输入模型名，如 agnes-2.0-flash / gpt-4o 等'}
            onChange={(e) => { agentBApiConfig.model = e.target.value }}
          />
        </Form.Item>
      </Form>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
        <Tag color={isAgentBApiReady() ? 'success' : 'default'}>
          {isAgentBApiReady() ? `✓ 就绪 (可用 ${parseAgentBApiKeys(agentBApiConfig.apiKey).length} 个 Key)` : '请填写完整接口地址、API Key 与模型'}
        </Tag>
        <span style={{ fontSize: 11, color: '#94a3b8' }}>配置即时生效并保存至浏览器</span>
      </div>
    </Modal>
  )
}
