'use client'

// AgentBDirect.vue（Task 4-b）「可用工具说明」卡片子模块——源模板 <a-card v-if="toolsOpen" ...>
// 整块搬出（纯静态：只读共享 toolReferenceRows 与颜色常量，无组件状态绑定）。
import { Card, Col, Divider, Row, Tag, Typography } from 'antd'
import { BOARD_MARK_COLORS } from '@/board-tools/roughNotationTool.js'
import { toolReferenceRows } from './agentBShared'

export default function ToolsCard() {
  return (
    <Card
      title="可用工具说明"
      className="qh-surface-card qh-tool-card"
      size="small"
      extra={
        <Typography.Text type="secondary">
          单手串行 · 随口播触发 · 锚定已有文字
        </Typography.Text>
      }
    >
      <Row gutter={[12, 12]}>
        {toolReferenceRows.map((item: any) => (
          <Col key={item.key} span={24}>
            <Card size="small" className="qh-tool-item">
              <Row gutter={12} align="top">
                <Col span={6}>
                  <div className="qh-tool-preview">
                    {item.key === 'underline' && (
                      <svg viewBox="0 0 120 40" width="100%" height={40}>
                        <text x="10" y="18" fontSize="14" fill="#263238" fontFamily="serif">标记的文字</text>
                        <path
                          d="M8 26 Q 60 38 112 26"
                          stroke={BOARD_MARK_COLORS.red}
                          strokeWidth={2}
                          fill="none"
                          strokeLinecap="round"
                        />
                      </svg>
                    )}
                  </div>
                </Col>
                <Col span={18}>
                  <div className="qh-tool-title">
                    <Tag color="blue">{item.label}</Tag>
                    <span className="qh-tool-tool-id">{item.tool}</span>
                  </div>
                  <div className="qh-tool-summary">{item.summary}</div>
                  <div className="qh-tool-fields">
                    {item.fields.map((f: any) => (
                      <div key={f.name} className="qh-tool-field">
                        <code className="qh-field-name">{f.name}</code>
                        <span className="qh-field-value">{f.value}</span>
                      </div>
                    ))}
                  </div>
                </Col>
              </Row>
              {item.example && (
                <div className="qh-tool-example">
                  <div className="qh-tool-example-label">示例</div>
                  <pre className="qh-tool-example-code">{item.example}</pre>
                </div>
              )}
            </Card>
          </Col>
        ))}
      </Row>
      <Divider style={{ margin: '12px 0' }} />
      <Row gutter={12}>
        <Col span={12}>
          <Typography.Title level={5}>通用参数</Typography.Title>
          <div className="qh-tool-common">
            <div><b>action.order</b>：全表唯一正整数，按播放顺序递增</div>
            <div><b>标记颜色</b>：动作 1.0 颜色统一红（下划线/画圈）</div>
          </div>
        </Col>
        <Col span={12}>
          <Typography.Title level={5}>可用区域</Typography.Title>
          <div className="qh-tool-common">
            <div>
              <Tag>question 题目区</Tag> <Tag color="orange">analysis 分析区</Tag>
            </div>
            <div>
              <Tag color="green">solution 解答区</Tag> <Tag color="purple">summary 总结区</Tag>
            </div>
            <div style={{ marginTop: 6, color: '#8c8c8c', fontSize: 12 }}>
              文字标记只能标记已有的文字
            </div>
          </div>
        </Col>
      </Row>
    </Card>
  )
}
