'use client'

/* 教学板书 · 视频素材参数产物单页 / 全屏画布
 * 功能：
 *   1. 锁定 1726 × 980 画布比例，防止任何全屏或缩放畸变
 *   2. 呈现专业级参数框（题目信息、真画布四区落点坐标、讲题五字段时序表、下游流水线 JSON）
 *   3. 与服务端 /api/deliverable 深度接力，持久化文件存档，刷新永久不丢失
 *   4. 支持一键导出 JSON / 口播稿 / 分镜讲义，支持纯沉浸全屏模式切换
 *
 * BoardPreviewApp.vue → React 1:1 移植（Task 4-c）
 * 原文件：/home/z/teaching-board/src/board-preview/BoardPreviewApp.vue（2086 行）
 * Vue→React 对应关系：ref→useState+ref 镜像（useSyncedRef，异步流程内"先写后读"语义与
 * Vue ref.value 一致）、computed→渲染期直算/useMemo、watch→useEffect、
 * onMounted/onBeforeUnmount→useEffect([]) 挂载/清理、defineAsyncComponent→直接 import
 * （Next 按路由自动分包）、<transition name="fade">→FadeTransition（等价 enter/leave 类名切换）。
 * 原 setup 期同步读 URLSearchParams/localStorage 的部分统一推迟到挂载 effect（SSR 安全，
 * 防 hydration mismatch）。
 */
import { cloneElement, useEffect, useMemo, useRef, useState, type ReactElement } from 'react'
import { Alert, Button, message, Modal, Select, Tag } from 'antd'
import {
  CheckCircleOutlined,
  CopyOutlined,
  DownloadOutlined,
  FullscreenOutlined,
  FullscreenExitOutlined,
  FileDoneOutlined,
  CompassOutlined,
  TableOutlined,
  CodeOutlined,
  RollbackOutlined,
  InfoCircleOutlined,
  ClockCircleOutlined,
  FileTextOutlined,
  FundProjectionScreenOutlined,
  PictureOutlined,
  ShareAltOutlined,
  CloseCircleOutlined,
  SoundOutlined,
  FileSearchOutlined,
  ReloadOutlined,
  ArrowRightOutlined,
} from '@ant-design/icons'
import {
  CANVAS_W as DESIGN_W,
  CANVAS_H as DESIGN_H,
} from '@/utils/canvasCoords.js'
import { BOARD_LAYOUT } from '@/utils/boardLayout.js'
import { renderProblemHtml } from '@/utils/mathText.js'
// ★ Task 10: 引入甲方原始要求常量（板书 38px / 平方乔木体 / 题目 30px）
import {
  QUESTION_FONT_SIZE,
  BOARD_FONT_SIZE,
  HANDWRITING_FAMILY,
  CANVAS_SIZE,
  HANDWRITING_FONT_CHOICES,
  HANDWRITING_FONT_CHOICE_DEFAULT,
  buildCanvasParams,
} from '@/services/stepHandoff.js'
import {
  exportSpeechMarkdown as doExportSpeechMarkdown,
  exportElementsMarkdown as doExportElementsMarkdown,
} from '@/lib/speechMarkdown.js'
// ★ Task 40：#017 归一共享真源（流水线 JSON 出口接线，与 AgentBDirect/服务端双出口同一实现）
import { normalizeDeliverableAssetPaths } from '@/lib/deliverableAssetPaths.js'
import {
  isLiveBoardPreviewUpdate,
  loadLiveBoardPreview,
  saveLiveBoardPreview,
  saveLayoutRevision,
} from '@/board-preview/liveBoardPreview.js'
import RealBoardPreview from './RealBoardPreview'
import './BoardPreviewApp.css'

/** Vue ref → React 等价桥：state 管渲染，ref 镜像同步可读（同一异步流程内先 set 后读，读到的永远是新值，等价 Vue ref.value） */
function useSyncedRef<T>(initial: T) {
  const [state, setState] = useState<T>(initial)
  const ref = useRef<T>(initial)
  const set = (next: T | ((prev: T) => T)) => {
    const resolved = typeof next === 'function' ? (next as (prev: T) => T)(ref.current) : next
    ref.current = resolved
    setState(resolved)
  }
  return [state, set, ref] as const
}

/**
 * Vue <transition name="fade"> 等价实现（0.2s 透明度过渡）。
 * 类名与 scoped CSS 中 .fade-enter-from/.fade-enter-active/.fade-leave-active/.fade-leave-to
 * 完全一致：enter 先挂 fade-enter-from+fade-enter-active、下一帧去 fade-enter-from 触发过渡、
 * 220ms 后清理；leave 挂 fade-leave-active+fade-leave-to、200ms 后卸载。
 * 子元素必须为单个真实元素（对应 Vue v-if 单根内容）。
 */
function FadeTransition({ visible, children }: { visible: boolean; children: ReactElement }) {
  const [shouldRender, setShouldRender] = useState(visible)
  const [transitionClass, setTransitionClass] = useState('')
  const [prevVisible, setPrevVisible] = useState(visible)

  // visible prop 变化时在渲染期调整 state（React 官方替代 effect 内同步 setState 的模式）：
  // enter 先挂 fade-enter-from+fade-enter-active；leave 挂 fade-leave-active+fade-leave-to。
  if (prevVisible !== visible) {
    setPrevVisible(visible)
    if (visible) {
      setShouldRender(true)
      setTransitionClass('fade-enter-from fade-enter-active')
    } else if (shouldRender) {
      setTransitionClass('fade-leave-active fade-leave-to')
    }
  }

  useEffect(() => {
    let raf1 = 0
    let raf2 = 0
    let timer: ReturnType<typeof setTimeout> | null = null
    if (transitionClass.includes('fade-enter-from')) {
      // enter：下一帧去掉 fade-enter-from 触发 0.2s 过渡，220ms 后清理类名
      raf1 = requestAnimationFrame(() => {
        raf2 = requestAnimationFrame(() => {
          setTransitionClass('fade-enter-active')
        })
      })
      timer = setTimeout(() => setTransitionClass(''), 220)
    } else if (transitionClass.includes('fade-leave-active')) {
      // leave：200ms 过渡结束后卸载（等价 Vue 等待 transitionend）
      timer = setTimeout(() => {
        setShouldRender(false)
        setTransitionClass('')
      }, 200)
    }
    return () => {
      cancelAnimationFrame(raf1)
      cancelAnimationFrame(raf2)
      if (timer) clearTimeout(timer)
    }
  }, [transitionClass])

  if (!shouldRender) return null
  return cloneElement(children as ReactElement<Record<string, unknown>>, {
    className: `${((children as ReactElement<Record<string, unknown>>).props.className as string) || ''} ${transitionClass}`.trim(),
  })
}

export default function BoardPreviewApp() {
  // const params = new URLSearchParams(window.location.search)
  // 原 setup 期同步读取 URL 参数（viewMode/showGrid/showLabels/showZones/projectCode 初始值）
  // → 挂载 effect 内读取（SSR 安全，防 hydration mismatch），fetchDeliverableData 内按需现读。
  // 模式：'deliverable' (带参数信息单页) 或 'fullscreen' (纯画布沉浸) 或 'canvas' (纯画布背景嵌入模式)
  const [viewMode, setViewMode, viewModeRef] = useSyncedRef<string>('deliverable')
  const [loading, setLoading] = useState(false)

  // 核心产物数据状态
  const [projectCode, setProjectCode, projectCodeRef] = useSyncedRef<string>('')
  const [createdAt, setCreatedAt, createdAtRef] = useSyncedRef<string>('')
  const [filename, setFilename, filenameRef] = useSyncedRef<string>('')
  const [problemText, setProblemText, problemTextRef] = useSyncedRef<string>('')
  const [topicLayout, setTopicLayout, topicLayoutRef] = useSyncedRef<any>(null)
  const [boardPlan, setBoardPlan, boardPlanRef] = useSyncedRef<any>(null)
  const [sourceImageUrl, setSourceImageUrl, sourceImageUrlRef] = useSyncedRef<string>('')
  const [keepOriginal, setKeepOriginal, keepOriginalRef] = useSyncedRef<boolean>(false)
  const [screenshotUrl, setScreenshotUrl, screenshotUrlRef] = useSyncedRef<string>('')
  const [meta, setMeta, metaRef] = useSyncedRef<any>({
    problemType: '小学数学题',
    boardFocus: '图文结合',
    gradeLevel: '小学阶段',
    knowledgeTitle: '核心知识点',
    canvasSize: { width: DESIGN_W, height: DESIGN_H },
  })
  const [stats, setStats, statsRef] = useSyncedRef<any>({
    totalDuration: 0,
    totalDurationText: '0秒',
    stepCount: 0,
    charCount: 0,
    actionCount: 0,
  })
  const [checkInfo, setCheckInfo, checkInfoRef] = useSyncedRef<any>({
    checkApplied: false,
    changeCount: 0,
    asrPolished: false,
  })
  const [rows, setRows, rowsRef] = useSyncedRef<any[]>([])
  // ★ Task 46 归一（死代码复活）：order 注入进 entry.action.order——下游 RealBoardPreview
  //   normalizeActionSpecItem 解包 {...item.action} 只认 action 内字段，旧的 entry 级注入
  //   （rowIndex*1000+actionIndex）解包即丢=死代码。现在注进 action 内：跨行用 rowIndex*1000
  //   块 + 行内尊重已填 order（缺省 actionIndex+1 保正整数），预览单手队列才真正有序；
  //   entry.action 非对象（capabilityGap/裸格式）跳过注入。
  const actionSpec = useMemo<any[]>(() => rows.flatMap((row: any, rowIndex: number) => (
    Array.isArray(row?.actionSpec)
      ? row.actionSpec.map((action: any, actionIndex: number) => {
        if (action && typeof action.action === 'object') {
          // 行内 order 必须为正整数（缺省 1 起，与 validate 的 ?? 1 同口径），否则
          // 下游 validateRoughNotation/DrawingAction 会拒收 order<1
          const innerOrder = Number.isFinite(action.action.order) && action.action.order >= 1
            ? action.action.order
            : actionIndex + 1
          return { ...action, action: { ...action.action, order: rowIndex * 1000 + innerOrder } }
        }
        return action
      })
      : []
  )), [rows])

  // 界面控制
  const [showGrid, setShowGrid, showGridRef] = useSyncedRef<boolean>(false) // params.get('showGrid') === '1'
  const [showLabels, setShowLabels, showLabelsRef] = useSyncedRef<boolean>(true) // params.get('showLabels') !== '0'
  const [showZones, setShowZones, showZonesRef] = useSyncedRef<boolean>(true) // params.get('showZones') !== '0'
  const [activeTab, setActiveTab] = useState('rows')
  const [selectedStageFilter, setSelectedStageFilter] = useState('all')

  // 全屏浮动工具栏
  const [showFloatToolbar, setShowFloatToolbar] = useState(true)
  const toolbarTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ★ Task 58 布局修订闭环：布局编辑模式——编辑态退截图底图、复活活排版（可拖四区框/标签/题目块），
  // 保存修订后回工作台重新生成按新布局出片（夏夏拍板：布局调整前移生成环，播放页调=生米煮熟）
  const [layoutEditMode, setLayoutEditMode] = useState(false)

  function saveLayoutRevisionAction() {
    if (!boardPlanRef.current) {
      message.warning('当前档没有 boardPlan，无法保存布局修订')
      return
    }
    try {
      saveLayoutRevision({
        problemText: problemTextRef.current || '',
        projectCode: projectCodeRef.current || '',
        boardPlan: boardPlanRef.current,
        savedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
      })
      message.success('布局修订已保存：回工作台点【重新生成】即可按新四区坐标生成五字段（自动跳过缓存）', 6)
    } catch (err: any) {
      message.error(`布局修订保存失败：${err?.message || err}`)
    }
  }

  function pingFloatToolbar() {
    setShowFloatToolbar(true)
    clearTimeout(toolbarTimerRef.current as ReturnType<typeof setTimeout>)
    toolbarTimerRef.current = setTimeout(() => {
      setShowFloatToolbar(false)
    }, 2500)
  }

  function onTopicLayoutUpdated(newLayout: any) {
    setTopicLayout({ ...(topicLayoutRef.current || {}), ...newLayout })
    // ★ Task 58-b 实测防死路：冷开预览页（交付存储空、boardPlan 尚未装载）时拖区框/标签，
    // 原实现 if(boardPlan.value) 静默跳过合并 → 拖了白拖无提示。此处按默认布局播种一份
    // boardPlan（BOARD_LAYOUT 即 planKeys 九键缺省真源），保证修订链永远有真相源可写。
    if (!boardPlanRef.current) {
      setBoardPlan({ ...BOARD_LAYOUT })
    }
    // ★ Task 58 布局修订闭环：拖拽后的区框/标签/题目区坐标同步进 boardPlan
    // （zone 拖拽 key = analysis/solution/summary；标签 = xxxLabel；题目区 = question）——
    // boardPlan 是重新生成的真相源，保存布局修订时随 projectCode 落盘。
    if (boardPlanRef.current) {
      const planKeys = ['topicLabel', 'question', 'analysisLabel', 'analysis', 'solutionLabel', 'solution', 'summaryLabel', 'summary', 'image']
      const merged = { ...boardPlanRef.current }
      for (const k of planKeys) {
        if (newLayout && newLayout[k] != null) merged[k] = { ...(merged[k] || {}), ...newLayout[k] }
      }
      setBoardPlan(merged)
    }
    try {
      saveLiveBoardPreview({
        problemText: problemTextRef.current,
        topicLayout: topicLayoutRef.current,
        boardPlan: boardPlanRef.current,
        showGrid: showGridRef.current,
        showLabels: showLabelsRef.current,
        showZones: showZonesRef.current,
        sourceImageUrl: sourceImageUrlRef.current,
        keepOriginal: keepOriginalRef.current,
      })
    } catch (_) {}
  }

  function onProblemTextUpdated(newText: string) {
    setProblemText(newText)
    try {
      saveLiveBoardPreview({
        problemText: problemTextRef.current,
        topicLayout: topicLayoutRef.current,
        boardPlan: boardPlanRef.current,
        showGrid: showGridRef.current,
        showLabels: showLabelsRef.current,
        showZones: showZonesRef.current,
        sourceImageUrl: sourceImageUrlRef.current,
        keepOriginal: keepOriginalRef.current,
      })
    } catch (_) {}
  }

  function applyDeliverablePayload(payload: any, code: string | null = null, created: string | null = null) {
    if (!payload) return
    if (code) setProjectCode(code)
    else if (payload.projectCode) setProjectCode(payload.projectCode)

    if (created) setCreatedAt(created)
    else if (payload.createdAt) setCreatedAt(payload.createdAt)

    if (payload.filename) setFilename(payload.filename)
    if (payload.problemText != null) setProblemText(payload.problemText)
    if (payload.topicLayout) setTopicLayout(payload.topicLayout)
    if (payload.boardPlan) setBoardPlan(payload.boardPlan)
    if (payload.sourceImageUrl != null) setSourceImageUrl(payload.sourceImageUrl)
    if (payload.keepOriginal != null) setKeepOriginal(Boolean(payload.keepOriginal))
    if (payload.screenshotUrl != null) setScreenshotUrl(payload.screenshotUrl)

    if (payload.meta) {
      setMeta({ ...metaRef.current, ...payload.meta })
    }
    // ★ Task 9 修复: 兜底从 payload 顶层读 canvasParams (有些上游 saveLiveBoardPreview 直接写在顶层)
    //  优先级: payload.meta.canvasParams > payload.canvasParams > payload.handoffCanvasParams
    //  这样无论上游怎么放, BoardPreviewApp 都能拿到 canvasParams 给 RealBoardPreview
    if (payload.canvasParams && !metaRef.current.canvasParams) {
      setMeta({ ...metaRef.current, canvasParams: payload.canvasParams })
    }
    if (payload.handoffCanvasParams && !metaRef.current.canvasParams) {
      setMeta({ ...metaRef.current, canvasParams: payload.handoffCanvasParams })
    }
    if (payload.stats) {
      setStats({ ...statsRef.current, ...payload.stats })
    }
    if (payload.checkInfo) {
      setCheckInfo({ ...checkInfoRef.current, ...payload.checkInfo })
    }
    if (Array.isArray(payload.rows)) {
      setRows(payload.rows)
    }
  }

  // 从服务端或本地读取数据（带持久化保证，刷新不丢失）
  async function fetchDeliverableData() {
    setLoading(true)
    const params = new URLSearchParams(window.location.search)
    const queryId = params.get('id') || params.get('file')
    const apiUrl = queryId ? `/api/deliverable?id=${encodeURIComponent(queryId)}` : '/api/deliverable'

    try {
      const res = await fetch(apiUrl)
      if (res.ok) {
        const data = await res.json()
        const payload = data.deliverable || data
        // ★ Task 58-b 空壳防短路：交付存储为空时接口仍回 ok:true + deliverable:{}——
        // 空对象在此前的 data.deliverable || data.rows 判真中会提前 return，
        // 把 localStorage 回退永久短路（冷开预览页白板）。只有 payload 带真内容
        // （题目/布局/rows 任一）才采纳，否则落穿到本地回退。
        const hasContent = !!(payload.problemText || payload.boardPlan || (payload.rows && payload.rows.length))
        if (data.ok && hasContent) {
          applyDeliverablePayload(payload, data.projectCode, data.createdAt)
          setLoading(false)
          return
        }
      }
    } catch (err) {
      console.warn('获取 /api/deliverable 失败，转为本地回退:', err)
    }

    // 服务端若暂无，则尝试回退 localStorage
    const local = loadLiveBoardPreview()
    if (local) {
      applyDeliverablePayload(local)
    }

    // URL fallback
    const urlProblemText = params.get('problemText')
    if (urlProblemText) {
      setProblemText(urlProblemText)
    }
    const urlSourceImage = params.get('sourceImage')
    if (urlSourceImage) {
      setSourceImageUrl(urlSourceImage)
    }

    setLoading(false)
  }

  // ★ 板书字体下拉切换器（2026-10-25 需求）：此前预览页只能看档内固定字体，无切换 UI。
  //   AgentBDirect v2.1 同源口径：选择值唯一键 uiSettings.handwritingFontChoice（数据随档走），
  //   字体域整体按 buildCanvasParams(choice) 重建（fontSource 与 fontSize 三区文案一并双态，
  //   半边覆写会让描述标签仍写旧字体），切换即写回交付档（POST /api/deliverable/update-font，
  //   镜像 update-sync 落盘口径）；写档失败不回滚本地预览。
  const boardFontOptions = HANDWRITING_FONT_CHOICES.map((o: any) => ({ value: o.id, label: o.label }))
  // 下拉显值 = 用户本页选择 > 档内选择 > 默认（派生式：新档载入自动跟随，无 effect 同步态）
  const [fontOverride, setFontOverride] = useState<string | null>(null)
  const effectiveFontChoice =
    fontOverride
    || meta?.uiSettings?.handwritingFontChoice
    || meta?.canvasParams?.fontSource?.handwriting?.choice
    || HANDWRITING_FONT_CHOICE_DEFAULT

  function applyBoardFontChoice(choice: string) {
    const fontDomain: any = buildCanvasParams(choice)
    const resolvedChoice = fontDomain.fontSource?.handwriting?.choice || choice
    const family = fontDomain.fontSource?.handwriting?.family || ''
    setFontOverride(resolvedChoice)
    const cur = metaRef.current
    if (!cur) return // 嵌入/空档态：仅本地预览生效（无档可写）
    const nextMeta = {
      ...cur,
      canvasParams: { ...cur.canvasParams, ...fontDomain },
      uiSettings: { ...cur.uiSettings, handwritingFontChoice: resolvedChoice, handwritingFont: family },
    }
    setMeta(nextMeta)
    // 数据随档走：写回交付档案
    fetch('/api/deliverable/update-font', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        projectCode: cur.projectCode,
        canvasParams: fontDomain,
        uiSettings: { handwritingFontChoice: resolvedChoice, handwritingFont: family },
      }),
    })
      .then((r) => r.json())
      .then((d: any) => {
        if (d?.ok) {
          message.success('✍ 板书字体已切换并写入交付档（播放页 / 导出 / 后续固化同步生效）')
        } else {
          message.warning('字体已切换（仅本页预览），写入交付档失败：' + (d?.error || '未知错误'))
        }
      })
      .catch(() => message.warning('字体已切换（仅本页预览），写入交付档失败（网络异常）'))
  }

  function onStorage(event: StorageEvent) {
    if (isLiveBoardPreviewUpdate(event)) {
      applyDeliverablePayload(loadLiveBoardPreview())
    }
  }

  function onKeyDown(e: KeyboardEvent) {
    if (e.key === 'Escape' && viewModeRef.current === 'fullscreen') {
      setViewMode('deliverable')
    }
  }

  function handleWindowMessage(event: MessageEvent) {
    const data = event.data
    if (!data || typeof data !== 'object') return
    if (data.type === 'SET_DELIVERABLE' || data.type === 'set-deliverable') {
      applyDeliverablePayload(data.payload || data.deliverable)
    } else if (data.type === 'TOGGLE_GRID') {
      setShowGrid(Boolean(data.value))
    } else if (data.type === 'TOGGLE_LABELS') {
      setShowLabels(Boolean(data.value))
    } else if (data.type === 'TOGGLE_ZONES') {
      setShowZones(Boolean(data.value))
    }
  }

  // onMounted：URL 参数初始值回放 + 拉取交付数据 + 跨窗同步监听 + 就绪广播
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const initialMode = params.get('mode')
    setViewMode(
      initialMode === 'canvas' || initialMode === 'embed' || initialMode === 'bg'
        ? 'canvas'
        : initialMode === 'fullscreen'
        ? 'fullscreen'
        : 'deliverable'
    )
    setShowGrid(params.get('showGrid') === '1')
    setShowLabels(params.get('showLabels') !== '0')
    setShowZones(params.get('showZones') !== '0')
    setProjectCode(params.get('id') || '')

    fetchDeliverableData()
    pingFloatToolbar()
    window.addEventListener('storage', onStorage)
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('message', handleWindowMessage)
    try {
      window.parent?.postMessage({ type: 'BOARD_PREVIEW_CANVAS_READY' }, '*')
    } catch {}

    // onBeforeUnmount
    return () => {
      clearTimeout(toolbarTimerRef.current as ReturnType<typeof setTimeout>)
      window.removeEventListener('storage', onStorage)
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('message', handleWindowMessage)
    }
  }, [])

  // 计算属性
  const renderedProblemHtml = renderProblemHtml(problemText || '暂无题目内容')

  // 舞台长宽比
  const canvasAspectRatio = `${DESIGN_W} / ${DESIGN_H}`

  // 过滤后的五字段行
  const filteredRows = selectedStageFilter === 'all' ? rows : rows.filter((r: any) => r.stage === selectedStageFilter)

  // 所有出现的教学阶段
  const stageOptions = ['all', ...Array.from(new Set(rows.map((r: any) => r.stage).filter(Boolean)))]

  // ★ v2.1：分区描述的手写字体名随交付档选择派生（meta.canvasParams.fontSource.handwriting），
  //   旧档/未传兑底默认乔木——文案与实际渲染字体（RealBoardPreview 同源）不再各说各话
  const handFontFamily = (() => {
    const fam = meta?.canvasParams?.fontSource?.handwriting?.family
    return (typeof fam === 'string' && fam) ? fam : HANDWRITING_FAMILY
  })()

  // 四区绝对坐标与百分比对照
  const fourZonesCoords = (() => {
    const plan = boardPlan || {}
    const layout = topicLayout || {}

    const q = plan.question || layout.question || BOARD_LAYOUT.question
    const an = plan.analysis || BOARD_LAYOUT.analysis
    const so = plan.solution || BOARD_LAYOUT.solution
    const sm = plan.summary || BOARD_LAYOUT.summary

    function toPx(pctObj: any) {
      const x = Number(pctObj.x || 0)
      const y = Number(pctObj.y || 0)
      const w = Number(pctObj.w || 0)
      const h = Number(pctObj.h || 0)
      return {
        xPct: x.toFixed(1) + '%',
        yPct: y.toFixed(1) + '%',
        wPct: w.toFixed(1) + '%',
        hPct: h ? h.toFixed(1) + '%' : '自适应',
        xPx: Math.round((x * DESIGN_W) / 100) + 'px',
        yPx: Math.round((y * DESIGN_H) / 100) + 'px',
        wPx: Math.round((w * DESIGN_W) / 100) + 'px',
        hPx: h ? Math.round((h * DESIGN_H) / 100) + 'px' : '高度自适应',
      }
    }

    return [
      { key: 'topic', name: '题目区 (Topic/Question)', tag: '题', label: '题目', ...toPx(q), desc: `承载题目文本与原图锦定（${QUESTION_FONT_SIZE}px 微软雅黑，印刷体）` },
      { key: 'analysis', name: '分析区 (Analysis)', tag: '析', label: '分析', ...toPx(an), desc: `引导审题思路与关系拆解（约 ${BOARD_FONT_SIZE}px 手写体 ${handFontFamily}）` },
      { key: 'solution', name: '解答区 (Solution)', tag: '解', label: '解答', ...toPx(so), desc: `核心规范算式与步骤推导（约 ${BOARD_FONT_SIZE}px 手写体 ${handFontFamily}）` },
      { key: 'summary', name: '总结区 (Summary)', tag: '总', label: '总结', ...toPx(sm), desc: `作答闭环与方法结论沉淀（约 ${BOARD_FONT_SIZE}px 手写体 ${handFontFamily}）` },
    ]
  })()

  // 板书显示安全格式化（防止 [object Object]）
  function formatBoardDisplay(board: any) {
    if (!board) return '(本步无新增板书)'
    if (typeof board === 'string') return board
    if (typeof board === 'object') return board.content || '(本步无新增板书)'
    return String(board)
  }

  // ★ Task 46：动作 pill 标签——契约包裹格式下 act.action 是对象（旧写法 act.tool || act.action
  //   会把整个对象渲染成 JSON）。解包优先级：包裹 → action.action（underline/circle）||
  // action.tool is optional; unwrap package or use flat action/tool.
  //   等）→ 'action' 兜底。
  function formatActionPillLabel(act: any) {
    if (act?.action && typeof act.action === 'object') {
      return act.action.action || act.action.tool || 'action'
    }
    return act?.action || act?.tool || 'action'
  }

  // 格式化的下游视频流水线 JSON
  const pipelineJsonString = useMemo(() => {
    const data: any = {
      deliverableId: projectCode || 'DELIV-' + Date.now(),
      generatedAt: createdAt || new Date().toISOString(),
      canvasSpec: {
        standard: '16:9 课件演播室',
        width: DESIGN_W,
        height: DESIGN_H,
        unit: 'px',
      },
      topicSpec: {
        problemText: problemText,
        keepOriginal: keepOriginal,
        sourceImageUrl: sourceImageUrl || null,
        screenshotUrl: screenshotUrl || null,
        topicLayout: topicLayout,
        boardPlan: boardPlan,
      },
      meta: meta,
      stats: stats,
      checkInfo: checkInfo,
      sequence: rows.map((row: any, idx: number) => ({
        step: idx + 1,
        stage: row.stage,
        // 有音频用真实时长；无音频明确标记为预估，并保留音频槽位。
        duration: row.audioDurationMs ?? row.duration ?? 0,
        durationLabel: row.audioDurationMs ? '真实音频时长' : '预估',
        audioUrl: row.audioUrl || '音频暂未生成',
        audioDurationMs: row.audioDurationMs ?? null,
        speech: row.speech,
        board: row.board,
        actionSpec: row.actionSpec,
      })),
    }
    // ★ Task 40-A：流水线 JSON 出口同走 #017 共享归一（sequence 行 mp3/audioUrl +
    //   topicSpec.screenshotUrl 题目图）——data/sequence/topicSpec 均为本次 computed 新建的
    //   对象图，原地归一无副作用；file:// 消费不再拿到站点根绝对路径（/audio-cache/ → ../audio-cache/）
    normalizeDeliverableAssetPaths(data)
    return JSON.stringify(data, null, 2)
  }, [projectCode, createdAt, problemText, keepOriginal, sourceImageUrl, screenshotUrl, topicLayout, boardPlan, meta, stats, checkInfo, rows])

  // 动作方法
  function downloadPipelineJson() {
    message.info('推荐生成全部的语音后点击导出。当前仍可继续导出。')
    const blob = new Blob([pipelineJsonString], { type: 'application/json;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `pipeline-${projectCode || 'deliverable'}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    message.success('已成功从状态树下载流水线规格 JSON')
  }

  function copyPipelineJson() {
    navigator.clipboard.writeText(pipelineJsonString).then(() => {
      message.success('已成功复制完整流水线参数 JSON 到剪贴板')
    }).catch(() => {
      message.error('复制失败，请手动在下方框中全选复制')
    })
  }

  function copyPageUrl() {
    navigator.clipboard.writeText(window.location.href).then(() => {
      message.success('已复制单页永久链接')
    })
  }

  function exportSpeechMarkdown() {
    doExportSpeechMarkdown(rowsRef.current, {
      problemText: problemTextRef.current,
    })
    message.success('已导出口播讲义 MD (纯口播/TTS就绪/无控制标签)')
  }

  function exportElementsMarkdown() {
    doExportElementsMarkdown(rowsRef.current, {
      title: '讲题五字段要素全量表',
      problemText: problemTextRef.current,
      model: metaRef.current?.model,
      generatedAt: createdAtRef.current,
      handoffCanvasParams: metaRef.current?.canvasParams,
      handoffBoardPlan: boardPlanRef.current,
      // ★ v2.1 补漏（Task 40-F）：要素表板书字体行此前不传选择 → 恒写 handoff 默认态
      //   乔木 507，韶华档从预览页导出错说字体；与 AgentBDirect exportSpeech/exportStoryboard
      //   同口径（服务端归一时 fontSource.handwriting.choice 与 uiSettings.handwritingFontChoice 同值）
      handwritingFontChoice: metaRef.current?.canvasParams?.fontSource?.handwriting?.choice ?? null,
    })
    message.success('已导出五字段要素表 MD')
  }

  function printPage() {
    window.print()
  }

  // 客户端原生录屏（纯浏览器交互授权，录制画布/动作/音频，0 后台服务器消耗）
  const [isRecording, setIsRecording, isRecordingRef] = useSyncedRef<boolean>(false)
  const [recordingSeconds, setRecordingSeconds] = useState(0)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const recordedChunksRef = useRef<Blob[]>([])
  const recordingStreamRef = useRef<MediaStream | null>(null)
  const recordingTimerIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const recordingTimerText = (() => {
    const m = Math.floor(recordingSeconds / 60)
    const s = recordingSeconds % 60
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  })()

  // 录屏交付前置就绪检查
  const [precheckModalOpen, setPrecheckModalOpen] = useState(false)

  // 模块 1：题目识别状态（computed → 渲染期直算；refreshPrecheckStatus 异步后用镜像 ref 重算）
  function computeProblemReadiness(problemTextValue: string): any {
    const text = (problemTextValue || '').trim()
    const isReady = text.length > 0
    return {
      key: 'problem',
      name: '题目识别状态',
      isReady,
      statusText: isReady ? '已就绪' : '未就绪',
      statusColor: isReady ? 'success' : 'error',
      description: isReady
        ? `题目文本已就绪（共 ${text.length} 字），画布题目区正常渲染展示。`
        : '尚未检测到题目文本或题目尚未在「第 1 步 贴题识别」中完成识别落位与确认。',
      guide: '请返回「第 1 步 贴题识别」页面，上传清晰题目截图或粘贴题文，完成落位并点击「确认使用此题」，确保交付微课具备完整题面板书。',
      actionText: '前往「第 1 步 贴题识别」',
      actionHref: '/',
    }
  }

  // 模块 2：TTS 音轨状态
  function computeTtsReadiness(rowsValue: any[]): any {
    const totalSteps = rowsValue.length
    if (totalSteps === 0) {
      return {
        key: 'tts',
        name: 'TTS 音轨状态',
        isReady: false,
        statusText: '未就绪 (无教学时序)',
        statusColor: 'error',
        description: '五字段教学时序表为空，尚未生成任何讲题口播与板书动作。',
        guide: '请在 Agent B 页面中先执行「五字段生成」，由 AI 建立讲题分步口播与板书时序，再进行语音合成。',
        actionText: '前往「Agent B 讲题五字段」',
        actionHref: '/',
        totalSteps: 0,
        readyCount: 0,
        missingCount: 0,
        missingSteps: [],
      }
    }

    const isRowAudioValid = (r: any) => Boolean(r?.audioUrl && r.audioUrl !== '音频暂未生成')
    const readyCount = rowsValue.filter(isRowAudioValid).length
    const missingRows = rowsValue
      .map((r: any, idx: number) => ({ step: idx + 1, valid: isRowAudioValid(r) }))
      .filter((item: any) => !item.valid)
      .map((item: any) => item.step)
    const isReady = readyCount === totalSteps

    return {
      key: 'tts',
      name: 'TTS 音轨状态',
      isReady,
      statusText: isReady ? `已就绪 (${totalSteps}/${totalSteps} 步已合成)` : `未就绪 (${readyCount}/${totalSteps} 步已合成)`,
      statusColor: isReady ? 'success' : 'error',
      description: isReady
        ? `全部 ${totalSteps} 步口播音轨均已就绪，录屏时音画同步将达到最佳效果。`
        : `当前五字段口播共 ${totalSteps} 步，已合成语音 ${readyCount} 步，尚有 ${totalSteps - readyCount} 步缺失音轨（未完成步骤：第 ${missingRows.slice(0, 8).join('、')}${missingRows.length > 8 ? ' 等' : ''} 步）。`,
      guide: '录屏交付需同步录制高品质口播音轨。请在 Agent B 讲题时序表格中，为缺失音轨的行点击「试听/生成语音」按钮（或调用 ASR 兜底），确保所有行均拥有有效音频。',
      actionText: '前往完善 TTS 音轨',
      actionHref: '/',
      totalSteps,
      readyCount,
      missingCount: totalSteps - readyCount,
      missingSteps: missingRows,
    }
  }

  const problemReadiness = computeProblemReadiness(problemText)
  const ttsReadiness = computeTtsReadiness(rows)

  // 预检查综合汇总
  const precheckModules = [problemReadiness, ttsReadiness]
  const unreadyModules = precheckModules.filter((m: any) => !m.isReady)
  const allModulesReady = unreadyModules.length === 0

  // 刷新状态并重新检查（await 后 computed 已在 Vue 中自动重估 → 此处用镜像 ref 重算等价）
  async function refreshPrecheckStatus() {
    await fetchDeliverableData()
    const freshProblemReadiness = computeProblemReadiness(problemTextRef.current)
    const freshTtsReadiness = computeTtsReadiness(rowsRef.current)
    const freshUnreadyModules = [freshProblemReadiness, freshTtsReadiness].filter((m: any) => !m.isReady)
    const freshAllModulesReady = freshUnreadyModules.length === 0
    if (freshAllModulesReady) {
      message.success('恭喜！题目识别与 TTS 音轨均已就绪！')
      setPrecheckModalOpen(false)
    } else {
      message.info(`已刷新：仍有 ${freshUnreadyModules.length} 项模块未就绪，请参考指引完善。`)
    }
  }

  // 供开发者或测试快速录屏（放权原则）
  function forceStartRecording() {
    setPrecheckModalOpen(false)
    message.warning('已跳过前置检查，启动测试录屏（视频可能缺少题文或语音）')
    startScreenRecording()
  }

  async function toggleScreenRecording() {
    if (isRecordingRef.current) {
      stopScreenRecording()
      return
    }

    // 录屏交付预检查：如果题目识别状态或 TTS 音轨状态未就绪，弹窗展示未就绪列表与指引
    if (!allModulesReady) {
      setPrecheckModalOpen(true)
      return
    }

    await startScreenRecording()
  }

  async function startScreenRecording() {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        message.error('您的浏览器当前不支持或禁用了屏幕录制 API (getDisplayMedia)。请使用 Chrome/Edge 浏览器打开。')
        return
      }

      let stream: MediaStream | null = null
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({
          video: { displaySurface: 'browser', frameRate: 30 },
          audio: true,
        })
      } catch {
        stream = await navigator.mediaDevices.getDisplayMedia({
          video: { frameRate: 30 },
        })
      }

      if (!stream) return
      recordingStreamRef.current = stream

      // ★ 哑剧防火（2026-10-25 需求：Fish TTS 口播必须录在范围内）：授权弹窗没勾
      //   「同时分享标签页音频」时 getDisplayMedia 也会成功但音轨为空 → 成品哑剧。
      //   显式校验音轨并大声警告（不阻断：录无声画布的调试场景仍可继续）。
      const hasAudioTrack = (stream.getAudioTracks() || []).length > 0
      if (!hasAudioTrack) {
        message.warning({
          content: '⚠ 本次录屏未捕获到音频轨：口播音稿将录不进去（哑剧）！如需声音请停止后重新录制——浏览器授权弹窗选择「此标签页」并勾选「同时分享标签页音频」',
          duration: 10,
        })
      }

      let mimeType = 'video/webm;codecs=vp9,opus'
      if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/webm;codecs=vp8,opus'
      if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/webm'
      if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = ''

      recordedChunksRef.current = []
      const options = mimeType ? { mimeType } : undefined
      mediaRecorderRef.current = new MediaRecorder(stream, options)

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data)
        }
      }

      mediaRecorderRef.current.onstop = () => {
        cleanupRecordingUI()
        if (recordedChunksRef.current.length > 0) {
          const actualType = mimeType || 'video/webm'
          const blob = new Blob(recordedChunksRef.current, { type: actualType })
          const url = URL.createObjectURL(blob)
          const a = document.createElement('a')
          const baseName = `board-video-${projectCodeRef.current || 'deliverable'}`
          a.href = url
          a.download = `${baseName}.webm`
          a.click()
          URL.revokeObjectURL(url)
          const sizeMb = (blob.size / (1024 * 1024)).toFixed(2)
          // ★ 2026-10-25 需求拍板：恒 WebM 产物 + 文本教转 MP4（程序不引转码依赖保持轻量）
          message.success({
            content: `🎉 演播录屏已保存（WebM · ${sizeMb} MB，含口播音轨）｜转 MP4：① 剪映导入 → 导出选 MP4（零安装，推荐）② ffmpeg：ffmpeg -i ${baseName}.webm -c:v libx264 -c:a aac ${baseName}.mp4`,
            duration: 12,
          })
        }
      }

      const videoTrack = stream.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.onended = () => {
          if (isRecordingRef.current) stopScreenRecording()
        }
      }

      mediaRecorderRef.current.start(1000)
      setIsRecording(true)
      setRecordingSeconds(0)
      recordingTimerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1)
      }, 1000)

      message.info(hasAudioTrack ? '🔴 录屏已开始！请演播您的板书与动作（已捕获音轨，TTS 口播将同步录制）' : '🔴 录屏已开始！请演播您的板书与动作（⚠ 无音轨：本次为无声录像）')
    } catch (err: any) {
      if (err.name !== 'NotAllowedError') {
        message.error('启动录屏失败: ' + (err.message || String(err)))
      }
    }
  }

  function stopScreenRecording() {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop()
    }
    if (recordingStreamRef.current) {
      recordingStreamRef.current.getTracks().forEach((t) => t.stop())
    }
  }

  function cancelScreenRecording() {
    recordedChunksRef.current = []
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop()
    }
    if (recordingStreamRef.current) {
      recordingStreamRef.current.getTracks().forEach((t) => t.stop())
    }
    cleanupRecordingUI()
    message.info('已取消本次录制')
  }

  function cleanupRecordingUI() {
    if (recordingTimerIntervalRef.current) {
      clearInterval(recordingTimerIntervalRef.current)
      recordingTimerIntervalRef.current = null
    }
    setIsRecording(false)
  }

  // onBeforeUnmount（录屏资源清理）
  useEffect(() => {
    return () => {
      cleanupRecordingUI()
      if (recordingStreamRef.current) {
        recordingStreamRef.current.getTracks().forEach((t) => t.stop())
      }
    }
  }, [])

  function getStageTagColor(stage: string) {
    if (stage === '审题引入') return 'blue'
    if (stage === '知识链接') return 'cyan'
    if (stage === '深入探究') return 'purple'
    if (stage === '解答过程') return 'green'
    if (stage === '总结提升') return 'orange'
    return 'default'
  }

  return (
    <div
      className={
        'deliverable-page-wrapper' +
        (viewMode === 'fullscreen' ? ' mode-fullscreen' : '') +
        (viewMode === 'canvas' ? ' mode-canvas' : '')
      }
    >
      {/* 顶部状态与导航条 */}
      {viewMode === 'deliverable' && (
        <header className="deliverable-nav-header">
          <div className="nav-left">
            <div className="brand-title">
              <FundProjectionScreenOutlined className="brand-icon" />
              <span className="title-text">教学板书 · 视频素材交付单页</span>
            </div>
            {projectCode && (
              <Tag color="cyan" className="code-badge">
                编号: {projectCode}
              </Tag>
            )}
            <Tag color="success" className="status-tag">
              <CheckCircleOutlined /> 已固化存档 · 刷新不丢失
            </Tag>
          </div>

          <div className="nav-center-toggles">
            <label className="toggle-chip">
              <input type="checkbox" checked={showGrid} onChange={(e) => setShowGrid(e.target.checked)} />
              <span>网格线</span>
            </label>
            <label className="toggle-chip">
              <input type="checkbox" checked={showLabels} onChange={(e) => setShowLabels(e.target.checked)} />
              <span>四标签</span>
            </label>
            <label className="toggle-chip">
              <input type="checkbox" checked={showZones} onChange={(e) => setShowZones(e.target.checked)} />
              <span>分区辅助线</span>
            </label>

            {/* ★ 板书字体切换下拉（2026-10-25 需求）：选择随档走，切换后写入交付档 */}
            <div className="nav-font-switch" title="板书手写字体：切换后写入交付档（播放页 / 导出同步生效）">
              <span className="font-switch-label">✍ 板书字体</span>
              <Select
                size="small"
                className="board-font-select"
                value={effectiveFontChoice}
                options={boardFontOptions}
                onChange={applyBoardFontChoice}
              />
            </div>
          </div>

          <div className="nav-right-actions">
            {/* ★ Task 58 布局修订闭环：编辑态保存条 */}
            {layoutEditMode && (
              <Button
                size="small"
                type="primary"
                className="btn-save-layout-revision"
                title="把拖拽后的四区/标签/题目区坐标保存为布局修订，回工作台重新生成时生效"
                onClick={saveLayoutRevisionAction}
              >
                💾 保存布局修订
              </Button>
            )}
            <Button
              size="small"
              type={layoutEditMode ? 'dashed' : 'default'}
              className={layoutEditMode ? 'is-layout-editing' : ''}
              title="布局调整前移生成环：拖四区框/标签/题目块，保存后回工作台重新生成（播放页调布局=生米煮熟）"
              onClick={() => setLayoutEditMode(!layoutEditMode)}
            >
              {layoutEditMode ? '✅ 完成布局编辑' : '📐 布局编辑'}
            </Button>
            {/* 客户端录屏按钮（拉起浏览器原生授权，0 后端消耗） */}
            <Button
              size="small"
              className={'btn-vue-record' + (isRecording ? ' is-recording' : '')}
              onClick={toggleScreenRecording}
              title="拉起浏览器录屏，录制画布演播与声音"
            >
              <span className={'rec-dot-icon' + (isRecording ? ' blink' : '')}>●</span>
              <span>{isRecording ? `录制中 ${recordingTimerText}` : '录屏交付'}</span>
            </Button>
            <Button size="small" onClick={copyPageUrl} icon={<ShareAltOutlined />}>
              分享链接
            </Button>
            <Button size="small" onClick={copyPipelineJson} icon={<CopyOutlined />}>
              复制流水线 JSON
            </Button>
            <Button
              size="small"
              type="primary"
              className="btn-toggle-fullscreen"
              onClick={() => setViewMode('fullscreen')}
              icon={<FullscreenOutlined />}
            >
              纯画布全屏
            </Button>
          </div>
        </header>
      )}

      {/* 录屏状态置顶浮动条 */}
      <FadeTransition visible={isRecording}>
        <div className="recording-floating-bar-vue">
          <span className="recording-pulse-vue"></span>
          <span style={{ fontWeight: 600 }}>正在录制画布演播</span>
          <span className="recording-timer-vue">{recordingTimerText}</span>
          <Button size="small" type="primary" danger onClick={stopScreenRecording}>
            ⏹ 结束并下载
          </Button>
          <Button size="small" ghost onClick={cancelScreenRecording}>
            ✕ 取消
          </Button>
        </div>
      </FadeTransition>

      {/* 主展示区 */}
      <main className={'deliverable-main-container' + (viewMode === 'canvas' ? ' canvas-only' : '')}>
        {/* 1. 严格锁定 1726 × 980 比例的真画布视口 */}
        <section
          className={
            'board-cinema-section' +
            (viewMode === 'fullscreen' ? ' stage-fullscreen' : '') +
            (viewMode === 'canvas' ? ' stage-canvas' : '')
          }
        >
          <div className="board-ratio-lock-box">
            <RealBoardPreview
              problemText={problemText}
              topicLayout={topicLayout}
              boardPlan={boardPlan}
              showGrid={showGrid}
              showAllLabels={showLabels || layoutEditMode}
              showZoneGuides={showZones}
              sourceImageUrl={sourceImageUrl}
              keepOriginal={keepOriginal}
              boardRows={rows}
              actionSpec={actionSpec}
              interactive={false}
              canvasParams={(meta && meta.canvasParams) || null}
              backgroundImageUrl={layoutEditMode ? '' : screenshotUrl}
              zoneEditable={layoutEditMode}
              onUpdateTopicLayout={onTopicLayoutUpdated}
              onUpdateProblemText={onProblemTextUpdated}
            />
          </div>

          {/* 纯全屏浮动工具栏 */}
          <FadeTransition visible={viewMode === 'fullscreen' && showFloatToolbar}>
            <div
              className="fullscreen-floating-toolbar"
              onMouseEnter={pingFloatToolbar}
            >
              {/* 全屏下录屏按钮 */}
              <Button
                size="small"
                className={'btn-vue-record' + (isRecording ? ' is-recording' : '')}
                onClick={toggleScreenRecording}
              >
                <span className={'rec-dot-icon' + (isRecording ? ' blink' : '')}>●</span>
                <span>{isRecording ? `停止录制 (${recordingTimerText})` : '录屏交付'}</span>
              </Button>
              <span className="toolbar-divider"></span>
              <label>
                <input type="checkbox" checked={showGrid} onChange={(e) => setShowGrid(e.target.checked)} /> 网格
              </label>
              <label>
                <input type="checkbox" checked={showLabels} onChange={(e) => setShowLabels(e.target.checked)} /> 四标签
              </label>
              <label>
                <input type="checkbox" checked={showZones} onChange={(e) => setShowZones(e.target.checked)} /> 分区线
              </label>
              <span className="toolbar-divider"></span>
              <span className="canvas-dimension">{DESIGN_W} × {DESIGN_H} (锁定 16:9)</span>
              <span className="toolbar-divider"></span>
              <Button size="small" ghost onClick={() => setViewMode('deliverable')} icon={<FullscreenExitOutlined />}>
                返回参数单页 (ESC)
              </Button>
            </div>
          </FadeTransition>

          {viewMode === 'fullscreen' && (
            <div className="fullscreen-esc-hint" onMouseMove={pingFloatToolbar}>
              按 ESC 键或点击工具栏退出全屏
            </div>
          )}
        </section>

        {/* 2. 下挖参数框 (教学视频制作核心参数看板) */}
        {viewMode === 'deliverable' && (
          <section className="params-dashboard-section">
            {/* 统计指标概览条 */}
            <div className="metrics-grid">
              <div className="metric-card">
                <div className="metric-icon bg-emerald"><ClockCircleOutlined /></div>
                <div className="metric-content">
                  <span className="metric-label">视频预估用时</span>
                  <span className="metric-value">{stats.totalDurationText || (stats.totalDuration ? stats.totalDuration + '秒' : '约2分半')}</span>
                </div>
              </div>

              <div className="metric-card">
                <div className="metric-icon bg-blue"><TableOutlined /></div>
                <div className="metric-content">
                  <span className="metric-label">时序步数</span>
                  <span className="metric-value">{rows.length ? rows.length + ' 步' : (stats.stepCount ? stats.stepCount + ' 步' : '8 步')}</span>
                </div>
              </div>

              <div className="metric-card">
                <div className="metric-icon bg-purple"><FileTextOutlined /></div>
                <div className="metric-content">
                  <span className="metric-label">口播总字数</span>
                  <span className="metric-value">{stats.charCount ? stats.charCount + ' 字' : '约350字'}</span>
                </div>
              </div>

              <div className="metric-card">
                <div className="metric-icon bg-amber"><CompassOutlined /></div>
                <div className="metric-content">
                  <span className="metric-label">画布标准</span>
                  <span className="metric-value">{CANVAS_SIZE.width} × {CANVAS_SIZE.height}</span>
                </div>
              </div>
            </div>

            {/* 标签页与参数详情 */}
            <div className="dashboard-tabs-container">
              <div className="tabs-header-bar">
                <div className="tabs-nav-list">
                  <button
                    className={'tab-nav-btn' + (activeTab === 'rows' ? ' active' : '')}
                    onClick={() => setActiveTab('rows')}
                  >
                    <TableOutlined /> 讲题五字段时序执行表 ({rows.length}步)
                  </button>
                  <button
                    className={'tab-nav-btn' + (activeTab === 'coords' ? ' active' : '')}
                    onClick={() => setActiveTab('coords')}
                  >
                    <CompassOutlined /> 真画布四大区域与规格规划
                  </button>
                  <button
                    className={'tab-nav-btn' + (activeTab === 'json' ? ' active' : '')}
                    onClick={() => setActiveTab('json')}
                  >
                    <CodeOutlined /> 自动化视频流水线对接 (JSON)
                  </button>
                </div>

                <div className="tab-header-actions">
                  {activeTab === 'rows' && (
                    <>
                      <Select
                        value={selectedStageFilter}
                        size="small"
                        style={{ width: 120 }}
                        onChange={(value) => setSelectedStageFilter(value)}
                        options={[
                          { value: 'all', label: '全部阶段' },
                          ...stageOptions.filter((s: string) => s !== 'all').map((st: string) => ({ value: st, label: st })),
                        ]}
                      />
                      <Button size="small" onClick={exportSpeechMarkdown} icon={<DownloadOutlined />}>导出口播 MD (TTS就绪)</Button>
                      <Button size="small" onClick={exportElementsMarkdown} icon={<DownloadOutlined />}>导出要素表 MD</Button>
                    </>
                  )}

                  {activeTab === 'coords' && (
                    <span className="spec-hint-badge">画布物理基准: {CANVAS_SIZE.width} × {CANVAS_SIZE.height} (16:9 课件演播室)</span>
                  )}

                  {activeTab === 'json' && (
                    <>
                      <Button size="small" type="primary" onClick={downloadPipelineJson} icon={<DownloadOutlined />}>下载 JSON</Button>
                      <Button size="small" onClick={copyPipelineJson} icon={<CopyOutlined />}>一键复制 JSON</Button>
                    </>
                  )}
                </div>
              </div>

              {/* TAB 1: 讲题五字段时序执行表 */}
              <div className="tab-pane-content tab-rows-pane" style={activeTab === 'rows' ? undefined : { display: 'none' }}>
                {!rows.length ? (
                  <div className="empty-hint-card">
                    <InfoCircleOutlined /> 暂无五字段生成数据，可在生成器中点击「生成产物单页」同步
                  </div>
                ) : (
                  <div className="execution-table-wrap">
                    <table className="execution-table">
                      <thead>
                        <tr>
                          <th style={{ width: 54 }}>序号</th>
                          <th style={{ width: 100 }}>教学阶段</th>
                          <th style={{ width: 76 }}>时长</th>
                          <th style={{ width: '44%' }}>口播文本 (Speech - 无TTS标签/数字已汉字化)</th>
                          <th>板书内容 (Board) 与动作规范 (actionSpec)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredRows.map((row: any, idx: number) => (
                          <tr key={idx}>
                            <td className="col-center index-num">{idx + 1}</td>
                            <td className="col-center">
                              <Tag color={getStageTagColor(row.stage)}>{row.stage}</Tag>
                            </td>
                            <td className="col-center duration-tag">{row.duration}</td>
                            <td className="col-speech">
                              <p className="speech-text">{row.speech}</p>
                            </td>
                            <td className="col-board">
                              <div className="board-snippet">
                                <span className="snippet-label">板书:</span>
                                <span className="board-text">{formatBoardDisplay(row.board)}</span>
                              </div>
                              {row.actionSpec && row.actionSpec.length ? (
                                <div className="actions-badge-list">
                                  {row.actionSpec.map((act: any, aIdx: number) => (
                                    <span
                                      key={aIdx}
                                      className="action-pill"
                                      title={JSON.stringify(act)}
                                    >
                                      ⚡ {formatActionPillLabel(act)}
                                    </span>
                                  ))}
                                </div>
                              ) : null}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* TAB 2: 真画布四大区域与落点坐标 */}
              <div className="tab-pane-content tab-coords-pane" style={activeTab === 'coords' ? undefined : { display: 'none' }}>
                <div className="coords-two-col">
                  {/* 左侧：题目区原题与渲染 */}
                  <div className="coords-card topic-preview-card">
                    <div className="card-sub-header">
                      <span className="sub-title">📝 题目文本 (KaTeX 公式解析)</span>
                      {keepOriginal && <Tag color="orange">保留原题原图</Tag>}
                    </div>
                    <div className="problem-latex-box" dangerouslySetInnerHTML={{ __html: renderedProblemHtml }} />

                    {sourceImageUrl && (
                      <div className="source-image-strip">
                        <span className="sub-label">原图资产:</span>
                        <img src={sourceImageUrl} className="source-thumb" alt="原题截图" />
                      </div>
                    )}
                  </div>

                  {/* 右侧：四区规格与百分比绝对值对照表 */}
                  <div className="coords-card zones-table-card">
                    <div className="card-sub-header">
                      <span className="sub-title">🎯 四大区域规划参数 ({CANVAS_SIZE.width} × {CANVAS_SIZE.height} · 达芬奇手稿风格)</span>
                    </div>
                    <table className="zones-data-table">
                      <thead>
                        <tr>
                          <th>区域名称</th>
                          <th>相对百分比 (X%, Y%, W%, H%)</th>
                          <th>绝对像素坐标 ({CANVAS_SIZE.width}×{CANVAS_SIZE.height})</th>
                          <th>功能定义</th>
                        </tr>
                      </thead>
                      <tbody>
                        {fourZonesCoords.map((z: any) => (
                          <tr key={z.key}>
                            <td className="zone-name">
                              <span className="zone-tag-chip">{z.tag}</span>
                              <strong>{z.name}</strong>
                            </td>
                            <td className="zone-coords-pct">
                              X: {z.xPct} | Y: {z.yPct}<br />
                              W: {z.wPct} | H: {z.hPct}
                            </td>
                            <td className="zone-coords-px">
                              X: {z.xPx} | Y: {z.yPx}<br />
                              W: {z.wPx} | H: {z.hPx}
                            </td>
                            <td className="zone-desc">{z.desc}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* TAB 3: 自动化视频流水线对接 (JSON) */}
              <div className="tab-pane-content tab-json-pane" style={activeTab === 'json' ? undefined : { display: 'none' }}>
                <div className="json-code-header">
                  <span className="code-title">📦 下游渲染引擎消费规格 (Direct Pipeline Spec)</span>
                  <Button size="small" type="primary" ghost onClick={copyPipelineJson} icon={<CopyOutlined />}>复制 JSON</Button>
                </div>
                {/* suppressHydrationWarning：pipelineJsonString 冷开档含 new Date() 时间戳
                    （deliverableId 'DELIV-'+Date.now() / generatedAt ISO），SSR 与客户端首渲染必然
                    不同——原 Vue MPA 无 SSR 无此问题；React 19 会原位修复仅告警，这里精准消音 */}
                <pre className="json-code-block" suppressHydrationWarning><code suppressHydrationWarning>{pipelineJsonString}</code></pre>
              </div>
            </div>
          </section>
        )}
      </main>
      {/* 录屏交付前置检查未就绪提示 Ant Design Modal */}
      <Modal
        open={precheckModalOpen}
        title="录屏交付前置就绪检查"
        width={640}
        destroyOnHidden={false}
        centered
        className="precheck-delivery-modal"
        onCancel={() => setPrecheckModalOpen(false)}
        footer={
          <div className="precheck-modal-footer">
            <Button
              type="text"
              size="small"
              className="btn-force-record"
              onClick={forceStartRecording}
              title="系统放权，不强制卡死。供开发者临时调试无音频画布录制"
            >
              仍要测试录屏 (可能缺少音轨/题文)
            </Button>
            <div className="footer-primary-actions">
              <Button onClick={refreshPrecheckStatus} icon={<ReloadOutlined />}>
                刷新就绪状态
              </Button>
              <Button type="primary" onClick={() => setPrecheckModalOpen(false)}>
                我知道了，去完成
              </Button>
            </div>
          </div>
        }
      >
        <div className="precheck-modal-body">
          <Alert
            type="warning"
            showIcon
            className="precheck-warning-banner"
            title="检测到交付核心模块尚未就绪"
            description="录屏交付将把画布笔迹演播与口播音轨同步录制为最终交付微课。若模块未就绪，可能导致成品视频缺少题面板书或静音无声。请按照下方指引完成配置。"
          />

          <div className="unready-modules-section">
            <div className="unready-section-header">
              <span className="section-title">未就绪模块列表 ({unreadyModules.length}/{precheckModules.length})</span>
              <span className="section-sub">请逐项确认并完善后再启动录屏交付</span>
            </div>

            <div className="unready-modules-list">
              {unreadyModules.map((item: any) => (
                <div
                  key={item.key}
                  className="unready-module-card"
                >
                  <div className="module-card-header">
                    <div className="module-card-title-wrap">
                      {item.key === 'problem' ? (
                        <FileSearchOutlined className="module-type-icon" />
                      ) : (
                        <SoundOutlined className="module-type-icon" />
                      )}
                      <span className="module-title-text">{item.name}</span>
                    </div>
                    <Tag color={item.statusColor} className="module-status-badge">
                      <CloseCircleOutlined /> {item.statusText}
                    </Tag>
                  </div>

                  <div className="module-diagnosis">
                    <span className="diagnosis-label">当前状态：</span>
                    <span className="diagnosis-text">{item.description}</span>
                  </div>

                  <div className="module-guide-box">
                    <div className="guide-header">
                      <InfoCircleOutlined className="guide-icon" />
                      <span className="guide-title">完成指引：</span>
                    </div>
                    <p className="guide-content">{item.guide}</p>
                    <div className="guide-actions">
                      <a
                        href={item.actionHref}
                        className="btn-guide-action"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {item.actionText}
                        <ArrowRightOutlined />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ★ 2026-10-25 需求：录制产物格式与音轨说明（恒 WebM + MP4 转换文本指引，程序不引转码依赖） */}
          <div className="precheck-format-tips">
            <div className="format-tips-header">
              <InfoCircleOutlined className="guide-icon" />
              <span className="guide-title">录制格式与音轨说明：</span>
            </div>
            <ul className="format-tips-list">
              <li>🔊 <b>录到口播声音</b>：点「开始录制」后浏览器授权弹窗选择 <b>「此标签页」</b> 并勾选 <b>「同时分享标签页音频」</b>，Fish TTS 口播音轨才会被录进去（不勾 = 哑剧）。</li>
              <li>📦 <b>产物格式为 WebM</b>：Chrome 标准录屏格式，剪映 / OBS / PR 均可直接导入。</li>
              <li>🎞 <b>转 MP4</b>（任选其一）：① 剪映导入 → 导出选 MP4（零安装，推荐）；② 装了 ffmpeg 的电脑一行命令：<code>ffmpeg -i xxx.webm -c:v libx264 -c:a aac xxx.mp4</code>。</li>
            </ul>
          </div>
        </div>
      </Modal>
    </div>
  )
}
