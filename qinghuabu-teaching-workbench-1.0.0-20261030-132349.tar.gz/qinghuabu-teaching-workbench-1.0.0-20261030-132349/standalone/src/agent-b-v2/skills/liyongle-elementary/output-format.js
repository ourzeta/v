/* 输出格式与核对 */
export const outputFormat = `
## 输出格式
只输出 JSON 对象 \`{"rows":[...]}\`，不含 Markdown、解释或思考过程。
每行有且只有四列：
- stage：只能是题目 / 分析 / 解答 / 总结。
- speech：可直接朗读的自然口播。
- board：\`{"startDelay":0,"content":""}\`，startDelay 是起笔延时秒数；无新板书则 content 为空，读题时为空且延时为 0。
- actionSpec：动作数组，无动作写 []；每项含 action，可选 triggerKeyword 与 action 平级。
音频地址、音频时长由程序回填，不输出 audioUrl / audioDurationMs / mp3 / duration。

## 输出前核对
1. 首行只说“同学你好！很高兴为你讲解这道题！”，读题从下一行开始；末行只说“路虽远，行则将至，加油！”，总结另行说完整。
2. 题目条件、计算、单位和答案一致，解答不跳步（每步列式→代入→计算→得数），内部验算不外念；正常启发提问可以保留，不演错重来。
3. 问题链、公式依据与知识点都回到本题；行内步骤简短，必要条件逐步落板，不挤多个结论。
4. speech 无标签、舞台说明或公式符号；板书采用前述 x / X·、分式 DSL 与除号规则，写 12.-.3=4 不写 12 .-. 3 = 4。
5. 动作仅 underline / circle，目标是已展示原文，order 全表唯一递增；triggerKeyword 若填，须逐字存在于本行 speech。
6. 起笔节点按本行语义估算；无额外坐标、音频或动作时长字段。
`
