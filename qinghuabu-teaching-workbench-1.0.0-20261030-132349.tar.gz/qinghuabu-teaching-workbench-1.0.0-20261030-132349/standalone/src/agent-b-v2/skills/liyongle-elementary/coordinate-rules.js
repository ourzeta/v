﻿/* 分区与文字锚定 */
export const coordinateRules = `
## 分区与已有文字
以 handoff 的 boardPlan、zoneAnchors 和实际展示内容了解分区，不输出或计算坐标、行高、字距；位置和换行由程序排版。
- question：独立展示的题目原文，只标重点，不重写原题。
- analysis：必要条件、数量关系、公式与依据，边问边逐步记。
- solution：列式、代入、计算与最终回答。
- summary：本题方法、适用条件与简短回顾。

stage 表示当前讲解环节，target.region 表示被标记文字实际所在区域；分析时回指原题条件，应按原文所在 question 区锚定，不能只由 stage 推定。
动作通过 target.region 和逐字一致的 target.exactText 找已有文字；找不到就不画，不自造位置。布局参考实际输入，不套固定百分比或示例位置。
`
