/* 板书与文字标记规范 */
import { QUESTION_FONT_SIZE, QUESTION_FONT_FAMILY, BOARD_FONT_SIZE } from '../../../services/stepHandoff.js'

export const boardRules = `
## 板书与动作
原题展示区独立固定微软雅黑（${QUESTION_FONT_FAMILY}）${QUESTION_FONT_SIZE}px；分析/解答/总结使用正文手写体 ${BOARD_FONT_SIZE}px。stage 是讲解环节，不决定原题区字体。
板书与口播同步，抓关键词、公式、算式和结论，不抄整段口播；一行一个要点，分步生长。没有新内容时 content 为空，不重复前文。纯提问/铺垫与真正书写尽量分 row。
board 是 \`{"startDelay":0,"content":""}\`。startDelay 是口播开始到落笔的秒数，按引出板书的关键词前字数 × 0.375 估算；开口即写可为 0，无板书或读题为 0，不固定填同一数值。布局、字体和精确时序由程序负责。

### 数学写法
- 运算符紧凑贴排：写 \`12.-.3=4\`、\`9+6=15\`、\`7/15x20\`，不写 \`12 .-. 3 = 4\`。
- 无未知数时乘号用 x，如 \`(9+6)x8/2=60\`；有未知数时未知数大写 X、乘号用 ·，如 30X·3=90X，不用相邻 xx。
- 除号用 .-.，不写 ÷ 或 \\div，不把除法和分数互换；竖式可用 ) 与 -----。
- 纯分数用 a/b，如 7/15、3/4x20；整体算式作分子或分母时允许 \\frac{3+34}{5} 这种分式 DSL，不能丢掉整体范围。除分式 DSL 外不输出 LaTeX 宏或环境。
- 平方立方用 ²、³；竖式横线用 ------，不用 _。文字指向可用 ->；它不是动作工具。多步计算普通换行，一行一步，单位写清。

### 文字标记
只允许 rough-notation 的 underline / circle；颜色由程序决定。目标必须已经存在：question 区匹配题目原文，其他区匹配已有板书。
每项 actionSpec 的包装结构：
\`\`\`
{ triggerKeyword: "口播触发词（可选，entry 级）", action: { tool, ...工具参数, order } }
\`\`\`
triggerKeyword 可选，与 action 平级，必须逐字存在于本行 speech；不填时默认先写板书再依次标记。
参数示例：
\`\`\`json
{
  "action": {
    "tool": "rough-notation",
    "action": "underline",
    "target": {
      "region": "question",
      "exactText": "小明有5个苹果",
      "occurrence": 1
    },
    "order": 1
  }
}
\`\`\`
- target.region 只能是 question / analysis / solution / summary，按文字真实所在区选。
- target.exactText 逐字匹配原文；occurrence 指定重复文字的第几次，默认 1。
- order 在 action 内，是全表唯一递增正整数。单手依次书写与标记，不同时两处动笔。
- 无可标记文字时返回空动作数组。不要输出 start/end 坐标、颜色或 durationMs / estimatedDurationMs / gapAfterMs / seed。
`
