/* ASR 口播稿优化与板书规范化引擎
   严格遵循规范：
   1. 口播稿为纯文字，可直接导入 TTS 自然朗读；绝不包含任何控制标签或占位符
   2. 阿拉伯数字保留阿拉伯数字，不改写为中文数字（如 15分之7 不写成 十五分之七）
   3. 小数：整数部分保留阿拉伯数字，小数点读"点"，小数部分逐位读汉字（如 3.14 -> 3点一四，0.05 -> 0点零五）
   4. 分数：先读分母再读分子，保留阿拉伯数字（\frac{7}{15} -> 15分之7，1\frac{1}{2} -> 1又2分之1）
   5. 根号/幂次：√9 -> 根号9，a² -> a的平方，a³ -> a的立方，a^4 -> a的4次方
   6. 运算符：+ 读作"加"，- 读作"减"，×/x 读作"乘以"，÷/.-. 读作"除以"，= 读作"等于"
   7. 区分未知数 X（直接读 X）与乘法 x（读作"乘以"）
   8. 括号必须读出"括号里"
   9. 板书（★ 2026-10-24 夏夏教义）：乘法统一小写 x；除号写 .-.（点-横-点上下堆叠，不写 ÷）；
      分数写 a/b 纯字符（程序升 \frac 堆叠 DSL，占 2 行高度）；平方立方写 ² ³（1/3 字号右上角）；零 KaTeX
*/

import { formatMathSpeechToChinese } from '../lib/mathAsrConverter.js'
import { AGENT_B_V2_SPEECH_RATE } from '../agent-b-v2/timing.js'
import { normalizeBoardLine } from '../utils/superFilter.js'

// 兑底秒/字系数：真源派生（60/160 = 0.375 秒/字）。仅无音频时的初始预估用，有音频以实测时长为准。
const FALLBACK_SEC_PER_CHAR = 60 / AGENT_B_V2_SPEECH_RATE

/**
 * 优化单行 speech 口播稿文本（结合数学算式口播转换库）
 */
export function polishSpeechText(rawSpeech) {
  if (!rawSpeech || typeof rawSpeech !== 'string') return ''
  return formatMathSpeechToChinese(rawSpeech)
}

/**
 * 规范化板书 board 文本 —— ★ 2026-10-24 起归一到 superFilter 唯一真源（normalizeBoardLine）
 * ★ Task 43 全局归一（夏夏拍板「全局归一化过，不要冲突」）历史脉络：旧版在此手抄了
 *   乘号替换 + a/b→\frac 两套平行正则（自带小数/单位负向断言保护），与真源 superFilter ⑩ 形成
 *   第三套平行实现——重复即多余，多余即没有价值，本版销账：Check 落库口径 = superFilter 口径
 *   = 存储单一方言（÷→.-.、×→x、a/b→\frac、^2→² 全走真源 12 步）。
 * - 乘法统一小写 x；除号 .-.；分数 \frac 堆叠 DSL；板书零 KaTeX（题干除外）
 */
export function normalizeBoardContent(content) {
  if (!content || typeof content !== 'string') return ''
  return normalizeBoardLine(content)
}

/**
 * 语义板书时机估算器：
 * 结合口播与板书内容，寻找最自然的落笔关键词，换算为本行语音播放后的秒数
 * （兑位口径：按 FALLBACK_SEC_PER_CHAR 真源派生，160cpm 时 = 0.375 秒/字；仅无音频初始预估用）
 */
export function estimateKeywordStartDelay(speech, boardContent, stage) {
  if (stage === '题目' || !boardContent || !boardContent.trim()) return 0
  const cleanSpeech = String(speech || '').trim()
  if (!cleanSpeech) return 0

  // 1. 寻找明确引导落笔的触发词/短语
  const triggerPatterns = [
    /写下/, /列出/, /列式/, /写成/, /记作/, /公式是/, /关系是/, /算式是/,
    /等于/, /算出来/, /算得/, /得出/, /得到/, /也就是/, /计算得到/,
    /代入/, /先算/, /再算/, /可以写成/, /设/
  ]

  let bestIndex = -1

  for (const pattern of triggerPatterns) {
    const match = pattern.exec(cleanSpeech)
    if (match && match.index > 0) {
      if (bestIndex === -1 || match.index < bestIndex) {
        bestIndex = match.index
      }
    }
  }

  // 2. 若未匹配到引导词，尝试寻找板书中的核心数字或未知数在口播中的第一次出现位置
  if (bestIndex === -1) {
    const numbers = boardContent.match(/\b\d+(?:\.\d+)?\b/g)
    if (numbers && numbers.length) {
      for (const num of numbers) {
        const idx = cleanSpeech.indexOf(num)
        if (idx > 2 && (bestIndex === -1 || idx < bestIndex)) {
          bestIndex = idx
        }
      }
    }
  }

  // 若找到动笔关键词且不是第0字，按兑底秒/字系数计算（真源派生，防散）
  if (bestIndex > 2) {
    const calculatedSec = Number((bestIndex * FALLBACK_SEC_PER_CHAR).toFixed(1))
    return Math.min(20.0, Math.max(0.5, calculatedSec))
  }

  // 口播开门见山直接讲板书内容，给一个起笔自然的 1.0s
  return 1.0
}

/**
 * 对整套 rows 进行完整的 ASR 与板书规范化处理
 * 返回 { rows, changes }
 */
export function polishRowsASR(originalRows) {
  if (!Array.isArray(originalRows)) return { rows: [], changes: [] }

  const changes = []
  const polishedRows = originalRows.map((origRow, index) => {
    const rowNum = index + 1
    const stage = origRow?.stage || ''
    const origSpeech = String(origRow?.speech || '')
    const polishedSpeech = polishSpeechText(origSpeech)

    if (origSpeech !== polishedSpeech) {
      changes.push({
        row: rowNum,
        field: 'speech',
        before: origSpeech,
        after: polishedSpeech,
        reason: 'ASR 口播纯文字优化：转换数学符号为自然中文读法、规范小数与分数读音',
      })
    }

    let origBoardObj = origRow?.board
    let newBoard = origBoardObj

    if (typeof origBoardObj === 'string') {
      const normalizedStr = normalizeBoardContent(origBoardObj)
      if (normalizedStr !== origBoardObj) {
        changes.push({
          row: rowNum,
          field: 'board',
          before: origBoardObj,
          after: normalizedStr,
          reason: '板书符号规范化：乘法统一为小写 x，规范分数与公式',
        })
      }
      const estDelay = estimateKeywordStartDelay(polishedSpeech, normalizedStr, stage)
      if (estDelay > 0) {
        changes.push({
          row: rowNum,
          field: 'board_timing',
          before: '+0.0s (开播即显)',
          after: `+${estDelay.toFixed(1)}s`,
          reason: `语义校准板书时机：结合口播关键词换算延迟约 +${estDelay.toFixed(1)}s 落笔，避免提前剧透并保证音画同步`,
        })
      }
      newBoard = {
        content: normalizedStr,
        startDelay: estDelay,
      }
    } else if (origBoardObj && typeof origBoardObj === 'object') {
      const origContent = String(origBoardObj.content || '')
      const normalizedContent = normalizeBoardContent(origContent)
      if (origContent !== normalizedContent) {
        changes.push({
          row: rowNum,
          field: 'board',
          before: origContent,
          after: normalizedContent,
          reason: '板书符号规范化：乘法统一为小写 x，规范分数与公式',
        })
      }

      let currentDelay = origBoardObj.startDelay
      if (typeof currentDelay === 'number' && currentDelay > 0) {
        // 模型或人工已显式设定时机，保留
      } else if (normalizedContent && stage !== '题目') {
        const estDelay = estimateKeywordStartDelay(polishedSpeech, normalizedContent, stage)
        if (estDelay > 0 && (!currentDelay || currentDelay === 0)) {
          changes.push({
            row: rowNum,
            field: 'board_timing',
            before: '+0.0s (开播即显)',
            after: `+${estDelay.toFixed(1)}s`,
            reason: `语义校准板书时机：结合口播关键词换算延迟约 +${estDelay.toFixed(1)}s 落笔，避免提前剧透并保证音画同步`,
          })
          currentDelay = estDelay
        }
      }

      newBoard = {
        content: normalizedContent,
        startDelay: currentDelay !== undefined ? currentDelay : 0,
      }
    }

    // ★ 哑巴根修复（P1，2026-10-15）：ASR 兜底通道与 Check Agent 同病——
    // 返回行只带 4 内容字段，音频三字段被洗掉；此处按索引回填原行音频，
    // 防止「ASR 规范化 → 应用 → 导出/播放哑巴」链路
    const keepAudio = {}
    if (typeof origRow?.audioUrl === 'string' && origRow.audioUrl !== '') keepAudio.audioUrl = origRow.audioUrl
    if (Number(origRow?.audioDurationMs) > 0) {
      keepAudio.audioDurationMs = Math.round(Number(origRow.audioDurationMs))
      keepAudio.duration = origRow.duration
    }

    return {
      stage,
      speech: polishedSpeech,
      board: newBoard,
      actionSpec: Array.isArray(origRow?.actionSpec) ? origRow.actionSpec : [],
      ...keepAudio,
    }
  })

  return { rows: polishedRows, changes }
}

/**
 * 兼容旧调用方；实际布局由真实渲染层负责。
 */
export function polishBoardSpacing(rows, changes = []) {
  return { rows: Array.isArray(rows) ? rows : [], changes }
}
