/**
 * skillViolations.js — 5 个上游 skill 反模式落地为 Check Agent 校验
 *
 * 来源 skills/：
 *   1. board-zone-layout       → 坐标越界 + 严重叠字
 *   2. handwriting-font-policy → L1 题目层手写体越权
 *   3. hand-action-control     → 工具白名单 + Agent 填时长
 *   4. speech-board-timing     → 口播发音硬规范 (分数/符号/小数)
 *   5. field-char-escape-filter → 字面落板禁令 ($ \left \right &amp; 等)
 *
 * 设计原则（按用户接管方法论）：
 *   - 模块化: 独立文件, 不动现有 contract.js
 *   - 模块调用优先: 复用 5 个 skill 的反模式表, 不重写正则
 *   - 禁止代码膨胀: 只做反模式检测, 不做修复 (修复由 Check Agent 模型做)
 *   - 极简但完整: 每条反模式一行, 无冗余
 *
 * @qh-core LANE=CHECK POINT=SKILL_VIOLATIONS 5 skill 反模式校验
 */

// ─── skill 5: field-char-escape-filter 复用 ─────────
// 字面落板禁令: $ \left \right 控制字符 &amp; &lt; &gt;
// 注意: 不用 /g flag, 避免 .test() 的 lastIndex 状态问题
const FORBIDDEN_LITERAL = [
  { re: /\$+/, from: 'field-char-escape-filter §五', msg: '$ 绝不字面落板' },
  { re: /\\left\b|\\right\b/, from: 'field-char-escape-filter §五', msg: '\\left \\right 绝不字面落板' },
  { re: /&amp;|&lt;|&gt;|&nbsp;/, from: 'field-char-escape-filter §三', msg: 'HTML 实体残留未解码' },
  { re: /[\t\u0008\u000B\u000C]/, from: 'field-char-escape-filter §二②', msg: '控制字符 \\t \\b \\v \\f 绝不字面落板' },
  // ★ v9.1 finescan：夏夏横杆教义「横杆是 - 这个符号而不是 _」——板书语境 `_` 无合法用例，
  //   实测 `7 _ 15` / `1836 _______ 4` 穿透归一化直达板书（归一化层 ⑦ 已治；本条为原始形态
  //   审计哨兵，审计点前移后立即活咬，冒烟测试锁规则本身）
  { re: /_+/, from: 'board-speech-rules §2.2 + v4 横杆定档', msg: '横杆一律 - / —— 真字符凑，下划线 _ 严禁落板' },
  // ★ v9.1 finescan：数字夹击双减号凑杆（v4' 深夜定档废案「不是--」）；
  //   行首合法竖式横线 `------` 前无数字不咬（防误伤，与竖式豁免同精神）
  { re: /\d\s*--\s*\d/, from: 'board-speech-rules §2.2 + v4\' 横杆定档', msg: '双减号 -- 凑横杆已废止（数字夹击），按分子字符数两档 - / ——' },
]

// ─── skill 4: speech-board-timing 口播发音硬规范 ─────────
const SPEECH_RULES = [
  // 注: skill §五.1 原正则只匹配阿拉伯数字, 实际口播中文数字也常出现 (三/四), 扩展支持
  { re: /[\d零〇一二两三四五六七八九十百千万亿]+\s*[\/⁄]\s*[\d零〇一二两三四五六七八九十百千万亿]+/, from: 'speech-board-timing §五.1', msg: '口播分数不得用斜杠，写"分母分之分子"' },
  { re: /[x×·]/, from: 'speech-board-timing §五.2', msg: '口播不得保留小写 x、× 或 ·；未知数用大写 X，乘号写"乘以"' },
  { re: /÷/, from: 'speech-board-timing §五.2', msg: '口播不得保留 ÷，写"除以"（板书除号 .-. 漏进口播同念除以）' },
  // 只提示演错再改口，不拦截正常的启发提问和语气词。
  { re: /哦不对|不对不对|(?:我|咱们|我们)(?:刚才)?(?:又)?(?:算错了|看错了|看岔了)|重新算|差点写错|脑子绕晕了|咱们重来/, from: '教风铁律', msg: '疑似改口式演错，请人工核对；先在内部验算，口播只呈现正确推导，保留自然启发提问' },
  { re: /\+/, from: 'speech-board-timing §五.2', msg: '口播中的 + 必须写成"加"' },
  { re: /\d+\.\d+/, from: 'speech-board-timing §五.3', msg: '口播小数不得保留小数点，写"3点一四"逐位汉字' },
  { re: /\\(?:d?frac|sqrt|text)|\$/, from: 'speech-board-timing §五.2', msg: '口播不得含 KaTeX 命令或 $ 定界符' },
]

// ─── ★ 一步一行铁律（2026-10-27 夏夏拍板）：挤行启发式 ─────────
// 播放器按 row 对齐音频和写字：口播一大段串着好几步板书挤一行 = 写字进度和语音进度互相追不上。
// 双信号检测：speech 超长 且 board 含多行步骤算式（\n 分隔）。竖式横线行（行首 ------）是
// 教义允许的竖式组成部分，剔除后再计数，防误伤。
function checkRowGranularity(speech, boardContent, rowIdx) {
  const violations = []
  const speechLen = speech.replace(/\s/g, '').length
  if (speechLen < 120) return violations // 口播不够长，单信号不报警
  const lines = String(boardContent || '').split('\n')
      .map(l => l.trim())
      .filter(l => l && !/^-{4,}$/.test(l)) // 竖式横线行豁免
  const stepLike = lines.filter(l => /[=＝]/.test(l) || /[xX·][\d(]/.test(l))
  if (stepLike.length >= 3) {
    violations.push({
      path: `rows[${rowIdx}].board`,
      from: '一步一行铁律',
      msg: `疑似挤行：口播 ${speechLen} 字串着 ${stepLike.length} 步板书挤一行——播放器按 row 对齐音频和写字，挤行会音画不同步；建议按步骤拆成多个 row（宁可多拆几行）`,
    })
  }
  return violations
}

// ─── skill 3: hand-action-control 工具白名单 + Agent 不得填时长 ─────────
import { ROUGH_NOTATION_TOOL_ID, ROUGH_NOTATION_ENABLED_ACTIONS } from '../board-tools/roughNotationTool.js'
const ALLOWED_NOTATION_ACTIONS = new Set(ROUGH_NOTATION_ENABLED_ACTIONS)

// ─── skill 2: handwriting-font-policy L1 题目层永久印刷体 ─────────
// board.region === 'question' 时, 不应该有手写体标记 (本题代码层不直接判字体, 留软提示)

// ─── skill 1: board-zone-layout 坐标越界 (百分比 0-100) ─────────
function checkCoordBounds(spec, path) {
  const violations = []
  if (Array.isArray(spec?.start) && (spec.start[0] < 0 || spec.start[0] > 100 || spec.start[1] < 0 || spec.start[1] > 100)) {
    violations.push({ path: path + '.start', from: 'board-zone-layout §一', msg: 'start 坐标必须 0—100 百分比' })
  }
  if (Array.isArray(spec?.end) && (spec.end[0] < 0 || spec.end[0] > 100 || spec.end[1] < 0 || spec.end[1] > 100)) {
    violations.push({ path: path + '.end', from: 'board-zone-layout §一', msg: 'end 坐标必须 0—100 百分比' })
  }
  return violations
}

/**
 * 校验单行 row 的四列是否违反 5 个 skill 的反模式
 * @param {object} row - {stage, speech, board, actionSpec}
 * @param {number} rowIdx - 0-based 行号
 * @returns {Array<{path, from, msg}>} 违规列表, 空数组 = 合规
 */
export function checkSkillViolations(row, rowIdx = 0) {
  const v = []
  const at = `rows[${rowIdx}]`

  // skill 4: 口播发音硬规范
  const speech = String(row?.speech || '')
  SPEECH_RULES.forEach(rule => {
    if (rule.re.test(speech)) v.push({ path: at + '.speech', from: rule.from, msg: rule.msg })
  })

  // skill 5: 板书字段字面落板禁令
  const rawBoards = Array.isArray(row?.boards) ? row.boards : null
  const boardContent = String(
    row?.board?.content ??
    (rawBoards ? rawBoards.map(b => (b && typeof b === 'object' ? b.content ?? b.text ?? '' : String(b ?? ''))).join('\n') : null) ??
    (typeof row?.board === 'string' ? row.board : '')
  )
  v.push(...checkRowGranularity(speech, boardContent, rowIdx))
  FORBIDDEN_LITERAL.forEach(rule => {
    if (rule.re.test(boardContent)) v.push({ path: at + '.board.content', from: rule.from, msg: rule.msg })
  })

  // skill 3: 动作工具白名单 + Agent 不得填时长
  const specs = Array.isArray(row?.actionSpec) ? row.actionSpec : []
  specs.forEach((spec, i) => {
    // 兼容两种 actionSpec 结构: {tool, action, ...} 或 {action: {tool, action, ...}}
    const action = spec?.action && typeof spec?.action === 'object' ? spec.action : spec
    const tool = action?.tool
    const sat = `${at}.actionSpec[${i}]`

    if (!tool) {
      v.push({ path: sat, from: 'hand-action-control §二', msg: '动作缺少 tool 字段' })
    } else if (tool !== ROUGH_NOTATION_TOOL_ID) {
      v.push({ path: sat + '.tool', from: 'hand-action-control §二', msg: `Unsupported board tool: ${tool} (allowed: rough-notation)` })
    }

    if (tool === ROUGH_NOTATION_TOOL_ID && !ALLOWED_NOTATION_ACTIONS.has(action.action)) {
      v.push({ path: sat + '.action', from: 'hand-action-control §三', msg: `rough-notation 动作 ${action.action} 不在白名单（Task 43：underline/circle）` })
    }

    // Agent 不得填时长
    if (action.durationMs != null || action.estimatedDurationMs != null) {
      v.push({ path: sat, from: 'hand-action-control §二', msg: '时长由程序算, Agent 不得填 durationMs/estimatedDurationMs' })
    }
    // ★ Task 46 归一：Agent 不得填 gapAfterMs（任意值，含合法值）——间隔由程序按 MIN_HAND_LIFT_GAP_MS=1000 排期；
    // 旧「< 600 才违规」双重劈腿（真源 1000 + 教义是 agent 根本不得填）同日废弃。
    if (action.gapAfterMs != null) {
      v.push({ path: sat + '.gapAfterMs', from: 'hand-action-control §一', msg: 'Agent 不得填写 gapAfterMs（程序按 MIN_HAND_LIFT_GAP_MS=1000 排期；旧 600 阈值口径已废弃，Task 46 归一）' })
    }
    if (action.seed != null) {
      v.push({ path: sat + '.seed', from: 'hand-action-control §二', msg: 'roughjs 随机种子由程序生成, Agent 不得填' })
    }

    // ★ Task 43 动作 1.0：triggerKeyword entry 级逐字校验（口播触发词必须逐字存在于本行 speech）
    // 程序兑底与 Check Agent prompt §8 同口径：miss → 违规报告（编译层自行退串行，不丢动作）
    const kw = spec?.triggerKeyword
    if (typeof kw === 'string' && kw.trim()) {
      const speech = String(row?.speech || '')
      if (!speech.includes(kw)) {
        v.push({ path: sat + '.triggerKeyword', from: 'hand-action-control §六', msg: `触发词 "${kw}" 不在本行 speech 原文中（必须逐字存在，miss 退串行）` })
      }
    }
    // 写错层：triggerKeyword 落在 action 内部会被忽略（entry 级才生效）
    if (action.triggerKeyword != null && spec?.triggerKeyword == null) {
      v.push({ path: sat + '.action.triggerKeyword', from: 'hand-action-control §六', msg: 'triggerKeyword 写在 action 内部会被忽略——它是 entry 级字段（与 action 平级）' })
    }

    // skill 1: 坐标越界
    v.push(...checkCoordBounds(action, sat))
  })

  // skill 2: L1 题目层 region 软提示 (题目区不该有手写体 board content)
  if (row?.board?.region === 'question' && boardContent && boardContent.length > 0) {
    // 读题行 board.content 应为空 (与 board-lecture-player contract §5 对齐)
    v.push({ path: at + '.board.content', from: 'board-lecture-player contract §5 + handwriting-font-policy §二', msg: '题目区 board.content 应为空字符串 (读题行不写板书)' })
  }

  return v
}

/**
 * 批量校验 rows 数组
 * @param {Array} rows
 * @returns {{ok: boolean, violations: Array, summary: string}}
 */
export function auditRowsBySkills(rows) {
  if (!Array.isArray(rows)) return { ok: false, violations: [], summary: 'rows 不是数组' }
  const all = []
  rows.forEach((row, i) => all.push(...checkSkillViolations(row, i)))
  return {
    ok: all.length === 0,
    violations: all,
    summary: `5 skill 反模式校验: ${all.length === 0 ? 'PASS' : 'FAIL'} (${all.length} 违规)`,
  }
}
