/**
 * superFilter.js — 车同轨·书同文 12 步过滤流水线（唯一真源）
 *
 * v2 (2026-10-12): 手写字体字库实测校准版
 *   用 fontTools / CDN unicode-range 实测 5 款手写字体的字符覆盖：
 *   平方乔木体(507 主) / 韶华(157) / 上上谦(511) / 三生(510) / 栗壳坚坚(490)
 *   （字体清单真源 = stepHandoff.js HANDWRITING_FONT_STACK，字体宪法 v2 2026-10-15；韶拓 509 未单测，同族降级位）
 *   5/5 支持: ASCII U+0020-007E、CJK 常用字、中文标点 ，。、；：？！（）《》〈〉【】…—‘’“”「」
 *   5/5 全缺: → ⇒ ≤ ≥ ≠ ≈ × ÷ − ± · √ ° ∠ ⊥ ∥ π ∞ ∵ ∴ ℃ 及全部全角字母数字变体
 *   结论: 过滤器输出必须落在「字体安全白名单」内，白名单外一律凑法降级
 *   (ASCII 拼凑或中文)，绝不静默回退印刷体混排。
 *   例外: ² ³ 保留输出 —— 画布层按 1/3 字号上标画「2」「3」(不取 ² 字形)，
 *         DOM 层由 renderBoardSegmentHtml 转为 1/3 字号上标 span，同样不取 ² 字形。
 *   例外②: · 保留输出（★ v10 乘号双分支）——点状乘号 ·•∙ 归一保留 ·；· 字形仅栗坚有
 *         (韶华/CDN 旧款全缺)，渲染层同 ²³ 哲学用全字体都有的 '.' 放大居中凑
 *         (DOM DOT_HTML / 画布 dotOp 墨芯锚定，常数真源 board-doctrine.js SYM.DOT_*)。
 *
 * v3 (2026-10-24): 夏夏三大教义归一（除号/分数/上标）
 *   ① 除号 = `.-.`（点-横-点上下堆叠，画布/DOM 同分数机制画，占 2 行高度）
 *     ——夏夏原话：「除号怎么写：用分数的上下结构，用手写字体的（.-.）一个点在上面
 *     一个点在-的下面！用常见符号凑」；÷ 与 \div 一律归一为 .-.，绝不转分数。
 *   ② 分数 = 上下堆叠凑法，板书/口播/字幕零 KaTeX（唯一例外=题干 mathText.js）
 *     ——夏夏原话：「不要用 KaTeX（除了题目）！依旧用普通的上下分结构写，和除号
 *     写法一样，凑出来！（算作2行高度，防止换行重影）」→ DSL \frac{a}{b}（渲染层内部
 *     记号），布局层按 2 行高度计，防相邻行重影。
 *   ③ 平方/立方 = 右上角上标，手写字体字号缩成 1/3 —— 夏夏原话：「字号缩成1/3之后
 *     把2或者3写在右上角」（旧 0.6 倍废止）。
 *
 * v4 (2026-10-24 晚): 夏夏横杆教义 + 外部 .frac 版最小吸收
 *   ④ 分数/除号横杆 = 手写字体真字符凑，不是 CSS border 画线、更不是 _ ——夏夏原话：
 *     「除号和分数中间的横杆，是 - 这个符号而不是 _！！！如果是上面很多分子的
 *     算式是这个 ——」。外部 .frac 版可学的只有「.82em 三层居中结构」；其 border-top
 *     画线、杆只随分母宽的缺陷弃用。
 *   ④' (2026-10-24 深夜定档): 横杆两档按分子字符数一刀切 ——夏夏原话：
 *     「——  分子超过3个字符的用这个   不是--」。分子 ≤3 字符 → '-'；分子 >3 字符
 *     → '——'。双减号 '--' 拼短横与视觉宽度估算 visualWidthEm 一并废止（重复即多余，
 *     多余即没有价值）。「——」负距闭合：平方乔木体 '—' 墨芯不满步进（实测 adv 20.1px
 *     /墨芯 15px@26px），原生两连断成两截——夏夏「——」是一根连续长横（不是 --），
 *     DOM 第二根 margin-left:-0.25em / 画布第二根 0.70×adv 负步进拼接，不透明墨叠加
 *     不可见（横杆口径两侧镜像，行为对拍哨兵 test-player-mirror-parity A6）。
 *
 * v7 (2026-10-25 晚): 夏夏三教义连发——①默认板书字体换栗壳坚坚体(490)（字体宪法 v2.4，
 *   stepHandoff 真源；DIV_HTML 墨芯常数随栗坚重测：上 -0.510em/下 -0.165em/left +0.125em
 *   （40px 浏览器栅格实测定杆，同下方 v7 详解块/真源 board-doctrine.js；fontTools 轮廓值
 *   -0.477/-0.164/0.12 仅解算交叉参照，勿据此改码），
 *   旧乔木口径 -0.435/-0.115/+0.188 随字体退役）；②分数字号 = 板书字号 5分3（font-size:.6em，
 *   旧 .82em 废止，与画布 rowImage 0.6 档同源）；③'——' 闭合按栗坚 '—' 度量重定
 *   （'—' 墨芯实跨 [0.093,0.74]em → DOM margin-left:-0.173em / 画布 0.775×adv，旧 -0.25em/0.70 随乔木退役）。
 *
 * v8 (2026-10-25 归一化): 夏夏拍板「归一化，合并提取文件统一管理」——本文件与画布端
 *   row-player.html 的分数/除号/长横版式常数，全部收敛到 src/utils/board-doctrine.js
 *   单一真源（SYM 对象），本文件 import 消费、播放器内嵌同值镜像块；哨兵 A10/A11/A12 锁口径。
 *
 * v9 (2026-10-25): 夏夏两教义连发——①分数字号定档：分子/分母 = 板书字号本体（FRAC_SCALE 1，
 *   40→40px——「分子的字号是板书字体的（原来是 3/5），分母也是板书字体的」，分数行按 2 行自然
 *   行高，全尺寸分子分母填满两行信封=老师讲解观感；旧 2/3、3/5、.82em 三档全退役）；②符号贴排：剥除中缀
 *   运算符两侧空格（病根实锤：生成端 prompt 旧示例教模型写「12 .-. 3 = 4」带空格，栗坚空格
 *   步进 0.313em、符号两侧共 0.63em 假空气——「符号与文字数字间隔太宽、怎么调都调不对」
 *   的元凶就是这些真被画出来的空格字形；单一规则见 ⑩'，竖式行首运算符无 \S 左邻天然豁免）。
 *
 * v9.1 (2026-10-25 finescan 八块细扫): 实锤——`7 _ 15` / `1836 _______ 4` / `7--15` 过 12 步
 *   原样存活直达板书（`_` 是 5/5 缺字清单漏网字符、`--` 是 v4' 深夜定档废案残留「不是--」）。
 *   归一化三刀（单一规则，不堆特例）：①⑦ 表新增 `_+` 串归一——夏夏横杆教义「横杆是 - 这个符号
 *   而不是 _」字面落实，串长 ≤3 根 → '-'、>3 根 → '——'（与 barCharsFor 阈值同口径；行首竖式
 *   `______` 同步归一，isRuleLine 纯横线行照旧画 rough 线）；②⑩' 前置一刀——数字夹击双减号
 *   同档归一（`7--15`→`7-15`、`1836 ------ 4`→`1836——4`；行首合法竖式横线 `------` 前无数字
 *   lookaround 够不着天然豁免）；③⑩' 运算符类补 '—'——`1836 —— 4` 长横两侧空格同剥
 *   （破折号贴排归一）。板书语境 `x_1` 下标极罕见，`_` 全拦收益 > 边角（记档）。
 *
 * 中点乘号保留为独立符号；DOM 与播放器均用句点放大居中显示。
 */
import { SYM } from './board-doctrine.js'

/*
 *
 * 12 步流水线（顺序不能倒）:
 *   ① 真实 \r\n \r 统一为 \n          ①' 字面量 \n 还原（后非字母）
 *   ② 控制字符退化为空格              ③ HTML 实体解码（&amp; 最后）
 *   ④ LaTeX 损伤修复                  ④' <br>→\n + 白名单标签剥除
 *   ⑤ aligned 环境剥壳 + 删 $ \left \right
 *   ⑥ 全角变体归半角（保留全角标点）
 *   ⑦ Unicode 缺字凑法降级            ⑧ LaTeX → 板书安全凑法
 *   ⑨ ^2 ^3 → ² ³（1/3 字号右上角上标）
 *   ⑩ 纯整数 a/b → \frac{a}{b}（堆叠 DSL）⑩' 符号贴排（含前置：数字夹击 -- 横杆归一；剥运算符两侧空格，竖式行首豁免）⑪ 压行内空白（保前导）
 *   ⑫ 连续 3+ 换行压成 2 个
 *
 * 接入点: RealBoardPreview.vue (B 页画布预览) + AgentBDirect.vue (表格板书列, renderBoardTextHtml)
 * ★ 2026-10-24 起板书链路零 KaTeX（夏夏「不要用 KaTeX 这个（除了题目）」）；
 *   KaTeX 唯一合法区 = 题干 mathText.js。
 * 镜像副本（改这里必须同步）: row-player.html / public/row-player.html
 * （lite-player.html 孤儿档案已于 2026-10-13 第七轮退役，git 历史可溯）
 * 一致性哨兵: scripts/test-superFilter.mjs 内含镜像同步检查
 *
 * @qh-core LANE=SHARED POINT=SUPER_FILTER
 */

// ===== ⑦ Unicode 缺字凑法降级表（实测 5/5 字体无字形 → 用支持的字符凑）=====
// 原则: 数学符号用 ASCII 键盘符凑（-> => <= >=），语义符号用中文凑（约/度/角/根号）
const UNICODE2SAFE = [
  // 箭头 → ASCII（几何/流程板书惯例，键盘字符手写体必支持）
  [/[\u2192\u21A0\u27F6\u2199\u2190\u27F5]/g, '->'],
  [/\u21D2/g, '=>'],
  [/\u2194/g, '<->'],
  // 关系符 → ASCII
  [/\u2264/g, '<='],
  [/\u2265/g, '>='],
  [/\u2260/g, '!='],
  [/\u2248/g, '约'],
  [/\u2261/g, '恒等于'],
  // 运算符（★ v10 2026-10-26 夏夏乘号双分支：叉状乘号 ×✕✖✗ 照旧归一日常小写 x；点状乘号
  //   •∙ 归一保留 ·——带未知数算式 30X·3=90X 的乘号是 ·，绝不降级 x（旧版 · 与叉状同转 x
  //   会把 30X·3 破坏成 30Xx3，规则断点已修）；÷→.-. 除号堆叠记号；数学长减号转键盘减号）
  // ★ 2026-10-24 夏夏教义：除号不再转分数，归一 .-.（上下点-横-点，渲染层同分数机制凑）
  [/[\u00D7\u2715\u2716\u2717]/g, 'x'],
  [/\u2022|\u2219/g, '·'],
  [/\u00F7/g, '.-.'],
  [/\u2215/g, '.-.'],
  [/\u2212/g, '-'],
  [/\u00B1/g, '+-'],
  [/\u221A/g, '根号'],
  // 度/单位
  [/\u00B0/g, '度'],
  [/\u2103/g, '摄氏度'],
  [/\u2030/g, '千分之'],
  // 几何
  [/\u2220/g, '角'],
  [/\u22A5/g, '垂直'],
  [/[\u2225\u2016]/g, '//'],
  // 希腊/无穷
  [/\u03C0/g, '圆周率'],
  [/\u221E/g, '无穷'],
  // 逻辑
  [/\u2234/g, '因此'],
  [/\u2235/g, '因为'],
  [/\u2208/g, '属于'],
  [/\u222A/g, '并'],
  [/\u2229/g, '交'],
  // 破折号变体归一为全角—（5/5 支持）；全角波浪/竖线转 ASCII
  [/[\u2013\u2012\u2015]/g, '—'],
  // ★ v9.1 finescan：下划线串归一横杆真字符——夏夏横杆教义「横杆是 - 这个符号而不是 _」字面
  //   落实。`_` 是 5/5 缺字清单漏网字符（板书语境无合法用例，实测 `7 _ 15`/`1836 _______ 4`
  //   原样落板）。串长 ≤3 根 → '-'、>3 根 → '——'（与 barCharsFor 阈值同口径）；行首竖式
  //   `______` 同步归一，isRuleLine 纯横线行照旧吃掉画 rough 线。`7 _ 15` → `7 - 15`，
  //   两侧空格由 ⑩' 接力剥除。
  [/_+/g, m => m.length > 3 ? '——' : '-'],
  [/[\uFF5E\u301C]/g, '~'],
  [/\uFF5C/g, '|'],
  // 日式引号转中式（『』全字体缺字，「」5/5 支持）
  [/\u300E/g, '「'],
  [/\u300F/g, '」'],
]

// ===== ⑧ LaTeX → 板书安全凑法（长命令在前，防短正则截断）=====
const LATEX2SAFE = [
  [/\\rightarrow\b/g, '->'],
  [/\\Rightarrow\b/g, '=>'],
  [/\\to\b/g, '->'],
  [/\\times(?![a-zA-Z])/g, 'x'],
  [/\\div(?![a-zA-Z])/g, '.-.'],   // ★ 2026-10-24 夏夏教义：除号归一 .-.，绝不转分数
  [/\\cdot(?![a-zA-Z])/g, '·'],    // ★ v10 乘号双分支：\cdot 点乘语义归 ·（旧转 x）；负向断言
                                 //   (?![a-zA-Z]) 替 \b——命令后随数字（\cdot3，t→3 均词字符
                                 //   无 \b 边界）也转换，旧版 `30X\cdot3` 整条漏转（既有 bug 顺手修）
  // ⚠ ^\circ 先于裸 \circ，否则留孤立 ^
  [/\^\s*(?:\{\s*\\circ\s*\}|\\circ)/g, '度'], [/\\circ\b/g, '度'], [/\\degree\b/g, '度'],
  // 平方立方：转 ² ³（画布层按 1/3 字号「2」「3」右上角上标画，不取 ²³ 字形）
  [/\^\s*(?:\{\s*2\s*\}|2)/g, '²'],
  [/\^\s*(?:\{\s*3\s*\}|3)/g, '³'],
  [/\\angle\b/g, '角'],
  [/\\pm\b/g, '+-'],
  [/\\perp\b/g, '垂直'],
  [/\\parallel\b/g, '//'],
  [/\\triangle\b/g, '三角形'],
  [/\\therefore\b/g, '因此'],
  [/\\because\b/g, '因为'],
  [/\\le(?:q)?\b/g, '<='],
  [/\\ge(?:q)?\b/g, '>='],
  [/\\ne(?:q)?\b/g, '!='],
  [/\\approx\b/g, '约'],
  [/\\pi\b/g, '圆周率'],
  [/\\infty\b/g, '无穷'],
  [/\\sqrt\s*\{([^}]*)\}/g, '根号$1'],
  [/\\sqrt\b/g, '根号'],
]

// ===== ⑥ 全角变体归半角（全角字母数字运算符 5/5 字体全缺）=====
// 保留全角标点：！（），：；？（自然中文排版且 5/5 支持）
const FW_KEEP = new Set(['\uFF01', '\uFF08', '\uFF09', '\uFF0C', '\uFF1A', '\uFF1B', '\uFF1F'])
function toHalfwidthVariants(t) {
  return t.replace(/[\uFF01-\uFF5E]/g, ch => {
    if (FW_KEEP.has(ch)) return ch
    return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0)
  })
}

// ===== 板书安全白名单（findUnsafeChars 校验用）=====
// ASCII + ²³(渲染层小字号画) + ·(★ v10 点状乘号，渲染层凑法画) + —…‘’“” + 中文标点 + CJK + \frac DSL 字符
const BOARD_SAFE_RE = /[\u0020-\u007E\u00B2\u00B3\u00B7\u2014\u2018-\u201D\u2026\u3001\u3002\u3008-\u3011\u4E00-\u9FFF\uFF01\uFF08\uFF09\uFF0C\uFF1A\uFF1B\uFF1F\\{}^]/

// 结构数学检测：手写字体写不了的 LaTeX 命令（\frac 除外，走画布 frac 排版）
const STRUCT_MATH = /\\(?!frac\b)[a-zA-Z]+|[A-Za-z0-9)\]}]\s*[\^_]\s*\{[^}]+\}|[A-Za-z0-9)\]}]\s*[\^_]\s*[A-Za-z0-9]\s*[\^_]/

// ① LaTeX 转义损伤修复：\frac 被吃成 rac / frac / \u000c+rac
function repairCommonLatexEscapeDamage(t) {
  return t
    .replace(/\u000c\s*rac/g, '\\frac')
    .replace(/(^|[^\w\\])rac(?=\s*\{)/g, '$1\\frac')
    .replace(/(^|[^\w\\])frac(?=\s*\{)/g, '$1\\frac')
}

// ③ HTML 实体解码（⚠ &amp; 必须最后解，否则 &amp;lt; 会被二次解成 <）
// 解码到标准 Unicode，随后的 ⑦ UNICODE2SAFE 统一做缺字凑法（单一职责）
function decodeHtmlEntities(t) {
  return t
    .replace(/&times;/g, '×').replace(/&divide;/g, '÷').replace(/&minus;/g, '−')
    .replace(/&plusmn;/g, '±').replace(/&deg;/g, '°').replace(/&le;/g, '≤')
    .replace(/&ge;/g, '≥').replace(/&ne;/g, '≠').replace(/&middot;/g, '·')
    .replace(/&mdash;/g, '—').replace(/&hellip;/g, '…')
    .replace(/&sup2;/g, '²').replace(/&sup3;/g, '³')
    .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&')
}

function escapeHtmlText(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

/**
 * normalizeBoardLine — 12 步过滤流水线，单行板书清洗（v2 字库实测校准版）
 * @param {string} s 原始板书行
 * @returns {string} 规范化后的板书行（手写字体安全白名单内）
 */
export function normalizeBoardLine(s) {
  let t = String(s == null ? '' : s)

  // ① 真实换行符统一（\r\n / \r → \n）
  t = t.replace(/\r\n|\r/g, '\n')
  // ①' 字面量 \n 还原：排除 \n 开头的 LaTeX 命令（\neq \not \notin \nabla）与单字母变量（\nS \na \nu，
  //     单字母后随边界视为变量不还原）；多字母非命令如 \nstep 视为转义损伤还原为换行。
  //     ★ Task 61 与 row-player 镜像统一到同一超集正则（旧窄正则连自家注释宣称保护的 \nS/\na 都护不住），
  //     行为对拍哨兵 = scripts/test-player-mirror-parity.mjs A 组。
  t = t.replace(/\\r\\n/g, '\n').replace(/\\n(?!(?:eq|ot|abla|otin|e\b|[a-zA-Z]\b))/g, '\n')
  // ② 控制字符 \t \b \v \f 退化为空格
  t = t.replace(/[\t\u0008\u000B\u000C]+/g, ' ')
  // ③ HTML 实体解码（&amp; 最后解）
  t = decodeHtmlEntities(t)
  // ④ LaTeX 损伤修复
  t = repairCommonLatexEscapeDamage(t)
  // ④' HTML 标签剥除：<br> 还原为换行；其余只剥已知格式标签
  //     ⚠ 用白名单标签而非 <[^>]+>：防止误吃 "3 < x, 5 > x" 这类不等式文本
  t = t
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/?(?:b|i|u|em|strong|span|div|p|sub|sup|font|bold)\b[^>]*>/gi, '')
  // ⑤ LaTeX 环境与定界符剥壳：\begin/\end、\\ 换行、& 对齐符、\(\) \[\]
  t = t
    .replace(/\\(?:begin|end)\s*\{[^}]*\}/g, '')
    .replace(/\\\\/g, '\n')
    .replace(/\\\(|\\\)/g, '')
    .replace(/\\\[|\\\]/g, '')
    .replace(/(^|\n)\s*&\s*(?==)/gm, '$1')
    .replace(/\s*&\s*(?==)/g, '')
  // ⑤' 删 $ \left \right（绝不字面落板）
  t = t.replace(/\$+/g, '').replace(/\\left\b|\\right\b/g, '')
  // ⑥ 全角变体归半角（全角标点除外）
  t = toHalfwidthVariants(t)
  // ⑦ Unicode 缺字凑法降级（5/5 字体无字形的字符 → ASCII/中文凑法）
  for (const [re, r] of UNICODE2SAFE) t = t.replace(re, r)
  // ⑧ LaTeX → 板书安全凑法
  for (const [re, r] of LATEX2SAFE) t = t.replace(re, r)
  // ⑨ ^2 ^3 → ² ³（渲染层 1/3 字号右上角上标画——2026-10-24 夏夏教义，旧 0.6 倍废止）
  t = t.replace(/(\w|\))\^2\b/g, '$1²').replace(/(\w|\))\^3\b/g, '$1³')
  // ⑩ 纯整数分数 a/b → \frac{a}{b}（上下堆叠 DSL，渲染层 2 行高度；除号 .-. 除外——
  //     2026-10-24 教义：除号是除号，分数是分数，两不再互转）。
  //     严禁误伤含小数点的数字（183.6 / 9）或单位。
  //     ★ 2026-10-28 分数审计（夏夏指令「几分之几全部一条条看过去」）：lookahead 放行分母后随
  //     字母（3/4x20 → \frac{3}{4}x20，兑现 prompt/board-rules 两处拍板文本「程序统一升成上下
  //     堆叠排版」——旧版 (?=$|[^\w.]) 把 x 当 \w 拦死，实测 3/4x20 平铺不升，规则文本与实现
  //     矛盾）；仍拦数字（3/420 不升，防编号/日期误伤）与下划线。分子是算式（3+34）时 a/b 形态
  //     表达不了整体做分子——生成端规则直接教写 \frac{分子}{分母}（渲染层天然支持），本正则不认
  //     非数字分子，零误伤。
  t = t.replace(/(^|[^\w.])(?<!\.)(\d+)\s*\/\s*(\d+)(?!\.)(?=$|[^\w.]|[A-Za-z])/g, '$1\\frac{$2}{$3}')
  // ⑩' 符号贴排（★ v9 2026-10-25 夏夏教义「专门调整符号与文字数字的间隔，太宽了，怀疑是不是
  //     被前后硬塞了空格」——怀疑属实）：生成端 prompt 旧示例教模型写「12 .-. 3 = 4」带空格，
  //     画布/DOM 会真实画出每个空格字形（栗坚空格步进 0.313em，符号两侧共 0.63em 假空气）。
  //     单一规则两条对称分支，定点迭代到收敛：A 空格后随运算符且空格前有实字删；B 运算符后
  //     空格且运算符前有实字删。每遍只删空格、串长严格递减必然停；多符号链（「6) x 8」「+ ( 1」）
  //     由次遍补剥前遍让位的空格；竖式行首/缩进后的「- 23」「x 2」前无实字，两分支恒够不着、
  //     迭代不动天然豁免；对齐前导空格 ⑪ 照旧保护。无任何按符号堆特例。
  // ⑩' 前置：数字夹击双减号归一（★ v9.1 finescan——v4' 废案 '--' 凑杆残留，`7--15` 实测穿透
  //     归一化直达板书）。按串长同档定杆（≤3 根 '-'、>3 根 '——'）；夹击空格一并剥除；行首合法
  //     竖式横线 `------` 前无数字，lookahead 够不着天然豁免（与竖式行首豁免同精神）。
  //     归一与剥空格同环交替迭代：`7 _ _ 15` 经 ⑦ 产出 `7 - - 15`，首遍剥空格成 `7--15`、
  //     次遍前置归一成 `7-15`——两规则互为接力，任何 _/--/空格 组合必收敛。
  let prev
  // ⑩' 运算符类含全角 —（★ v9.1：⑦ 产出的 `1836 —— 4` 长横两侧空格同剥，破折号贴排归一）
  //   与点状乘号 ·（★ v10：`30X · 3` 带空格的 · 两侧假空气同剥，贴排归一）
  do {
    prev = t
    t = t.replace(/(\d)[ \t]*(-{2,})[ \t]*(?=\d)/g, (m, d, bar) => d + (bar.length > 3 ? '——' : '-'))
    t = t.replace(/(?<=\S) +(?=[+\-*x=<>!%./()—·])|(?<=\S[+\-*x=<>!%./()—·]) +/g, '')
  } while (t !== prev)
  // ⑪ 压行内空白（保护前导空格供竖式与横线对齐，绝不碰 \n）
  const lead = (t.match(/^\s*/) || [''])[0]
  const rest = t.slice(lead.length).replace(/[\t ]+/g, ' ').replace(/\s+$/, '')
  t = lead + rest
  // ⑫ 连续 3 个及以上换行压缩为 2 个（空行泛滥治理）
  t = t.replace(/\n{3,}/g, '\n\n')
  return t
}

/**
 * toBoardLines — 板书字段（字符串/数组/对象）统一过滤 → 一行一个的行数组
 */
export function toBoardLines(v) {
  if (Array.isArray(v)) {
    return v
      .map(x => (x && typeof x === 'object') ? (x.content ?? x.text ?? '') : (x ?? ''))
      .flatMap(x => normalizeBoardLine(x).split('\n'))
      .map(l => l.replace(/\s+$/, ''))
      .filter(l => l.trim().length)
  }
  if (v && typeof v === 'object') return toBoardLines(v.content ?? v.text ?? '')
  return String(v == null ? '' : v)
    .split('\n')
    .flatMap(l => normalizeBoardLine(l).split('\n'))
    .map(l => l.replace(/\s+$/, ''))
    .filter(l => l.trim().length)
}

/**
 * isStructMath — 检测一行是否含结构数学（手写体写不了，需要公式图）
 */
export function isStructMath(line) {
  return STRUCT_MATH.test(line)
}

/**
 * hasStackGlyph — 检测一行是否含上下堆叠结构（\frac 分数 / .-. 除号）
 * ★ 2026-10-24 夏夏教义「算作2行高度，防止换行重影」：消费层据此把该行
 * 按 2 行自然行高排版。src 侧唯一真源（row-player 内嵌镜像 lineStackRows 同语义）。
 */
export function hasStackGlyph(line) {
  return /\\frac|\.\-\./.test(String(line || ''))
}

/**
 * findUnsafeChars — 找出白名单外的字符（Check Agent / 渲染层校验用）
 * 白名单 = 5/5 手写字体实测支持 + 渲染层代画的 ² ³ + \frac DSL 字符
 * @returns {string[]} 去重后的不安全字符列表（空数组 = 全部手写安全）
 */
export function findUnsafeChars(text) {
  const unsafe = new Set()
  for (const ch of String(text)) {
    if (ch === '\n') continue
    if (!BOARD_SAFE_RE.test(ch)) unsafe.add(ch)
  }
  return [...unsafe]
}

/**
 * boardTextToPlain — 板书文本降级为最朴素的纯文本（跨环境兜底）
 * \frac{a}{b} → a/b；.-. → ÷；² ³ → ^2 ^3。用于无渲染器的环境（导出、日志、检索等），
 * 保证任何环境下都「不错误」，只是不再是上下堆叠排版。
 * ★ 2026-10-28 分数审计：分子/分母是算式（含运算符）时套括号——\frac{3+34}{5} 直洗
 *   3+34/5 会被读成 3+(34/5) 语义错位，洗成 (3+34)/5 保真（与 row-player subPlain 同口径）。
 */
export function boardTextToPlain(text) {
  const fracSide = (s) => (/[+\-x·*]/.test(s) ? `(${s})` : s)
  return normalizeBoardLine(text)
    .replace(/\\frac\s*\{([^}]*)\}\s*\{([^}]*)\}/g, (_m, a, b) => `${fracSide(a)}/${fracSide(b)}`)
    .replace(/\.\-\./g, '÷')
    .replace(/²/g, '^2').replace(/³/g, '^3')
}

// ===== DOM 渲染段（RealBoardPreview / AgentBDirect 表格板书列 v-html 共用逻辑）=====
// 全部 inline style，不依赖任何外部 CSS —— 换环境不会错。
// ★ 2026-10-24 夏夏教义：
//   分数 = 上下堆叠凑法（inline-flex 竖排，占 2 行高度——所在行行高由消费层加倍防重影）；
//   除号 .-. = 同款上下堆叠：上点、- 字符横杆、下点（手写字体凑，与分数同机制）；
//   平方立方 = 右上角上标，字号缩成 1/3（旧 .65em 废止）。
// ★ v4 横杆教义（夏夏：「除号和分数中间的横杆，是 - 这个符号而不是 _！
//   如果是上面很多分子的算式是这个 ——」+ 深夜定档「——  分子超过3个字符的用这个   不是--」）：
//   横杆一律手写字体真字符凑，两档按分子字符数一刀切，禁止 border 画线、禁止 _、禁止 --。
const STACK_CSS = 'display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;line-height:1.05'

/**
 * barCharsFor — 分数横杆字符（横杆真源，DOM superFilter / 画布 row-player 两侧同源镜像）
 * 夏夏 2026-10-24 深夜定档原话：「——  分子超过3个字符的用这个   不是--」
 * 分子 ≤3 字符 → '-'；分子 >3 字符 → '——'。按分子字符数一刀切，不做宽度估算；
 * 双减号 '--' 与 visualWidthEm 宽度定杆已废止。除号 .-. 横杆恒 '-'（DIV_HTML 直写，
 * 无分子不走分档）。横杆是 - 不是 _；DOM/画布均以真字符渲染，零画线。
 * ⚠ '——' 渲染层须负距闭合（字体 '—' 墨芯不满步进，原生两连断两截）：
 *   DOM 第二根 margin-left / 画布第二根步进均为真源 board-doctrine.js SYM.DASH_CLOSE_* 常数。
 *   不透明墨叠加不可见。
 * 行为对拍哨兵：test-player-mirror-parity A6（播放器 §5c 镜像节同语料双跑）。
 */
export function barCharsFor(num) {
  return String(num == null ? '' : num).length > 3 ? '——' : '-'
}

// 除号 .-. 堆叠（★ v6 2026-10-25 夏夏教义定版：「手写字体支持减号加号，你先正常写减号，
//   就不会存在字号乱七八糟的问题，也不存在对称问题」）。v5 flex 三层 .82em+负距结构退役——
//   v6 杆 = 正常 inline 减号（inline-block 保自身行内基线与整行一字不差，「正常写减号」字面
//   落实，零 font-size 覆写）；上下点 width:0 绝对定位贴放，top/left 为墨芯解算常数（点基线
//   在解算中约掉，只剩墨芯度量——与画布 rowImage divOp 绘制段同源）。
//   ★ v7 常数随默认字体换栗壳坚坚体重测（本地分片实测 scripts/div-v7-lijian-test.html，40px 浏览器墨芯带：
//   barAs15/barDe-10/dotAs1/dotDe3/gap2.4/barC8/dotC3 → 上 top=-0.510em、下 top=-0.165em、left=+0.125em
//   （解算公式：上=-(barAs+gap+dotDe)、下=barDe+gap+dotAs、left=barC-dotC；浏览器栅格化墨芯含抗锯齿
//   ~0.7px，以浏览器实测为准——fontTools 轮廓值 -0.477/-0.164/0.12 仅作解算交叉参照；
//   旧乔木口径 -0.435/-0.115/+0.188 随默认字体退役）。
//   width:0 锁因：零宽盒笔位=盒左缘，left 常数精确落点（栗坚 '.' 正常步进 0.167em 墨芯近笔位，
//   旧乔木 '.' 零步进墨芯整在笔位左侧——两族同法墨芯对齐通吃）。
//   消费层行高仍按 hasStackGlyph 2 行高度排。⚠ 常数按默认态（栗坚）解，切乔木/韶华档
//   点位有 ±1-2px 档位差，属既有行为（旧版同理）。
//   ★ v8 归一化（2026-10-25）：上下点 top/left 常数不再字面散落，一律从真源 board-doctrine.js
//   SYM.DIV_DOT_* 取（值同 v7 栗坚口径，输出 HTML 逐字不变）。
const DIV_HTML = `<span style="display:inline-block;position:relative;line-height:1.05">-<span style="position:absolute;width:0;left:${SYM.DIV_DOT_LEFT}em;top:${SYM.DIV_DOT_TOP_UP}em">.</span><span style="position:absolute;width:0;left:${SYM.DIV_DOT_LEFT}em;top:${SYM.DIV_DOT_TOP_DOWN}em">.</span></span>`
// 中点用句点放大居中，与播放器使用相同墨芯位置。
const DOT_HTML = `<span style="font-size:${SYM.DOT_SCALE}em;line-height:0;position:relative;top:${(-SYM.DOT_STACK_Y / SYM.DOT_SCALE - 0.011).toFixed(4)}em">.</span>`
const SUP_MAP = { '²': '2', '³': '3', '¹': '1' }

/**
 * renderBoardSegmentHtml — 单行板书 → 安全 HTML 片段（v-html 用）
 * 先转义再构建标记；\frac → 三层堆叠分数（分子/横杆字符/分母）；.-. → 点-(-字符)横-点除号；
 * ² ³ → 1/3 字号上标 span。横杆层 = barCharsFor 两档真字符（'-' / '——'，长横负距闭合）。
 */
export function renderBoardSegmentHtml(text) {
  const esc = escapeHtmlText(normalizeBoardLine(text))
  return esc
    // 分数三层：分子 / 横杆真字符 / 分母（barCharsFor 两档定杆：分子≤3字符 '-'、>3字符 '——'
    // ——夏夏深夜定档「—— 分子超过3个字符的用这个 不是--」；学外部 .frac 版三层居中，弃其 border 画线）
    // ★ v9 2026-10-25 夏夏分数字号定档「分子的字号是板书字体的（原来 3/5），分母也是板书字体的」：
    //   分子分母 = 板书字号本体（FRAC_SCALE 1，40px 板书→40px 分数——分数行按 2 行自然行高，
    //   全尺寸分子分母填满两行信封=老师讲解观感；旧 0.667/0.6/.82em 三档全退役，与画布同源）
    .replace(/\\frac\s*\{([^}]*)\}\s*\{([^}]*)\}/g, (m, num, den) => {
      const bar = barCharsFor(num)
      // '——' 负距闭合：栗壳坚坚体 '—' adv 0.77em 墨芯 0.647em（两端各空 0.03/0.01em），原生
      // 两连断两截——夏夏「——」是一根连续长横（不是 --）。第二根 margin-left:-0.173em 拉回
      //   （第二笔位 = 0.77-0.173=0.597em，其墨芯起点 0.093+0.597=0.69 ≤ 首根墨底 0.74-0.05 → 墨芯叠
      //   0.05em 不透明不可见、任意字号通用，与画布 0.775×adv 同源；旧乔木 -0.25em 随默认字体退役）
      const barHtml = bar === '——'
        ? `<span>—</span><span style="margin-left:${SYM.DASH_CLOSE_DOM}em">—</span>`
        : bar
      return `<span style="${STACK_CSS};margin:0 2px;font-size:${SYM.FRAC_SCALE}em">` +
        `<span style="padding:0 3px">${num}</span>` +
        `<span style="padding:0 3px">${barHtml}</span>` +
        `<span style="padding:0 3px">${den}</span></span>`
    })
    .replace(/\.\-\./g, DIV_HTML)   // 除号堆叠；FRAC 构造/DIV_HTML 自身不含 .-. 字面，先后替换两不相伤
    .replace(/·/g, DOT_HTML)       // ★ v10 乘号双分支：· 凑法渲染（'.' 放大居中，同 ²³ 哲学；
                                   //   真字形仅栗坚有，韶华/CDN 旧款全缺，切字体即坏）
    .replace(/[²³¹]/g, ch => (
      `<span style="font-size:.3333em;vertical-align:super;line-height:0;margin-left:1px">${SUP_MAP[ch]}</span>`
    ))
}

/**
 * renderBoardTextHtml — 多行板书 → 安全 HTML（换行转 <br>）
 */
export function renderBoardTextHtml(text) {
  return String(text == null ? '' : text)
    .split('\n')
    .map(l => renderBoardSegmentHtml(l))
    .join('<br>')
}

// ponytail: 唯一真源 — row-player.html / public/row-player.html 镜像此文件，
// scripts/test-superFilter.mjs 里有镜像一致性哨兵，改这里必须跑测试同步两处副本。
