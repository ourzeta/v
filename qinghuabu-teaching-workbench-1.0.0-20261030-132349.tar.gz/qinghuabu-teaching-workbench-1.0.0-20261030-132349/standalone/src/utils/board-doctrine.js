/**
 * board-doctrine.js — 板书符号教义 · 单一真源（★ 2026-10-25 归一化）
 *
 * 夏夏拍板：「归一化简化……合并提取文件统一管理」——分数/除号/长横闭合的版式常数
 * 此前散落在 row-player.html（measureLine/rowImage 多处字面量）与 src/utils/superFilter.js
 * （DIV_HTML/分数 em 档），改一处漏一处。现全部收敛到本文件，统一管理：
 *
 *   消费端①（DOM 端）src/utils/superFilter.js — `import { SYM }` 构建 DIV_HTML/分数/长横 HTML；
 *   消费端②（画布端）row-player.html — 顶部 `const SYM=Object.freeze({...})` 镜像块（播放器是
 *     单文件离线三胞胎，无法 import src/，按既有镜像惯例内嵌同值块）；
 *   哨兵 test-font-single-source A12 对拍两侧同值，A10/A11 断言真源数值与旧值绝迹。
 *
 * 各常数出处（实测记档见 superFilter.js / row-player.html 注释）：
 *   - FRAC_SCALE 1        v9 定档 2026-10-25 夏夏「分子的字号是板书字体的（原来 3/5），分母也是
 *                         板书字体的」——分数行按 2 行自然行高，全尺寸填满=老师讲解观感（旧 0.667/0.6/.82em 全退役）
 *   - FRAC_MARGIN 0.28  同日「token 两侧余量收紧，治稀稀拉拉」（旧 0.45 废止）
 *   - FRAC_GAP 0.10     分子/分母墨芯与杆的间隙（×分数字号，墨芯锚定版式）
 *   - DIV_STEP 0.5      除号 token 步进（×板书字号；measureLine/rowImage/boardCharPool 同口径）
 *   - DIV_GAP 0.06      除号上下点与杆的间隙（×板书字号，墨芯锚定）
 *   - DIV_DOT_*         除号 DOM 端墨芯解算常数（em；栗壳坚坚体 40px 浏览器栅格实测：
 *                        上=-(barAs+gap+dotDe)、下=barDe+gap+dotAs、left=barC-dotC；
 *                        随默认字体换代须重测——上次换栗坚实测页 scripts/div-v7-lijian-test.html）
 *   - DASH_CLOSE_*      「——」负距闭合：原生两连断两截，第二根拉回拼接成一根连续长横
 *                        （画布 0.775×adv 与 DOM -0.173em 为同一墨芯跨度的两种单位表达，非相等）
 *
 * ⚠ 改这里的值 = 画布/DOM 两端同时生效；改完必跑 npm test（A10/A11/A12 哨兵）。
 */
export const SYM = Object.freeze({
  // —— 分数（\frac 上下堆叠）——
  FRAC_SCALE: 1,          // 分子/分母字号 = 板书字号本体（v9 夏夏定档「分子的字号是板书字体的
                         //   （原来 3/5），分母也是板书字体的」：40→40px，分数行 lineStackRows 按 2 行自然
                         //   行高，全尺寸填满两行信封=老师讲解观感；旧 0.667/0.6/.82em 三档全退役。DOM `${SYM.FRAC_SCALE}em` 同源）
  FRAC_MARGIN: 0.28,      // 分数 token 两侧余量 ×板书字号
  FRAC_STACK_Y: 0.28,     // 分数栈中心相对基线上移 ×板书字号（对齐行内数字墨芯中心带）
  FRAC_GAP: 0.10,         // 分子/分母墨芯与横杆的间隙 ×分数字号
  // —— 除号（.-. 点-横-点堆叠；杆=正常写的减号，v6 夏夏教义定版）——
  DIV_STEP: 0.5,          // 除号 token 步进 ×板书字号
  DIV_GAP: 0.06,          // 上下点墨芯与杆的间隙 ×板书字号
  DIV_DOT_TOP_UP: -0.510, // DOM 上点 top（em，墨芯解算）
  DIV_DOT_TOP_DOWN: -0.165,// DOM 下点 top（em，墨芯解算）
  DIV_DOT_LEFT: 0.125,    // DOM 点 left（em，墨芯解算）
  // —— 长横「——」负距闭合（夏夏「——是一根连续长横，不是 --」）——
  DASH_CLOSE_STEP: 0.775, // 画布第二根步进 ×adv
  DASH_CLOSE_DOM: -0.173, // DOM 第二根 margin-left（em）
  // 中点乘号用句点放大居中，避免切换手写字体时缺字。
  DOT_SCALE: 1.57,
  DOT_STACK_Y: 0.349,

})
